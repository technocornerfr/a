# Résolution de l'erreur npm "could not determine executable to run"

## Diagnostic du problème

Cette erreur se produit quand npm ne trouve pas les exécutables requis pour Capacitor. Plusieurs solutions selon votre configuration :

## Solution 1 : Vérifier l'installation Capacitor

```bash
# Vérifiez si Capacitor CLI est installé
npm list @capacitor/cli

# Si absent, installez-le
npm install @capacitor/cli
```

## Solution 2 : Utiliser npx avec chemin complet

```bash
# Au lieu de : npx cap sync ios
# Utilisez :
npx @capacitor/cli sync ios
```

## Solution 3 : Installation globale (recommandée)

```bash
# Installer Capacitor CLI globalement
npm install -g @capacitor/cli

# Puis utiliser directement
cap sync ios
```

## Solution 4 : Script manuel pour votre Mac

Créez ce script `sync-ios.sh` dans votre dossier TechnoCorner :

```bash
#!/bin/bash
echo "Synchronisation TechnoCorner iOS..."

# Méthode 1 : Essayer avec npx complet
echo "Tentative avec npx @capacitor/cli..."
npx @capacitor/cli sync ios
if [ $? -eq 0 ]; then
    echo "✅ Sync réussi avec npx @capacitor/cli"
    exit 0
fi

# Méthode 2 : Essayer avec node_modules local
echo "Tentative avec node_modules local..."
./node_modules/.bin/cap sync ios
if [ $? -eq 0 ]; then
    echo "✅ Sync réussi avec node_modules local"
    exit 0
fi

# Méthode 3 : Copie manuelle
echo "Copie manuelle des fichiers..."
mkdir -p ios/App/App/public
cp -r dist/* ios/App/App/public/
cp -r client/* ios/App/App/public/
echo "✅ Copie manuelle terminée"
```

## Solution 5 : Nettoyer et réinstaller

```bash
# Nettoyer le cache npm
npm cache clean --force

# Supprimer node_modules
rm -rf node_modules
rm package-lock.json

# Réinstaller
npm install

# Essayer sync
npx cap sync ios
```

## Solution immédiate pour votre cas

Exécutez ces commandes dans l'ordre sur votre Mac :

```bash
# 1. Aller dans votre dossier TechnoCorner
cd ~/path/to/your/technocorner

# 2. Installer Capacitor CLI globalement
npm install -g @capacitor/cli

# 3. Vérifier l'installation
cap --version

# 4. Synchroniser
cap sync ios

# 5. Si ça ne marche pas, essayer avec npx complet
npx @capacitor/cli sync ios
```

## Vérification du résultat

Après synchronisation réussie, vérifiez que vos fichiers sont copiés :

```bash
ls -la ios/App/App/public/
```

Vous devriez voir :
- index.html
- src/ (avec vos fichiers React)
- Autres assets de votre app

## Ouverture Xcode

Une fois la sync réussie :

```bash
cd ios/App
open App.xcworkspace
```

L'erreur npm est généralement liée à un problème de PATH ou d'installation Capacitor CLI. La solution globale devrait résoudre le problème définitivement.