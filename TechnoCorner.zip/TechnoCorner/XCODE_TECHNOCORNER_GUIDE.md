# Guide Xcode pour Votre Projet TechnoCorner Existant

## Situation actuelle
Votre projet TechnoCorner est déjà configuré avec :
- React/TypeScript frontend
- Capacitor pour iOS 
- Projet Xcode dans le dossier `ios/App/`

## Étape 1 : Ouvrir le bon projet Xcode

### Commande pour ouvrir Xcode
```bash
# Depuis la racine de votre projet TechnoCorner
cd ios/App
open App.xcworkspace
```

**IMPORTANT :** Ouvrez `App.xcworkspace` (pas App.xcodeproj)

### Si "open" ne fonctionne pas
1. **Ouvrez Finder**
2. **Naviguez vers votre dossier TechnoCorner**
3. **Allez dans `ios/App/`**
4. **Double-cliquez sur `App.xcworkspace`**

## Étape 2 : Localiser les zones de configuration dans Xcode

### Interface Xcode une fois ouvert
```
┌─────────────────────────────────────────────────────────────┐
│ [File] [Edit] [View] [Product] [Debug] [Window] [Help]     │ ← Menu principal
├─────────────────────────────────────────────────────────────┤
│ ◀ ▶ ⏸ ■   [App] ▼ [iPhone 15 Pro] ▼   [▶]               │ ← Barre d'outils
├─────────────┬───────────────────────────────┬───────────────┤
│             │                               │               │
│  Navigator  │        Zone principale        │   Inspector   │
│  (Sidebar)  │        (Configuration)        │   (Détails)   │
│             │                               │               │
└─────────────┴───────────────────────────────┴───────────────┘
```

### Afficher le Navigator si absent
- **Menu View → Navigators → Show Project Navigator**
- **Ou raccourci : Cmd+1**
- **Ou cliquez l'icône dossier** en haut à gauche

### Structure de votre projet TechnoCorner
```
📁 App (← CLIQUEZ ICI pour voir les configurations)
  📁 App (dossier source)
    📁 public (votre app React compilée)
      📄 index.html
      📄 static/ (CSS, JS, images)
    📄 AppDelegate.swift
    📄 SceneDelegate.swift
    📄 ViewController.swift
    📄 Info.plist
    📁 Assets.xcassets
      📄 AppIcon.appiconset
  📁 Pods (dépendances Capacitor)
    📁 Capacitor
    📁 CapacitorCordova
  🔨 Products
    📱 App.app
```

## Étape 3 : Configuration dans l'onglet General

### Accéder aux paramètres
1. **Cliquez sur "App"** (premier élément avec icône de dossier bleu)
2. **L'onglet "General" s'affiche** automatiquement au centre

### Ce que vous devez voir
```
┌─────────────────────────────────────────────────────────┐
│ General │ Signing & Capabilities │ Build Settings │ ... │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📱 App                                                │ ← Nom du projet
│                                                         │
│  Identity                                              │
│  ├ Display Name: [App              ]                   │ ← Changez en "TechnoCorner"
│  ├ Bundle Identifier: [com.example.app]                │ ← Changez en unique
│  ├ Version: [1.0.0]                                   │
│  └ Build: [1]                                         │
│                                                         │
│  Deployment Info                                       │
│  ├ Minimum Deployment Target: [iOS 13.0]              │
│  ├ iPhone Orientation: ☑ Portrait ☐ Landscape        │
│  └ iPad Orientation: (configurations iPad)             │
│                                                         │
│  App Icons and Launch Screen                           │
│  ├ App Icons Source: [AppIcon]                        │
│  └ Launch Screen: [LaunchScreen]                       │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Modifications nécessaires
1. **Display Name :** Changez "App" en "TechnoCorner"
2. **Bundle Identifier :** Changez en quelque chose d'unique comme :
   - `com.votrenom.technocorner`
   - `com.technocorner.app`
   - `com.votrenom.techno2025`

## Étape 4 : Configuration Signing & Capabilities

### Cliquer sur l'onglet Signing & Capabilities
```
┌─────────────────────────────────────────────────────────┐
│ General │ Signing & Capabilities │ Build Settings │ ... │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📱 App                                                │
│                                                         │
│  Signing (Debug)                                       │
│  ☐ Automatically manage signing    ← COCHEZ CETTE CASE │
│  Team: [None]                       ← SÉLECTIONNEZ     │
│  Bundle Identifier: com.votrenom.technocorner          │
│  Provisioning Profile: [None]                          │
│  Signing Certificate: [None]                           │
│                                                         │
│  Signing (Release)                                     │
│  ☐ Automatically manage signing    ← COCHEZ CETTE CASE │
│  Team: [None]                       ← SÉLECTIONNEZ     │
│  Bundle Identifier: com.votrenom.technocorner          │
│  Provisioning Profile: [None]                          │
│  Signing Certificate: [None]                           │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Actions requises
1. **Cochez les deux cases "Automatically manage signing"**
2. **Sélectionnez votre Team** dans les listes déroulantes

### Si pas de Team disponible
1. **Xcode → Preferences (Cmd+,)**
2. **Onglet "Accounts"**
3. **Cliquez "+" → Apple ID**
4. **Entrez vos identifiants Apple Developer**
5. **Retournez à Signing & Capabilities**

## Étape 5 : Vérifier votre app React

### Construire votre app web d'abord
```bash
# Dans le Terminal, depuis la racine TechnoCorner
npm run build
```

### Synchroniser avec iOS
```bash
# Copier la build dans le projet iOS
npx cap sync ios
```

### Tester dans le simulateur
1. **Dans Xcode, sélectionnez "iPhone 15 Pro"** en haut
2. **Cliquez le bouton Play** (triangle)
3. **Votre vraie app TechnoCorner** devrait s'afficher

## Étape 6 : Si vous ne voyez pas les zones détaillées

### Problème : Interface Xcode simplifiée
Votre Xcode pourrait être en mode simplifié. Activez le mode complet :

1. **Menu Xcode → Preferences**
2. **Onglet "General"**
3. **Navigation :** Sélectionnez "Show Navigator"
4. **Inspector :** Sélectionnez "Show Inspector"

### Problème : Mauvais projet ouvert
Assurez-vous d'ouvrir :
- ✅ `ios/App/App.xcworkspace` (CORRECT)
- ❌ `ios/App/App.xcodeproj` (INCORRECT)

### Problème : Navigator fermé
- **View → Navigators → Show Project Navigator**
- **Ou Cmd+1**

## Étape 7 : Build pour App Store

### Une fois configuré
1. **Destination :** "Any iOS Device (arm64)"
2. **Product → Archive**
3. **Distribute App → App Store Connect**

### Votre app React sera empaquetée
- Toute votre interface React/TypeScript
- Toutes vos fonctionnalités TechnoCorner
- Navigation, posts, événements, etc.

## Vérification rapide

### Vous devez voir dans Xcode
- ✅ Navigator avec structure App/Pods
- ✅ Onglets General, Signing & Capabilities
- ✅ Sections Identity, Deployment Info
- ✅ Options de signature avec Team

### Si vous ne voyez toujours pas
1. **Fermez Xcode complètement**
2. **Ouvrez Terminal :**
   ```bash
   cd ios/App
   open App.xcworkspace
   ```
3. **Attendez le chargement complet**
4. **Cmd+1 pour afficher Navigator**

Le projet iOS de TechnoCorner est déjà configuré avec Capacitor. Une fois ouvert correctement dans Xcode, vous verrez toutes les zones détaillées mentionnées dans les guides pour configurer votre vraie application React.