import sgMail from '@sendgrid/mail';

// Configuration SendGrid
sgMail.setApiKey('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');

async function testSendGridEmail() {
  try {
    console.log('Test d\'envoi d\'email avec SendGrid...');
    
    const msg = {
      to: 'growthfabriqueparis@gmail.com',
      from: 'growthfabriqueparis@gmail.com', // Utilisez votre adresse vérifiée
      subject: 'Test TechnoCorner - Votre billet',
      text: 'Ceci est un test d\'envoi d\'email depuis TechnoCorner.',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Test TechnoCorner</h2>
          <p>Ceci est un test d\'envoi d\'email depuis votre application TechnoCorner.</p>
          <p>Si vous recevez cet email, la configuration SendGrid fonctionne correctement.</p>
        </div>
      `
    };

    const response = await sgMail.send(msg);
    console.log('Email envoyé avec succès!');
    console.log('Response:', response[0].statusCode);
    return true;
  } catch (error) {
    console.error('Erreur lors de l\'envoi de l\'email:');
    console.error('Error code:', error.code);
    console.error('Error message:', error.message);
    if (error.response) {
      console.error('Response body:', error.response.body);
    }
    return false;
  }
}

testSendGridEmail();