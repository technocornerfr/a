import { MailService } from '@sendgrid/mail';

const mailService = new MailService();
mailService.setApiKey('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');

interface TicketEmailData {
  buyerName: string;
  buyerEmail: string;
  eventTitle: string;
  eventDate: string;
  venue: string;
  location: string;
  ticketCode: string;
  qrCodeDataUrl?: string | null;
  price: string;
  isExternal?: boolean;
  organizerName?: string;
}

export async function sendTicketEmail(ticketData: TicketEmailData): Promise<boolean> {
  try {
    const isExternal = ticketData.isExternal || false;
    const sourceText = isExternal ? 
      `via ${ticketData.organizerName || 'notre partenaire'} - Powered by TechnoCorner` : 
      'TechnoCorner';
    
    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Votre billet ${isExternal ? 'via TechnoCorner' : 'TechnoCorner'}</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }
          .ticket { background: white; border: 2px dashed #667eea; padding: 25px; margin: 20px 0; border-radius: 10px; }
          .qr-code { text-align: center; margin: 20px 0; }
          .qr-code img { max-width: 200px; height: auto; border: 2px solid #667eea; border-radius: 8px; }
          .event-details { background: #e3f2fd; padding: 20px; border-radius: 8px; margin: 15px 0; }
          .important { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 8px; margin: 15px 0; }
          .external-note { background: #e8f5e8; border: 1px solid #4caf50; padding: 15px; border-radius: 8px; margin: 15px 0; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          .download-section { background: #f0f8ff; border: 2px solid #0066cc; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center; }
          .download-btn { display: inline-block; background: #0066cc; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 10px; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎵 ${sourceText}</h1>
            <h2>Votre billet électronique</h2>
          </div>
          
          <div class="content">
            <h3>Bonjour ${ticketData.buyerName},</h3>
            <p>Félicitations ! Votre achat a été confirmé${isExternal ? ' via notre partenaire' : ''}. Voici votre billet électronique pour :</p>
            
            ${isExternal ? `
            <div class="external-note">
              <h4>✅ Billet généré par ${ticketData.organizerName || 'notre partenaire'}</h4>
              <p>Ce billet a été créé via notre système de billetterie partenaire. Il est 100% valide et garantit votre entrée à l'événement.</p>
            </div>
            ` : ''}
            
            <div class="ticket">
              <div class="event-details">
                <h2 style="margin-top: 0; color: #667eea;">${ticketData.eventTitle}</h2>
                <p><strong>📅 Date :</strong> ${new Date(ticketData.eventDate).toLocaleDateString('fr-FR', { 
                  weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
                })}</p>
                <p><strong>📍 Lieu :</strong> ${ticketData.venue}</p>
                <p><strong>🏙️ Ville :</strong> ${ticketData.location}</p>
                <p><strong>🎫 Code billet :</strong> <code style="background: #f1f3f4; padding: 4px 8px; border-radius: 4px;">${ticketData.ticketCode}</code></p>
                <p><strong>💰 Prix :</strong> ${ticketData.price}</p>
              </div>
              
              <div class="qr-code">
                <h4>QR Code d'entrée</h4>
                <img src="https://${process.env.REPLIT_DEV_DOMAIN || 'localhost:5000'}/api/qr/${ticketData.ticketCode}" 
                     alt="QR Code du billet" 
                     style="max-width: 200px; height: auto; border: 2px solid #667eea; border-radius: 8px; display: block; margin: 0 auto;" />
                <p><small>Présentez ce QR code à l'entrée de l'événement</small></p>
                <p style="font-size: 12px; color: #666; margin-top: 15px;">
                  <strong>Alternative :</strong> Si l'image ne s'affiche pas, utilisez le code : <br>
                  <code style="background: #f1f3f4; padding: 4px 8px; border-radius: 4px; font-size: 14px;">${ticketData.ticketCode}</code>
                </p>
              </div>
            </div>
            
            <div class="download-section">
              <h4>📄 Billet PDF à imprimer</h4>
              <p>Cliquez ci-dessous pour accéder à votre billet dans une page optimisée pour l'impression et l'enregistrement en PDF.</p>
              <a href="https://${process.env.REPLIT_DEV_DOMAIN || 'localhost:5000'}/api/ticket/${ticketData.ticketCode}/print" 
                 class="download-btn" 
                 style="display: inline-block; background: #27ae60; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; margin: 15px 0; font-weight: bold; font-size: 16px;">
                🖨️ Ouvrir le billet imprimable
              </a>
              <p><strong>Instructions :</strong></p>
              <ul style="text-align: left; display: inline-block;">
                <li><strong>Page imprimable :</strong> Cliquez le bouton pour ouvrir votre billet</li>
                <li><strong>Sauvegarder en PDF :</strong> Sur la page, utilisez Ctrl+P puis "Enregistrer au format PDF"</li>
                <li><strong>Imprimer :</strong> Sur la page, utilisez Ctrl+P et sélectionnez votre imprimante</li>
                <li><strong>Email mobile :</strong> Conservez cet email avec le QR code</li>
              </ul>
            </div>
            
            <div class="important">
              <h4>⚠️ Instructions d'entrée :</h4>
              <ul>
                <li>Conservez ce email précieusement</li>
                <li>Présentez le QR code à l'entrée (sur téléphone ou imprimé)</li>
                <li>Arrivez 30 minutes avant le début de l'événement</li>
                <li>Une pièce d'identité pourra vous être demandée</li>
                ${isExternal ? '<li>En cas de problème, contactez directement l\'organisateur</li>' : ''}
              </ul>
            </div>
            
            <p>Nous avons hâte de vous voir danser sur les meilleures vibrations techno !</p>
            <p><strong>${isExternal ? `L'équipe ${ticketData.organizerName || 'organisateur'} & ` : ''}L'équipe TechnoCorner</strong></p>
          </div>
          
          <div class="footer">
            <p>TechnoCorner - La plateforme de référence pour les événements électroniques</p>
            <p>Cet email a été envoyé automatiquement, merci de ne pas y répondre.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    await mailService.send({
      to: ticketData.buyerEmail,
      from: 'growthfabriqueparis@gmail.com',
      subject: `🎵 Votre billet pour ${ticketData.eventTitle}`,
      text: `Bonjour ${ticketData.buyerName},\n\nVotre billet pour ${ticketData.eventTitle} est confirmé.\nCode: ${ticketData.ticketCode}\nDate: ${ticketData.eventDate}\nLieu: ${ticketData.venue}\n\nPrésentez le QR code joint à l'entrée.\n\nL'équipe TechnoCorner`,
      html: emailHtml,
    });

    console.log(`Email envoyé avec succès à ${ticketData.buyerEmail}`);
    return true;
  } catch (error) {
    console.error('Erreur envoi email:', error);
    return false;
  }
}