import { users, events, tickets, posts, postLikes, postComments, organizerPayouts, organizerWebhooks, privateMessages, userFollows, externalApiKeys, externalEvents, externalTickets, apiAuditLog, type User, type InsertUser, type UpdateUserProfile, type Event, type InsertEvent, type Ticket, type InsertTicket, type Post, type InsertPost, type PostLike, type InsertPostLike, type PostComment, type InsertPostComment, type OrganizerPayout, type InsertOrganizerPayout, type OrganizerWebhook, type InsertOrganizerWebhook, type PrivateMessage, type InsertPrivateMessage, type UserFollow, type InsertUserFollow, type ExternalApiKey, type InsertExternalApiKey, type ExternalEvent, type InsertExternalEvent, type ExternalTicket, type InsertExternalTicket, type ApiAuditLog, type InsertApiAuditLog } from "@shared/schema";
import { db } from "./db";
import { eq, ilike, or, asc, lt, desc, sql, and } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserProfile(id: number, profile: UpdateUserProfile): Promise<User>;
  
  // Event methods
  getAllEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  getEventsByCategory(category: string): Promise<Event[]>;
  searchEvents(query: string): Promise<Event[]>;
  getEventsByOrganizer(organizerEmail: string): Promise<Event[]>;
  deleteEvent(eventId: number, organizerEmail: string): Promise<void>;
  
  // Ticket methods
  purchaseTicket(ticket: InsertTicket): Promise<Ticket>;
  getUserTickets(userId: number): Promise<Ticket[]>;
  getEventTickets(eventId: number): Promise<Ticket[]>;
  getTicketByCode(ticketCode: string): Promise<Ticket | undefined>;
  updateTicketStatus(ticketId: number, status: string): Promise<Ticket>;
  
  // Community/Feed methods
  createPost(post: InsertPost): Promise<Post>;
  getFeedPosts(limit?: number, offset?: number): Promise<Post[]>;
  getUserPosts(userId: number): Promise<Post[]>;
  likePost(postId: number, userId: number): Promise<PostLike>;
  unlikePost(postId: number, userId: number): Promise<void>;
  isPostLiked(postId: number, userId: number): Promise<boolean>;
  repostPost(originalPostId: number, userId: number, content?: string): Promise<Post>;
  addComment(comment: InsertPostComment): Promise<PostComment>;
  getPostComments(postId: number): Promise<PostComment[]>;
  deletePost(postId: number, userId: number): Promise<void>;
  
  // Organizer Payout methods
  createOrganizerPayout(payout: InsertOrganizerPayout): Promise<OrganizerPayout>;
  getPendingPayouts(): Promise<OrganizerPayout[]>;
  updatePayoutStatus(payoutId: number, status: string, stripeTransferId?: string): Promise<OrganizerPayout>;
  getOrganizerPayouts(organizerEmail: string): Promise<OrganizerPayout[]>;
  
  // Organizer Webhook methods
  createOrganizerWebhook(webhook: InsertOrganizerWebhook): Promise<OrganizerWebhook>;
  getPendingWebhooks(): Promise<OrganizerWebhook[]>;
  updateWebhookStatus(webhookId: number, status: string, responseStatus?: number, errorMessage?: string): Promise<OrganizerWebhook>;
  getEventWebhooks(eventId: number): Promise<OrganizerWebhook[]>;
  
  // Private Messages methods
  sendMessage(message: InsertPrivateMessage): Promise<PrivateMessage>;
  getConversations(userId: number): Promise<any[]>;
  getConversationMessages(userId: number, otherUserId: number): Promise<any[]>;
  markMessagesAsRead(userId: number, otherUserId: number): Promise<void>;
  
  // Follow/Unfollow methods
  followUser(followerId: number, followingId: number): Promise<UserFollow>;
  unfollowUser(followerId: number, followingId: number): Promise<void>;
  isFollowing(followerId: number, followingId: number): Promise<boolean>;
  getFollowers(userId: number): Promise<User[]>;
  getFollowing(userId: number): Promise<User[]>;
  getFollowersCount(userId: number): Promise<number>;
  getFollowingCount(userId: number): Promise<number>;
  
  // External API methods
  createApiKey(apiKey: InsertExternalApiKey): Promise<ExternalApiKey>;
  getApiKey(keyId: string): Promise<ExternalApiKey | undefined>;
  updateApiKeyLastUsed(keyId: string): Promise<void>;
  deactivateApiKey(keyId: string): Promise<void>;
  
  // External Events methods
  createExternalEvent(event: InsertExternalEvent): Promise<ExternalEvent>;
  getExternalEvent(id: number): Promise<ExternalEvent | undefined>;
  getExternalEventByExternalId(apiKeyId: number, externalEventId: string): Promise<ExternalEvent | undefined>;
  updateExternalEventStatus(id: number, status: string): Promise<ExternalEvent>;
  getExternalEventsByApiKey(apiKeyId: number): Promise<ExternalEvent[]>;
  
  // External Tickets methods
  createExternalTicket(ticket: InsertExternalTicket): Promise<ExternalTicket>;
  getExternalTicketByQrCode(qrCode: string): Promise<ExternalTicket | undefined>;
  getExternalTicketsByEvent(externalEventId: number): Promise<ExternalTicket[]>;
  updateExternalTicketStatus(id: number, status: string): Promise<ExternalTicket>;
  markExternalTicketAsUsed(qrCode: string): Promise<ExternalTicket>;
  
  // API Audit methods
  logApiRequest(log: InsertApiAuditLog): Promise<ApiAuditLog>;
  getApiUsageStats(apiKeyId: number, hours: number): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Nettoyer les événements expirés au démarrage et toutes les heures
    this.cleanupExpiredEvents();
    setInterval(() => this.cleanupExpiredEvents(), 60 * 60 * 1000); // Chaque heure
  }

  private async cleanupExpiredEvents() {
    try {
      const today = new Date();
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      // First, find expired events
      const expiredEvents = await db.select({ id: events.id })
        .from(events)
        .where(lt(events.date, yesterdayStr));

      if (expiredEvents.length === 0) {
        return;
      }

      const eventIds = expiredEvents.map(e => e.id);

      // Delete related tickets first to avoid foreign key constraint violation
      await db.delete(tickets).where(
        sql`${tickets.eventId} IN (${sql.join(eventIds.map(id => sql`${id}`), sql`, `)})`
      );

      // Then delete the expired events
      const deletedEvents = await db.delete(events).where(
        sql`${events.id} IN (${sql.join(eventIds.map(id => sql`${id}`), sql`, `)})`
      ).returning();
      
      if (deletedEvents.length > 0) {
        console.log(`[${new Date().toISOString()}] ${deletedEvents.length} événement(s) expiré(s) supprimé(s)`);
      }
    } catch (error) {
      console.error('Erreur lors du nettoyage des événements expirés:', error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserProfile(id: number, profile: UpdateUserProfile): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getAllEvents(): Promise<Event[]> {
    return await db
      .select()
      .from(events)
      .orderBy(asc(events.date));
  }

  async getEvent(id: number): Promise<Event | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event || undefined;
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const eventData = {
      ...insertEvent,
      imageUrl: insertEvent.imageUrl || null,
      organizerPhone: insertEvent.organizerPhone || null,
      organizerWebsite: insertEvent.organizerWebsite || null,
      createdAt: new Date().toISOString()
    };
    
    const [event] = await db
      .insert(events)
      .values(eventData)
      .returning();
    return event;
  }

  async getEventsByCategory(category: string): Promise<Event[]> {
    return await db
      .select()
      .from(events)
      .where(eq(events.category, category))
      .orderBy(asc(events.date));
  }

  async searchEvents(query: string): Promise<Event[]> {
    const searchPattern = `%${query.toLowerCase()}%`;
    return await db
      .select()
      .from(events)
      .where(
        or(
          ilike(events.title, searchPattern),
          ilike(events.description, searchPattern),
          ilike(events.location, searchPattern),
          ilike(events.venue, searchPattern),
          ilike(events.organizerName, searchPattern)
        )
      )
      .orderBy(asc(events.date));
  }

  async getEventsByOrganizer(organizerEmail: string): Promise<Event[]> {
    return await db
      .select()
      .from(events)
      .where(eq(events.organizerEmail, organizerEmail))
      .orderBy(desc(events.date));
  }

  async deleteEvent(eventId: number, organizerEmail: string): Promise<void> {
    // Vérifier que l'événement appartient bien à l'organisateur
    const event = await this.getEvent(eventId);
    if (!event) {
      throw new Error("Événement non trouvé");
    }
    
    if (event.organizerEmail !== organizerEmail) {
      throw new Error("Vous n'êtes pas autorisé à supprimer cet événement");
    }
    
    // Supprimer d'abord tous les billets associés
    await db.delete(tickets).where(eq(tickets.eventId, eventId));
    
    // Supprimer l'événement
    await db.delete(events).where(eq(events.id, eventId));
  }

  // Ticket methods
  async purchaseTicket(insertTicket: InsertTicket): Promise<Ticket> {
    // Generate unique ticket code
    const ticketCode = `TECHNO-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    const [ticket] = await db
      .insert(tickets)
      .values({
        ...insertTicket,
        ticketCode,
      })
      .returning();
    
    // Update tickets sold count
    const event = await this.getEvent(insertTicket.eventId);
    if (event) {
      await db
        .update(events)
        .set({ 
          ticketsSold: (event.ticketsSold || 0) + 1 
        })
        .where(eq(events.id, insertTicket.eventId));
    }
    
    return ticket;
  }

  async getUserTickets(userId: number): Promise<Ticket[]> {
    return await db.select()
      .from(tickets)
      .where(eq(tickets.userId, userId))
      .orderBy(asc(tickets.purchaseDate));
  }

  async getEventTickets(eventId: number): Promise<Ticket[]> {
    return await db.select()
      .from(tickets)
      .where(eq(tickets.eventId, eventId))
      .orderBy(asc(tickets.purchaseDate));
  }

  async getTicketByCode(ticketCode: string): Promise<Ticket | undefined> {
    const [ticket] = await db.select()
      .from(tickets)
      .where(eq(tickets.ticketCode, ticketCode));
    return ticket;
  }

  async updateTicketStatus(ticketId: number, status: string): Promise<Ticket> {
    const [ticket] = await db
      .update(tickets)
      .set({ status })
      .where(eq(tickets.id, ticketId))
      .returning();
    return ticket;
  }

  // Community/Feed methods
  async createPost(insertPost: InsertPost): Promise<Post> {
    const [post] = await db
      .insert(posts)
      .values(insertPost)
      .returning();
    return post;
  }

  async getFeedPosts(limit: number = 20, offset: number = 0): Promise<any[]> {
    try {
      console.log("Début getFeedPosts");
      
      // Récupérer directement depuis la base avec une requête SQL simple
      const result = await db.execute(sql`
        SELECT 
          p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
          u.username, u.profile_image_url
        FROM posts p 
        LEFT JOIN users u ON p.user_id = u.id 
        ORDER BY p.created_at DESC 
        LIMIT ${limit} OFFSET ${offset}
      `);
      
      console.log("Résultats SQL:", result.rows);
      
      const postsWithAuthors = result.rows.map((row: any) => ({
        id: row.id,
        content: row.content,
        imageUrl: row.image_url,
        type: row.type,
        likesCount: row.likes_count || 0,
        commentsCount: row.comments_count || 0,
        createdAt: row.created_at,
        userId: row.user_id,
        author: {
          id: row.user_id,
          username: row.username || "Utilisateur",
          profileImageUrl: row.profile_image_url
        },
        isLiked: false,
        comments: []
      }));
      
      console.log("Posts formatés:", postsWithAuthors);
      return postsWithAuthors;
    } catch (error) {
      console.error("Erreur dans getFeedPosts:", error);
      return [];
    }
  }

  async getUserPosts(userId: number): Promise<any[]> {
    console.log(`=== getUserPosts called for user ${userId} ===`);
    
    const result = await db.execute(sql`
      SELECT 
        p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
        u.username, u.profile_image_url
      FROM posts p 
      LEFT JOIN users u ON p.user_id = u.id 
      WHERE p.user_id = ${userId}
      ORDER BY p.created_at DESC
    `);
    
    console.log("Raw user posts from DB:", result.rows);
    
    const formattedPosts = result.rows.map((row: any) => ({
      id: row.id,
      content: row.content,
      imageUrl: row.image_url,
      type: row.type,
      likesCount: row.likes_count || 0,
      commentsCount: row.comments_count || 0,
      createdAt: row.created_at,
      userId: row.user_id,
      author: {
        id: row.user_id,
        username: row.username || 'User',
        profileImageUrl: row.profile_image_url
      }
    }));
    
    console.log("Formatted user posts:", formattedPosts);
    return formattedPosts;
  }

  async likePost(postId: number, userId: number): Promise<PostLike> {
    // Vérifier si déjà liké
    const existingLike = await db.select()
      .from(postLikes)
      .where(and(eq(postLikes.postId, postId), eq(postLikes.userId, userId)));

    if (existingLike.length > 0) {
      return existingLike[0];
    }

    // Créer le like
    const [like] = await db
      .insert(postLikes)
      .values({ postId, userId })
      .returning();

    // Mettre à jour le compteur
    await db
      .update(posts)
      .set({ 
        likesCount: sql`${posts.likesCount} + 1`
      })
      .where(eq(posts.id, postId));

    return like;
  }

  async unlikePost(postId: number, userId: number): Promise<void> {
    // Supprimer le like
    await db
      .delete(postLikes)
      .where(and(eq(postLikes.postId, postId), eq(postLikes.userId, userId)));

    // Mettre à jour le compteur
    await db
      .update(posts)
      .set({ 
        likesCount: sql`${posts.likesCount} - 1`
      })
      .where(eq(posts.id, postId));
  }

  async isPostLiked(postId: number, userId: number): Promise<boolean> {
    const likes = await db.select()
      .from(postLikes)
      .where(and(eq(postLikes.postId, postId), eq(postLikes.userId, userId)));
    return likes.length > 0;
  }

  async repostPost(originalPostId: number, userId: number, content?: string): Promise<Post> {
    const [repost] = await db
      .insert(posts)
      .values({
        userId,
        content: content || "",
        isRepost: "true",
        originalPostId,
        type: "text"
      })
      .returning();

    // Mettre à jour le compteur de reposts du post original
    await db
      .update(posts)
      .set({ 
        repostsCount: sql`${posts.repostsCount} + 1`
      })
      .where(eq(posts.id, originalPostId));

    return repost;
  }

  async addComment(insertComment: InsertPostComment): Promise<PostComment> {
    const [comment] = await db
      .insert(postComments)
      .values(insertComment)
      .returning();

    // Mettre à jour le compteur de commentaires
    await db
      .update(posts)
      .set({ 
        commentsCount: sql`${posts.commentsCount} + 1`
      })
      .where(eq(posts.id, insertComment.postId));

    return comment;
  }

  async getPostComments(postId: number): Promise<PostComment[]> {
    return await db.select()
      .from(postComments)
      .where(eq(postComments.postId, postId))
      .orderBy(asc(postComments.createdAt));
  }

  async deletePost(postId: number, userId: number): Promise<void> {
    // Vérifier que l'utilisateur est propriétaire du post
    const [post] = await db.select()
      .from(posts)
      .where(and(eq(posts.id, postId), eq(posts.userId, userId)));

    if (!post) {
      throw new Error("Post non trouvé ou accès non autorisé");
    }

    // Supprimer les likes, commentaires et le post
    await db.delete(postLikes).where(eq(postLikes.postId, postId));
    await db.delete(postComments).where(eq(postComments.postId, postId));
    await db.delete(posts).where(eq(posts.id, postId));
  }

  // Organizer Payout methods
  async createOrganizerPayout(insertPayout: InsertOrganizerPayout): Promise<OrganizerPayout> {
    const [payout] = await db
      .insert(organizerPayouts)
      .values(insertPayout)
      .returning();
    return payout;
  }

  async getPendingPayouts(): Promise<OrganizerPayout[]> {
    return await db
      .select()
      .from(organizerPayouts)
      .where(eq(organizerPayouts.status, 'pending'))
      .orderBy(asc(organizerPayouts.createdAt));
  }

  async updatePayoutStatus(payoutId: number, status: string, stripeTransferId?: string): Promise<OrganizerPayout> {
    const updateData: any = { status };
    if (stripeTransferId) {
      updateData.stripeTransferId = stripeTransferId;
    }

    const [payout] = await db
      .update(organizerPayouts)
      .set(updateData)
      .where(eq(organizerPayouts.id, payoutId))
      .returning();
    return payout;
  }

  async getOrganizerPayouts(organizerEmail: string): Promise<OrganizerPayout[]> {
    return await db
      .select()
      .from(organizerPayouts)
      .where(eq(organizerPayouts.organizerEmail, organizerEmail))
      .orderBy(desc(organizerPayouts.createdAt));
  }

  // Organizer Webhook methods
  async createOrganizerWebhook(insertWebhook: InsertOrganizerWebhook): Promise<OrganizerWebhook> {
    const [webhook] = await db
      .insert(organizerWebhooks)
      .values(insertWebhook)
      .returning();
    return webhook;
  }

  async getPendingWebhooks(): Promise<OrganizerWebhook[]> {
    return await db
      .select()
      .from(organizerWebhooks)
      .where(eq(organizerWebhooks.status, "pending"));
  }

  async updateWebhookStatus(
    webhookId: number, 
    status: string, 
    responseStatus?: number, 
    errorMessage?: string
  ): Promise<OrganizerWebhook> {
    const [webhook] = await db
      .update(organizerWebhooks)
      .set({
        status,
        responseStatus,
        errorMessage,
        lastAttempt: new Date(),
        attempts: sql`${organizerWebhooks.attempts} + 1`,
      })
      .where(eq(organizerWebhooks.id, webhookId))
      .returning();
    return webhook;
  }

  async getEventWebhooks(eventId: number): Promise<OrganizerWebhook[]> {
    return await db
      .select()
      .from(organizerWebhooks)
      .where(eq(organizerWebhooks.eventId, eventId));
  }

  // **Méthodes pour les messages privés**
  
  async sendMessage(insertMessage: InsertPrivateMessage): Promise<PrivateMessage> {
    const [message] = await db
      .insert(privateMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async getConversations(userId: number): Promise<any[]> {
    // Récupérer toutes les conversations où l'utilisateur est soit expéditeur soit destinataire
    const conversations = await db
      .select({
        otherUserId: sql<number>`CASE 
          WHEN ${privateMessages.senderId} = ${userId} THEN ${privateMessages.receiverId}
          ELSE ${privateMessages.senderId}
        END`,
        otherUsername: users.username,
        otherProfileImageUrl: users.profileImageUrl,
        lastMessage: privateMessages.content,
        lastMessageDate: privateMessages.createdAt,
        isRead: privateMessages.isRead,
        isFromMe: sql<boolean>`${privateMessages.senderId} = ${userId}`
      })
      .from(privateMessages)
      .innerJoin(users, sql`${users.id} = CASE 
        WHEN ${privateMessages.senderId} = ${userId} THEN ${privateMessages.receiverId}
        ELSE ${privateMessages.senderId}
      END`)
      .where(or(
        eq(privateMessages.senderId, userId),
        eq(privateMessages.receiverId, userId)
      ))
      .orderBy(desc(privateMessages.createdAt));

    // Grouper par utilisateur et garder seulement le message le plus récent
    const conversationMap = new Map();
    for (const conv of conversations) {
      if (!conversationMap.has(conv.otherUserId)) {
        conversationMap.set(conv.otherUserId, conv);
      }
    }

    return Array.from(conversationMap.values());
  }

  async getConversationMessages(userId: number, otherUserId: number): Promise<any[]> {
    const messages = await db
      .select({
        id: privateMessages.id,
        content: privateMessages.content,
        senderId: privateMessages.senderId,
        receiverId: privateMessages.receiverId,
        isRead: privateMessages.isRead,
        createdAt: privateMessages.createdAt,
        senderUsername: users.username,
        senderProfileImageUrl: users.profileImageUrl
      })
      .from(privateMessages)
      .innerJoin(users, eq(users.id, privateMessages.senderId))
      .where(
        or(
          and(
            eq(privateMessages.senderId, userId),
            eq(privateMessages.receiverId, otherUserId)
          ),
          and(
            eq(privateMessages.senderId, otherUserId),
            eq(privateMessages.receiverId, userId)
          )
        )
      )
      .orderBy(asc(privateMessages.createdAt));

    return messages;
  }

  async markMessagesAsRead(userId: number, otherUserId: number): Promise<void> {
    await db
      .update(privateMessages)
      .set({ isRead: 1 })
      .where(
        and(
          eq(privateMessages.senderId, otherUserId),
          eq(privateMessages.receiverId, userId),
          eq(privateMessages.isRead, 0)
        )
      );
  }

  async followUser(followerId: number, followingId: number): Promise<UserFollow> {
    const [follow] = await db
      .insert(userFollows)
      .values({
        followerId,
        followingId,
      })
      .returning();
    return follow;
  }

  async unfollowUser(followerId: number, followingId: number): Promise<void> {
    await db
      .delete(userFollows)
      .where(
        and(
          eq(userFollows.followerId, followerId),
          eq(userFollows.followingId, followingId)
        )
      );
  }

  async isFollowing(followerId: number, followingId: number): Promise<boolean> {
    const [follow] = await db
      .select()
      .from(userFollows)
      .where(
        and(
          eq(userFollows.followerId, followerId),
          eq(userFollows.followingId, followingId)
        )
      );
    return !!follow;
  }

  async getFollowers(userId: number): Promise<User[]> {
    const followers = await db
      .select({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        profileImageUrl: users.profileImageUrl,
        bio: users.bio,
        city: users.city,
        country: users.country,
        website: users.website,
        email: users.email,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
      })
      .from(userFollows)
      .innerJoin(users, eq(userFollows.followerId, users.id))
      .where(eq(userFollows.followingId, userId));
    
    return followers;
  }

  async getFollowing(userId: number): Promise<User[]> {
    const following = await db
      .select({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        profileImageUrl: users.profileImageUrl,
        bio: users.bio,
        city: users.city,
        country: users.country,
        website: users.website,
        email: users.email,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
      })
      .from(userFollows)
      .innerJoin(users, eq(userFollows.followingId, users.id))
      .where(eq(userFollows.followerId, userId));
    
    return following;
  }

  async getFollowersCount(userId: number): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(userFollows)
      .where(eq(userFollows.followingId, userId));
    
    return result?.count || 0;
  }

  async getFollowingCount(userId: number): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(userFollows)
      .where(eq(userFollows.followerId, userId));
    
    return result?.count || 0;
  }

  // External API methods
  async createApiKey(insertApiKey: InsertExternalApiKey): Promise<ExternalApiKey> {
    const [apiKey] = await db
      .insert(externalApiKeys)
      .values(insertApiKey)
      .returning();
    return apiKey;
  }

  async getApiKey(keyId: string): Promise<ExternalApiKey | undefined> {
    const [apiKey] = await db
      .select()
      .from(externalApiKeys)
      .where(and(eq(externalApiKeys.keyId, keyId), eq(externalApiKeys.isActive, true)));
    return apiKey;
  }

  async updateApiKeyLastUsed(keyId: string): Promise<void> {
    await db
      .update(externalApiKeys)
      .set({ lastUsed: new Date() })
      .where(eq(externalApiKeys.keyId, keyId));
  }

  async deactivateApiKey(keyId: string): Promise<void> {
    await db
      .update(externalApiKeys)
      .set({ isActive: false })
      .where(eq(externalApiKeys.keyId, keyId));
  }

  // External Events methods
  async createExternalEvent(insertEvent: InsertExternalEvent): Promise<ExternalEvent> {
    const [event] = await db
      .insert(externalEvents)
      .values(insertEvent)
      .returning();
    return event;
  }

  async getExternalEvent(id: number): Promise<ExternalEvent | undefined> {
    const [event] = await db
      .select()
      .from(externalEvents)
      .where(eq(externalEvents.id, id));
    return event;
  }

  async getExternalEventByExternalId(apiKeyId: number, externalEventId: string): Promise<ExternalEvent | undefined> {
    const [event] = await db
      .select()
      .from(externalEvents)
      .where(and(
        eq(externalEvents.apiKeyId, apiKeyId),
        eq(externalEvents.externalEventId, externalEventId)
      ));
    return event;
  }

  async updateExternalEventStatus(id: number, status: string): Promise<ExternalEvent> {
    const [event] = await db
      .update(externalEvents)
      .set({ status })
      .where(eq(externalEvents.id, id))
      .returning();
    return event;
  }

  async getExternalEventsByApiKey(apiKeyId: number): Promise<ExternalEvent[]> {
    return await db
      .select()
      .from(externalEvents)
      .where(eq(externalEvents.apiKeyId, apiKeyId))
      .orderBy(desc(externalEvents.createdAt));
  }

  // External Tickets methods
  async createExternalTicket(insertTicket: InsertExternalTicket): Promise<ExternalTicket> {
    const [ticket] = await db
      .insert(externalTickets)
      .values(insertTicket)
      .returning();
    return ticket;
  }

  async getExternalTicketByQrCode(qrCode: string): Promise<ExternalTicket | undefined> {
    const [ticket] = await db
      .select()
      .from(externalTickets)
      .where(eq(externalTickets.qrCode, qrCode));
    return ticket;
  }

  async getExternalTicketsByEvent(externalEventId: number): Promise<ExternalTicket[]> {
    return await db
      .select()
      .from(externalTickets)
      .where(eq(externalTickets.externalEventId, externalEventId))
      .orderBy(desc(externalTickets.createdAt));
  }

  async updateExternalTicketStatus(id: number, status: string): Promise<ExternalTicket> {
    const [ticket] = await db
      .update(externalTickets)
      .set({ status })
      .where(eq(externalTickets.id, id))
      .returning();
    return ticket;
  }

  async markExternalTicketAsUsed(qrCode: string): Promise<ExternalTicket> {
    const [ticket] = await db
      .update(externalTickets)
      .set({ 
        status: "used",
        usedAt: new Date()
      })
      .where(eq(externalTickets.qrCode, qrCode))
      .returning();
    return ticket;
  }

  // API Audit methods
  async logApiRequest(insertLog: InsertApiAuditLog): Promise<ApiAuditLog> {
    const [log] = await db
      .insert(apiAuditLog)
      .values(insertLog)
      .returning();
    return log;
  }

  async getApiUsageStats(apiKeyId: number, hours: number): Promise<number> {
    const hoursAgo = new Date(Date.now() - hours * 60 * 60 * 1000);
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(apiAuditLog)
      .where(and(
        eq(apiAuditLog.apiKeyId, apiKeyId),
        sql`${apiAuditLog.createdAt} >= ${hoursAgo}`
      ));
    return result.count;
  }
}

export const storage = new DatabaseStorage();
