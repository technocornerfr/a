// Exemple de test de l'API externe pour billetteries tierces
// Ce script démontre comment une billetterie externe peut intégrer avec TechnoCorner

const API_BASE_URL = 'https://042ac814-906e-4942-9d60-8182b8115ae8-00-ggkr9lhbmbgb.picard.replit.dev';

// Fonction pour générer une clé API de test
async function generateTestApiKey() {
  try {
    // Simulation de génération de clé API (normalement fait par l'admin)
    const testApiKey = {
      keyId: 'tk_demo123456789abcdef',
      keySecret: 'demo_secret_key_for_testing_purposes_only'
    };
    
    console.log('🔑 Clé API de démonstration générée:');
    console.log('Key ID:', testApiKey.keyId);
    console.log('Key Secret:', testApiKey.keySecret);
    console.log('Token:', `${testApiKey.keyId}:${testApiKey.keySecret}`);
    
    return testApiKey;
  } catch (error) {
    console.error('Erreur génération clé API:', error);
    return null;
  }
}

// Test 1: Créer un événement externe
async function testCreateExternalEvent(apiKey) {
  console.log('\n📅 Test 1: Création d\'un événement externe...');
  
  const eventData = {
    externalEventId: 'demo_event_001',
    title: 'Soirée Techno Integration Test',
    description: 'Test d\'intégration avec l\'API externe TechnoCorner',
    date: '2024-12-31',
    time: '23:00',
    venue: 'Club Test',
    location: 'Paris, France',
    maxTickets: 100
  };
  
  try {
    const response = await fetch(`${API_BASE_URL}/api/external/events`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey.keyId}:${apiKey.keySecret}`
      },
      body: JSON.stringify(eventData)
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('✅ Événement créé avec succès:', result);
      return result.event;
    } else {
      const error = await response.json();
      console.log('❌ Erreur création événement:', error);
      return null;
    }
  } catch (error) {
    console.error('❌ Erreur requête:', error.message);
    return null;
  }
}

// Test 2: Générer un QR code de billet
async function testGenerateTicket(apiKey, externalEventId) {
  console.log('\n🎫 Test 2: Génération d\'un QR code de billet...');
  
  const ticketData = {
    externalEventId: externalEventId,
    externalTicketId: 'ticket_demo_001',
    buyerName: 'Jean Testeur',
    buyerEmail: 'jean.testeur@email.com',
    ticketType: 'Standard',
    price: '25€'
  };
  
  try {
    const response = await fetch(`${API_BASE_URL}/api/external/tickets/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey.keyId}:${apiKey.keySecret}`
      },
      body: JSON.stringify(ticketData)
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('✅ QR code généré avec succès:');
      console.log('QR Code:', result.ticket.qrCode);
      console.log('Status:', result.ticket.status);
      return result.ticket;
    } else {
      const error = await response.json();
      console.log('❌ Erreur génération QR code:', error);
      return null;
    }
  } catch (error) {
    console.error('❌ Erreur requête:', error.message);
    return null;
  }
}

// Test 3: Valider un QR code
async function testValidateTicket(apiKey, qrCode) {
  console.log('\n🔍 Test 3: Validation d\'un QR code...');
  
  try {
    const response = await fetch(`${API_BASE_URL}/api/external/tickets/validate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey.keyId}:${apiKey.keySecret}`
      },
      body: JSON.stringify({ qrCode })
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('✅ Validation effectuée:');
      console.log('Valide:', result.valid);
      if (result.valid) {
        console.log('Acheteur:', result.ticket.buyerName);
        console.log('Type:', result.ticket.ticketType);
        console.log('Validé à:', result.ticket.validatedAt);
      } else {
        console.log('Erreur:', result.error);
      }
      return result;
    } else {
      const error = await response.json();
      console.log('❌ Erreur validation:', error);
      return null;
    }
  } catch (error) {
    console.error('❌ Erreur requête:', error.message);
    return null;
  }
}

// Test 4: Récupérer les statistiques
async function testGetEventStats(apiKey, externalEventId) {
  console.log('\n📊 Test 4: Récupération des statistiques...');
  
  try {
    const response = await fetch(`${API_BASE_URL}/api/external/events/${externalEventId}/stats`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${apiKey.keyId}:${apiKey.keySecret}`
      }
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('✅ Statistiques récupérées:');
      console.log('Événement:', result.event.title);
      console.log('Total billets:', result.stats.totalTickets);
      console.log('Billets valides:', result.stats.validTickets);
      console.log('Billets utilisés:', result.stats.usedTickets);
      return result;
    } else {
      const error = await response.json();
      console.log('❌ Erreur statistiques:', error);
      return null;
    }
  } catch (error) {
    console.error('❌ Erreur requête:', error.message);
    return null;
  }
}

// Workflow complet de test
async function runFullTest() {
  console.log('🚀 Démarrage des tests d\'intégration API externe\n');
  
  // Étape 1: Générer une clé API de test
  const apiKey = await generateTestApiKey();
  if (!apiKey) {
    console.log('❌ Impossible de générer la clé API de test');
    return;
  }
  
  // Étape 2: Créer un événement
  const event = await testCreateExternalEvent(apiKey);
  if (!event) {
    console.log('❌ Impossible de créer l\'événement, arrêt des tests');
    return;
  }
  
  // Étape 3: Générer un billet
  const ticket = await testGenerateTicket(apiKey, event.externalEventId);
  if (!ticket) {
    console.log('❌ Impossible de générer le billet, arrêt des tests');
    return;
  }
  
  // Étape 4: Valider le billet
  const validation = await testValidateTicket(apiKey, ticket.qrCode);
  if (!validation) {
    console.log('❌ Impossible de valider le billet');
    return;
  }
  
  // Étape 5: Récupérer les statistiques
  await testGetEventStats(apiKey, event.externalEventId);
  
  console.log('\n🎉 Tests d\'intégration terminés avec succès!');
  console.log('\n📋 Résumé du workflow:');
  console.log('1. ✅ Clé API générée');
  console.log('2. ✅ Événement externe créé');
  console.log('3. ✅ QR code de billet généré');
  console.log('4. ✅ QR code validé à l\'entrée');
  console.log('5. ✅ Statistiques récupérées');
}

// Exporter les fonctions pour usage externe
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    generateTestApiKey,
    testCreateExternalEvent,
    testGenerateTicket,
    testValidateTicket,
    testGetEventStats,
    runFullTest
  };
}

// Exécuter les tests si appelé directement
if (typeof window === 'undefined' && require.main === module) {
  runFullTest().catch(console.error);
}