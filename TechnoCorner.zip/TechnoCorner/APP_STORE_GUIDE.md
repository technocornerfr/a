# Guide de Publication TechnoCorner sur les App Stores

## 📱 Configuration Capacitor Terminée

✅ **Capacitor initialisé** avec les configurations :
- App ID: `com.technocorner.app`
- App Name: `TechnoCorner`
- Plateformes Android et iOS ajoutées
- Plugins configurés (SplashScreen, StatusBar)

---

## 🚀 Étapes de Publication

### **1. Build de l'Application**

```bash
# 1. Construire la version web
npm run build

# 2. Synchroniser avec les plateformes natives
npx cap sync

# 3. Construire pour Android
npx cap build android

# 4. Construire pour iOS (sur macOS uniquement)
npx cap build ios
```

### **2. Publication Android (Google Play Store)**

#### **Prérequis :**
- Compte développeur Google Play (25$ une fois)
- Android Studio installé
- Clé de signature générée

#### **Étapes :**
1. **Ouvrir le projet Android :**
   ```bash
   npx cap open android
   ```

2. **Dans Android Studio :**
   - Générer un APK signé : `Build → Generate Signed Bundle/APK`
   - Choisir "Android App Bundle" (recommandé)
   - Créer une nouvelle clé de signature si nécessaire

3. **Google Play Console :**
   - Créer une nouvelle application
   - Uploader l'AAB (Android App Bundle)
   - Remplir les métadonnées requises

#### **Métadonnées requises :**
- **Titre :** TechnoCorner
- **Description courte :** Plateforme sociale pour événements techno
- **Description complète :** Découvrez, partagez et vivez la scène techno avec TechnoCorner. Trouvez des événements, connectez-vous avec la communauté et scannez vos billets.
- **Catégorie :** Musique et audio
- **Screenshots :** 2-8 captures d'écran (1080x1920px)
- **Icône :** 512x512px (déjà créée)

### **3. Publication iOS (App Store)**

#### **Prérequis :**
- Compte développeur Apple (99€/an)
- macOS avec Xcode
- Certificats de développement

#### **Étapes :**
1. **Ouvrir le projet iOS :**
   ```bash
   npx cap open ios
   ```

2. **Dans Xcode :**
   - Configurer les identifiants et certificats
   - Archiver l'application : `Product → Archive`
   - Distribuer via App Store Connect

3. **App Store Connect :**
   - Créer une nouvelle app
   - Uploader le build via Xcode
   - Remplir les métadonnées
   - Soumettre pour révision

#### **Métadonnées requises :**
- **Nom :** TechnoCorner
- **Sous-titre :** Événements Techno & Communauté
- **Mots-clés :** techno,événements,musique,communauté,billets
- **Description :** Même que Android
- **Catégorie :** Musique
- **Screenshots :** iPhone et iPad si supporté

---

## 🎨 Assets Requis

### **Icônes d'Application :**
- **Android :** Multiple tailles générées automatiquement
- **iOS :** Multiple tailles requises (déjà configurées via Capacitor)

### **Screenshots Recommandés :**
1. Page d'accueil avec événements
2. Page communauté avec posts
3. Scanner de billets en action
4. Profil utilisateur
5. Détail d'un événement

### **Captures d'Écran Optimal :**
- **Android :** 1080x1920px, 1080x2340px
- **iOS :** 1290x2796px (iPhone 14 Pro), 2048x2732px (iPad)

---

## ⚙️ Configuration Finale

### **Permissions Required :**
```xml
<!-- Android (android/app/src/main/AndroidManifest.xml) -->
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
```

### **URLs et Deep Links :**
- **Android :** `com.technocorner.app`
- **iOS :** `technocorner://`

---

## 🚨 Points Importants

### **Avant Publication :**
1. **Tester sur vrais appareils** avec `npx cap run android/ios`
2. **Vérifier toutes les fonctionnalités** (scanner, notifications, etc.)
3. **Optimiser les performances** et temps de chargement
4. **Respecter les guidelines** des stores

### **Délais Prévus :**
- **Android :** 1-3 jours de révision
- **iOS :** 1-7 jours de révision

### **Coûts :**
- **Google Play :** 25$ une fois
- **Apple Store :** 99€/an

---

## 🔧 Commandes Utiles

```bash
# Synchroniser les changements
npx cap sync

# Ouvrir Android Studio
npx cap open android

# Ouvrir Xcode (macOS uniquement)
npx cap open ios

# Lancer sur appareil connecté
npx cap run android
npx cap run ios

# Copier les assets
npx cap copy

# Vérifier la configuration
npx cap doctor
```

---

## 📋 Checklist Publication

### **Pré-publication :**
- [ ] Build web fonctionnel
- [ ] Tests sur appareils réels
- [ ] Screenshots haute qualité
- [ ] Description marketing
- [ ] Politique de confidentialité
- [ ] Conditions d'utilisation

### **Android :**
- [ ] APK/AAB généré et signé
- [ ] Console Google Play configurée
- [ ] Métadonnées complètes
- [ ] Version de test déployée

### **iOS :**
- [ ] Archive Xcode créée
- [ ] App Store Connect configuré
- [ ] Certificats valides
- [ ] Soumission effectuée

---

## 🎯 Prochaines Étapes

1. **Construire la version finale :** `npm run build`
2. **Tester sur un appareil Android/iOS**
3. **Créer les comptes développeur**
4. **Préparer les assets marketing**
5. **Soumettre aux stores**

L'application est maintenant prête pour la publication sur les deux stores !