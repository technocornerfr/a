# Guide de sélection d'appareil iOS dans Xcode

## Problème : "No supported iOS devices are available"

Cette erreur apparaît quand Xcode ne trouve pas de simulateur iOS sélectionné pour exécuter votre app.

## Solution étape par étape

### 1. Localiser le sélecteur d'appareil

Dans Xcode, regardez en haut de l'écran :
- **Barre d'outils principale** (juste en dessous de la barre de menus)
- Vous verrez : `[App] > [Aucun appareil sélectionné]`
- C'est une zone cliquable avec une flèche vers le bas

### 2. Cliquer sur le sélecteur d'appareil

**Localisation exacte :**
```
[Bouton Play] [App ▼] [No Device Selected ▼] [Scheme]
                      👆 CLIQUEZ ICI
```

### 3. Sélectionner un simulateur iOS

Quand vous cliquez, un menu déroulant s'ouvre avec :

**Section "iOS Simulators" :**
- iPhone 15 Pro (recommandé)
- iPhone 15
- iPhone 14 Pro
- iPhone SE (3rd generation)
- iPad Air (5th generation)

**Choisissez :** `iPhone 15 Pro` ou `iPhone 15`

### 4. Installation automatique des simulateurs

Si aucun simulateur n'apparaît :

**Option A - Via Xcode :**
1. Menu `Xcode` → `Preferences` → `Components`
2. Onglet `Simulators`
3. Télécharger `iOS 17.x Simulator`

**Option B - Via ligne de commande :**
```bash
# Lister les simulateurs disponibles
xcrun simctl list devicetypes

# Installer iOS 17 Simulator si absent
xcode-select --install
```

### 5. Vérification de la sélection

Après sélection, vous devriez voir :
```
[Bouton Play] [App] [iPhone 15 Pro] [Debug]
```

### 6. Test de l'application

1. **Cliquez le bouton Play** (▶️) en haut à gauche
2. Le simulateur iOS se lance automatiquement
3. Votre app TechnoCorner s'installe et s'ouvre

### 7. Résolution des problèmes courants

**Si le simulateur ne s'ouvre pas :**
```bash
# Redémarrer Simulator
pkill Simulator
open -a Simulator
```

**Si erreur de provisioning :**
1. Projet → General → Signing & Capabilities
2. Cocher "Automatically manage signing"
3. Sélectionner votre Team Apple Developer

**Si erreur de build :**
1. Menu Product → Clean Build Folder
2. Fermer et rouvrir Xcode
3. Relancer le build

### 8. Interface du sélecteur d'appareil (description détaillée)

**Position dans Xcode :**
- **Barre d'outils principale** (2ème ligne depuis le haut)
- **Entre le bouton Play et les informations de build**
- **Largeur approximative : 200-300px**
- **Texte affiché :** "No Device Selected" ou nom de l'appareil

**Apparence visuelle :**
- Fond gris clair/sombre selon le thème
- Texte noir/blanc
- Petite flèche ▼ à droite
- Bordure subtile

## Raccourcis clavier utiles

- **Cmd+R** : Lancer l'app (équivalent au bouton Play)
- **Cmd+Shift+K** : Clean build folder
- **Cmd+B** : Build seulement (sans lancer)

## Test complet de TechnoCorner

Une fois le simulateur sélectionné et l'app lancée, vous pourrez tester :

✅ **Navigation** entre toutes les pages
✅ **Communauté** : posts, likes, commentaires  
✅ **Événements** : création, billets, checkout
✅ **Messages** : conversations en temps réel
✅ **Scanner QR** : simulation de scan billets
✅ **Authentification** : login/signup
✅ **Profile** : gestion utilisateur

Votre application TechnoCorner complète sera maintenant accessible sur iOS !