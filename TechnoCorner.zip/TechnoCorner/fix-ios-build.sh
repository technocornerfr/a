#!/bin/bash

echo "🔧 Correction des erreurs de build iOS TechnoCorner"
echo "================================================="

# Étape 1: Nettoyer les builds précédentes
echo "1. Nettoyage des builds précédentes..."
rm -rf ios/App/build
rm -rf ios/App/App/public/static 2>/dev/null

# Étape 2: Créer la structure de fichiers correcte
echo "2. Préparation de la structure de fichiers..."
mkdir -p ios/App/App/public/src
mkdir -p ios/App/App/public/assets

# Étape 3: Copier l'application React complète
echo "3. Copie de l'application TechnoCorner..."
cp -r client/src/* ios/App/App/public/src/
cp -r client/public/* ios/App/App/public/ 2>/dev/null || true
cp -r public/* ios/App/App/public/ 2>/dev/null || true

# Étape 4: Copier les assets nécessaires
echo "4. Copie des assets..."
cp afterlife-party-image.svg ios/App/App/public/ 2>/dev/null || true
cp generated-icon.png ios/App/App/public/ 2>/dev/null || true

# Étape 5: Vérifier les dépendances CocoaPods
echo "5. Mise à jour des dépendances iOS..."
cd ios/App
if command -v pod &> /dev/null; then
    echo "   - Installation des pods..."
    pod install --repo-update 2>/dev/null || pod install 2>/dev/null || echo "   - Pods déjà à jour"
else
    echo "   - CocoaPods non installé, ignoré"
fi

cd ../..

# Étape 6: Vérifier la configuration Capacitor
echo "6. Vérification de la configuration Capacitor..."
if [ -f "ios/App/App/capacitor.config.json" ]; then
    echo "   ✓ Configuration Capacitor présente"
else
    echo "   ⚠ Configuration Capacitor manquante"
fi

# Étape 7: Validation des fichiers critiques
echo "7. Validation des fichiers critiques..."
critical_files=(
    "ios/App/App/public/index.html"
    "ios/App/App/public/src/main.tsx"
    "ios/App/App/public/src/App.tsx"
    "ios/App/App/Info.plist"
)

for file in "${critical_files[@]}"; do
    if [ -f "$file" ]; then
        echo "   ✓ $file"
    else
        echo "   ✗ $file manquant"
    fi
done

# Étape 8: Afficher les instructions finales
echo ""
echo "🎯 Instructions pour Xcode:"
echo "=========================="
echo "1. Ouvrir: cd ios/App && open App.xcworkspace"
echo "2. Sélectionner un simulateur: iPhone 15 Pro"
echo "3. Configurer signing: Project → General → Signing"
echo "4. Build: Cmd+B puis Cmd+R"
echo ""
echo "📱 Votre app TechnoCorner est prête pour iOS!"
echo "   - 30+ pages React intégrées"
echo "   - Communauté, événements, messages"
echo "   - Scanner QR, authentification"
echo "   - Interface Nintendo-style optimisée"

# Afficher la structure finale
echo ""
echo "📁 Structure finale:"
ls -la ios/App/App/public/ | head -10