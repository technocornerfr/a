import sgMail from '@sendgrid/mail';

// Test direct avec la clé API
const API_KEY = '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';
sgMail.setApiKey(API_KEY);

async function testDirectSendGrid() {
  try {
    console.log('Test direct SendGrid avec adresse vérifiée...');
    
    const msg = {
      to: 'growthfabriqueparis@gmail.com',
      from: 'growthfabriqueparis@gmail.com',
      subject: 'Test TechnoCorner - Billet de test',
      text: 'Test d\'envoi direct depuis TechnoCorner',
      html: `
        <div style="font-family: Arial, sans-serif;">
          <h2>Test TechnoCorner</h2>
          <p>Si vous recevez cet email, SendGrid fonctionne correctement avec votre adresse vérifiée.</p>
          <p>Code de test: TEST-${Date.now()}</p>
        </div>
      `
    };

    const response = await sgMail.send(msg);
    console.log('SUCCESS! Email envoyé');
    console.log('Status Code:', response[0].statusCode);
    console.log('Headers:', response[0].headers);
    return true;
    
  } catch (error) {
    console.log('ERREUR SendGrid:');
    console.log('Code:', error.code);
    console.log('Message:', error.message);
    
    if (error.response) {
      console.log('Response Status:', error.response.status);
      console.log('Response Body:', JSON.stringify(error.response.body, null, 2));
    }
    
    return false;
  }
}

testDirectSendGrid();