# Guide Détaillé Xcode : Configuration Complète pour TechnoCorner

## Vue d'ensemble de Xcode

Xcode est l'environnement de développement d'Apple pour créer des applications iOS, macOS, watchOS et tvOS. Pour TechnoCorner, nous l'utilisons pour transformer votre application web en application iOS native.

---

## PARTIE 1 : Interface et Navigation Xcode (15 minutes)

### 1.1 Ouverture et première impression

Quand vous lancez `npx cap open ios`, Xcode s'ouvre avec votre projet. Voici ce que vous voyez :

**Interface principale de Xcode :**
```
┌─────────────────────────────────────────────────────────────┐
│ [Fichier] [Édition] [Affichage] [Product] [Debug] [Window]  │ ← Menu principal
├─────────────────────────────────────────────────────────────┤
│ ◀ ▶ ⏸ ■   [TechnoCorner] ▼ [iPhone 15 Pro] ▼   [Build] ▶  │ ← Barre d'outils
├─────────────┬───────────────────────────────┬───────────────┤
│             │                               │               │
│   Navigator │        Zone principale        │   Inspector   │ ← 3 zones principales
│             │                               │               │
│   (gauche)  │          (centre)            │   (droite)    │
│             │                               │               │
└─────────────┴───────────────────────────────┴───────────────┘
```

### 1.2 Zone Navigator (Barre latérale gauche)

**Si la barre latérale n'est pas visible :**
1. **Menu View → Navigators → Show Project Navigator**
2. **Ou raccourci clavier : Cmd+1**
3. **Ou clic sur l'icône dossier** en haut à gauche

**Structure du projet TechnoCorner :**
```
📁 App (← CLIQUEZ ICI - C'est le projet principal)
  📁 App (sous-dossier)
    📁 public (fichiers web de Capacitor)
      📄 index.html (votre application TechnoCorner)
      📄 capacitor.config.json
      📄 ...autres fichiers web
    📄 AppDelegate.swift (démarrage de l'app iOS)
    📄 SceneDelegate.swift (gestion des scènes)
    📄 ViewController.swift (contrôleur principal)
    📄 Info.plist (configuration de l'app)
    📁 Assets.xcassets (icônes et images)
  📁 Pods (librairies externes - Capacitor)
    📁 Capacitor
    📁 CapacitorCordova
    📄 ...autres dépendances
  🔨 Products (fichiers compilés)
    📱 App.app (votre application finale)
```

**ACTION PRÉCISE :** Cliquez sur **"App"** (le premier élément avec l'icône de dossier bleu). PAS sur le sous-dossier "App", mais bien sur l'élément racine.

### 1.3 Zone principale (Centre)

Une fois que vous avez cliqué sur "App" dans le Navigator, la zone centrale affiche :

**Onglets de configuration :**
```
┌─────────────────────────────────────────────────────────┐
│ General │ Signing & Capabilities │ Resource Tags │ ... │ ← Onglets
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📱 TechnoCorner                                       │ ← Nom du projet
│                                                         │
│  Identity                                              │ ← Section Identity
│  ├ Display Name: [TechnoCorner          ]             │
│  ├ Bundle Identifier: [com.votrenom.technocorner]     │
│  ├ Version: [1.0.0]                                   │
│  └ Build: [1]                                         │
│                                                         │
│  Deployment Info                                       │ ← Section Deployment
│  ├ Minimum Deployment Target: [iOS 13.0]              │
│  ├ Device Orientation: ☑ Portrait ☐ Landscape        │
│  └ Status Bar Style: [Default]                        │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 1.4 Zone Inspector (Droite)

Cette zone affiche des informations contextuelles sur l'élément sélectionné. Pour l'instant, nous ne l'utiliserons pas pour la configuration principale.

---

## PARTIE 2 : Configuration Identity (Onglet General)

### 2.1 Section Identity - Explication détaillée

**Display Name :**
- **Ce que c'est :** Le nom affiché sous l'icône de l'app sur l'écran d'accueil iPhone
- **Exemple :** "TechnoCorner"
- **Important :** Maximum 12-15 caractères pour l'affichage optimal

**Bundle Identifier :**
- **Ce que c'est :** Identifiant unique mondial de votre application
- **Format :** Reverse DNS (com.entreprise.nomapp)
- **Exemple :** `com.johndoe.technocorner`
- **Règles :**
  - Doit être unique au monde
  - Pas d'espaces, accents, ou caractères spéciaux
  - Uniquement lettres, chiffres, points, tirets
  - Une fois sur App Store, ne peut plus être changé

**Version :**
- **Ce que c'est :** Numéro de version visible par les utilisateurs
- **Format :** Majeure.Mineure.Correction (ex: 1.0.0)
- **Exemple :** 1.0.0 pour la première version

**Build :**
- **Ce que c'est :** Numéro interne de build pour Apple
- **Format :** Nombre entier croissant
- **Exemple :** 1, 2, 3, 4...
- **Usage :** Incrémenté à chaque upload vers App Store

### 2.2 Configuration étape par étape

**Étape 1 : Display Name**
1. **Cliquez dans le champ "Display Name"**
2. **Effacez le contenu existant** (probablement "App")
3. **Tapez : "TechnoCorner"**
4. **Appuyez sur Entrée**

**Étape 2 : Bundle Identifier**
1. **Cliquez dans le champ "Bundle Identifier"**
2. **Remplacez par votre identifiant unique :**
   - Si votre nom est Jean Dupont : `com.jeandupont.technocorner`
   - Si vous avez une entreprise : `com.votreentreprise.technocorner`
   - Si c'est personnel : `com.votrenom.technocorner`
3. **Appuyez sur Entrée**

**Étape 3 : Version et Build**
1. **Version :** Laissez "1.0.0"
2. **Build :** Laissez "1"

### 2.3 Section Deployment Info

**Minimum Deployment Target :**
- **Recommandé :** iOS 13.0
- **Pourquoi :** Compatible avec 95%+ des iPhones actuels
- **Comment changer :** Cliquez sur la liste déroulante → Sélectionnez "iOS 13.0"

**Device Orientation :**
- **Portrait :** ☑ (Coché - Recommandé)
- **Landscape Left :** ☐ (Décoché)
- **Landscape Right :** ☐ (Décoché)
- **Upside Down :** ☐ (Décoché)

**Pourquoi Portrait uniquement :** TechnoCorner est optimisé pour utilisation mobile verticale.

---

## PARTIE 3 : Configuration Signing & Capabilities (CRITIQUE)

### 3.1 Comprendre la signature d'applications iOS

**Qu'est-ce que la signature :**
Apple exige que toutes les applications iOS soient "signées" numériquement pour :
- Vérifier l'identité du développeur
- S'assurer que l'app n'a pas été modifiée
- Contrôler quelles apps peuvent être installées

**Ce dont vous avez besoin :**
- **Apple Developer Account** (99$/an)
- **Certificat de développeur** (créé automatiquement)
- **Provisioning Profile** (créé automatiquement)

### 3.2 Navigation vers Signing & Capabilities

1. **Cliquez sur l'onglet "Signing & Capabilities"** (à côté de "General")
2. **Interface qui s'affiche :**

```
┌─────────────────────────────────────────────────────────┐
│ General │ Signing & Capabilities │ Resource Tags │ ... │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📱 TechnoCorner                                       │
│                                                         │
│  Signing (Debug)                                       │ ← Section Debug
│  ☑ Automatically manage signing                        │
│  Team: [Choisir une équipe...          ] ▼            │
│  Bundle Identifier: com.votrenom.technocorner          │
│  Provisioning Profile: [Automatique]                   │
│  Signing Certificate: [Automatique]                    │
│                                                         │
│  Signing (Release)                                     │ ← Section Release
│  ☑ Automatically manage signing                        │
│  Team: [Choisir une équipe...          ] ▼            │
│  Bundle Identifier: com.votrenom.technocorner          │
│  Provisioning Profile: [Automatique]                   │
│  Signing Certificate: [Automatique]                    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 3.3 Configuration étape par étape

**Étape 1 : Automatically manage signing**
- **Vérifiez que les cases sont cochées** ☑ pour Debug ET Release
- **Si pas cochées :** Cliquez pour cocher

**Étape 2 : Configurer le Team**

**Si votre compte Apple Developer est déjà configuré :**
1. **Cliquez sur la liste déroulante "Team"**
2. **Sélectionnez votre nom/équipe** dans la liste
3. **Passez à l'étape 3**

**Si "Aucune équipe disponible" :**
1. **Menu Xcode → Preferences** (ou Cmd+,)
2. **Onglet "Accounts"**
3. **Cliquez le "+" en bas à gauche**
4. **Sélectionnez "Apple ID"**
5. **Entrez vos identifiants Apple Developer**
6. **Cliquez "Sign In"**
7. **Fermez les Preferences**
8. **Retournez à Signing & Capabilities**
9. **Sélectionnez votre équipe dans la liste déroulante**

**Étape 3 : Vérifier le Bundle Identifier**
- **Doit correspondre** à celui configuré dans l'onglet General
- **Doit être unique** (différent de toute autre app existante)

### 3.4 Résolution des erreurs courantes

**Erreur : "Failed to register bundle identifier"**
```
Solution :
1. Changez le Bundle Identifier pour le rendre unique
   Exemple : com.votrenom.technocorner2025
2. Appuyez sur Entrée
3. Xcode recrée automatiquement les certificats
```

**Erreur : "No matching provisioning profiles found"**
```
Solution :
1. Vérifiez que votre Apple Developer Account est actif (99$/an payés)
2. Menu Xcode → Preferences → Accounts
3. Sélectionnez votre compte → "Download Manual Profiles"
4. Retournez à Signing & Capabilities
5. Décochez puis recochez "Automatically manage signing"
```

**Erreur : "Team not found"**
```
Solution :
1. Votre Apple Developer Account n'est pas activé
2. Allez sur developer.apple.com
3. Payez les 99$ annuels pour activer le compte
4. Attendez 24h pour l'activation
5. Recommencez la configuration
```

### 3.5 Validation de la configuration

**Indicateurs de succès :**
- ☑ "Automatically manage signing" coché
- 👤 Team sélectionné (votre nom)
- 📱 Bundle Identifier unique
- ✅ "Provisioning Profile: Xcode Managed Profile"
- ✅ "Signing Certificate: Apple Development"
- ❌ Aucune erreur rouge affichée

---

## PARTIE 4 : Build et Test (20 minutes)

### 4.1 Comprendre les destinations de build

**En haut de Xcode, vous voyez :**
```
[TechnoCorner] ▼ [iPhone 15 Pro] ▼
```

**Destinations possibles :**

**Simulateurs (pour test) :**
- iPhone 15 Pro (Simulateur)
- iPhone 14 Pro (Simulateur)
- iPad Pro (Simulateur)
- etc.

**Appareils physiques :**
- Votre iPhone connecté en USB
- Any iOS Device (arm64) ← Pour App Store

### 4.2 Test dans le simulateur

**Étape 1 : Sélectionner le simulateur**
1. **Cliquez sur la destination** (à droite du nom du projet)
2. **Sélectionnez "iPhone 15 Pro"** dans la liste
3. **Le simulateur iPhone va se lancer**

**Étape 2 : Lancer l'application**
1. **Cliquez le bouton Play** (triangle) en haut à gauche
2. **Ou raccourci : Cmd+R**
3. **Attendez la compilation** (1-3 minutes la première fois)

**Étape 3 : Vérification**
```
Le simulateur iPhone s'ouvre et affiche :
┌─────────────────────┐
│    ●  ●  ●         │ ← Encoche iPhone
├─────────────────────┤
│                     │
│    🎧 TechnoCorner  │ ← Votre app s'affiche
│                     │
│  Votre passeport    │
│  pour la scène      │
│  techno mondiale    │
│                     │
│  [🎵 Événements]    │
│  [👥 Communauté]    │
│  [🎫 Billets]       │
│                     │
│  ✅ Application     │
│  prête pour         │
│  l'App Store        │
│                     │
└─────────────────────┘
```

### 4.3 Debugging en cas de problème

**Écran blanc dans le simulateur :**
```bash
# Retour au Terminal
cd ~/Desktop/TechnoCorner-iOS
npx cap sync ios
# Puis dans Xcode : Cmd+R (relancer)
```

**Erreurs de compilation :**
1. **Product → Clean Build Folder** (Cmd+Shift+K)
2. **Attendez le nettoyage complet**
3. **Relancez avec Cmd+R**

**Console de débogage :**
- **Menu View → Debug Area → Show Debug Area**
- **Vérifiez les messages d'erreur**
- **Recherchez les erreurs JavaScript** dans votre code HTML

---

## PARTIE 5 : Archive pour App Store (30 minutes)

### 5.1 Comprendre la différence Debug vs Release

**Debug Mode (simulateur) :**
- Pour tests locaux
- Code non optimisé
- Informations de débogage incluses
- Taille de fichier importante

**Release Mode (App Store) :**
- Pour publication
- Code optimisé et compressé
- Pas d'informations de débogage
- Taille de fichier réduite

### 5.2 Préparation pour l'archive

**Étape 1 : Changer la destination**
1. **Cliquez sur la destination** en haut de Xcode
2. **Sélectionnez "Any iOS Device (arm64)"**
3. **Ne sélectionnez PAS un simulateur**

**Étape 2 : Nettoyer le projet**
1. **Menu Product → Clean Build Folder**
2. **Ou raccourci : Cmd+Shift+K**
3. **Attendez le message "Clean Finished"**

### 5.3 Processus d'archivage

**Étape 1 : Lancer l'archive**
1. **Menu Product → Archive**
2. **Xcode commence la compilation Release**

**Ce qui se passe pendant l'archive :**
```
Étapes de compilation (10-20 minutes) :

1. [●○○○○] Analyzing dependencies (30s)
   └ Xcode vérifie toutes les dépendances

2. [●●○○○] Compiling Swift files (2-5 min)
   └ Compilation des fichiers iOS natifs

3. [●●●○○] Processing web assets (1-2 min)
   └ Optimisation de votre HTML/CSS/JS

4. [●●●●○] Linking frameworks (2-3 min)
   └ Liaison avec Capacitor et iOS

5. [●●●●●] Creating archive (5-10 min)
   └ Création du fichier .ipa final
```

**Indicateurs de progression :**
- **Barre de progression** en haut de Xcode
- **Messages dans la console** (optionnel : View → Debug Area)
- **Pas d'erreurs rouges** ne doivent apparaître

### 5.4 L'Organizer s'ouvre

**Une fois l'archive terminée :**
```
┌─────────────────────────────────────────────────────────┐
│                  Xcode Organizer                       │
├─────────────────────────────────────────────────────────┤
│ Archives │ Crashes │ Energy │ TestFlight │ ...          │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ 📱 TechnoCorner                                        │
│ └ Version 1.0.0 (1)                                   │
│   Date: 12 juin 2025, 14:30                           │
│   Size: ~15 MB                                         │
│   Status: ✅ Valid                                     │
│                                                         │
│ [Distribute App]  [Export Archive]  [Upload Symbols]   │ ← Boutons d'action
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Vérifications importantes :**
- ✅ Status: "Valid" (pas d'erreurs)
- 📅 Date récente (aujourd'hui)
- 📦 Taille raisonnable (10-30 MB)

---

## PARTIE 6 : Distribution vers App Store Connect (25 minutes)

### 6.1 Processus de distribution

**Étape 1 : Lancer la distribution**
1. **Dans l'Organizer, cliquez "Distribute App"**
2. **Sélectionnez votre archive TechnoCorner**

**Étape 2 : Choisir la méthode de distribution**
```
┌─────────────────────────────────────────────────────────┐
│              Select a method of distribution            │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ ○ App Store Connect                    ← SÉLECTIONNEZ   │
│   Upload your app to App Store Connect for             │
│   TestFlight testing or App Store distribution         │
│                                                         │
│ ○ Ad Hoc                                               │
│   Export a signed app for limited distribution         │
│                                                         │
│ ○ Enterprise                                           │
│   Export a signed app for enterprise distribution      │
│                                                         │
│ ○ Development                                          │
│   Export an app signed for development                 │
│                                                         │
│                              [Previous] [Next]         │
└─────────────────────────────────────────────────────────┘
```
**Sélectionnez "App Store Connect" → Next**

### 6.2 Options de distribution

**Étape 3 : Upload vs Export**
```
┌─────────────────────────────────────────────────────────┐
│            App Store Connect distribution               │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ ● Upload                               ← SÉLECTIONNEZ   │
│   Upload your app to App Store Connect for             │
│   processing and distribution                           │
│                                                         │
│ ○ Export                                               │
│   Export a signed .ipa file to upload later            │
│                                                         │
│                              [Previous] [Next]         │
└─────────────────────────────────────────────────────────┘
```
**Sélectionnez "Upload" → Next**

### 6.3 Options de signature et validation

**Étape 4 : Distribution options**
```
App Store Connect distribution options:

☑ Upload your app's symbols to receive symbolicated crash logs
☑ Manage Version and Build Number (App Store Connect)
☐ Strip Swift symbols

[Previous] [Next]
```
**Laissez les options par défaut → Next**

**Étape 5 : Re-signing**
```
Re-sign "TechnoCorner":

● Automatically manage signing    ← RECOMMANDÉ
○ Manually manage signing

Team: Votre Nom (Team ID: ABC123XYZ)
Bundle Identifier: com.votrenom.technocorner

[Previous] [Next]
```
**Laissez "Automatically manage signing" → Next**

### 6.4 Upload final

**Étape 6 : Révision finale et upload**
```
┌─────────────────────────────────────────────────────────┐
│                    Review TechnoCorner                 │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ App: TechnoCorner                                      │
│ Bundle ID: com.votrenom.technocorner                   │
│ Version: 1.0.0 (1)                                    │
│ Team: Votre Nom                                        │
│ Destination: App Store Connect                          │
│                                                         │
│ Content:                                               │
│ ├ TechnoCorner.app (~15 MB)                          │ 
│ ├ Symbols (~2 MB)                                     │
│ └ Manifest                                            │
│                                                         │
│                              [Previous] [Upload]       │
└─────────────────────────────────────────────────────────┘
```

**Cliquez "Upload"**

### 6.5 Processus d'upload

**Ce qui se passe pendant l'upload :**
```
Upload Progress:

1. [●○○○] Authenticating with App Store Connect (30s)
2. [●●○○] Uploading app binary (5-15 min selon connexion)
3. [●●●○] Uploading symbols and metadata (2-3 min)
4. [●●●●] Processing and validation (1-2 min)

Total: 8-20 minutes selon votre connexion internet
```

**Messages de réussite :**
- ✅ "Upload Successful"
- 📧 Email de confirmation d'Apple
- 📱 App disponible dans App Store Connect

---

## PARTIE 7 : Validation et résolution des problèmes

### 7.1 Erreurs de build courantes

**"Build failed with multiple errors"**
```
Diagnostic :
1. Ouvrir la console de build : View → Debug Area
2. Chercher les erreurs rouges
3. Solutions communes :

   Erreur : "Command CodeSign failed"
   Solution : Problème de signature
   - Signing & Capabilities → Nouveau Bundle ID
   - Décocher/recocher "Automatically manage signing"

   Erreur : "No such file or directory: www/index.html"
   Solution : Fichiers web manquants
   - Terminal : npx cap sync ios
   - Relancer le build

   Erreur : "Apple Developer Program membership required"
   Solution : Compte développeur inactif
   - Vérifier sur developer.apple.com
   - Payer les 99$ annuels
```

### 7.2 Erreurs d'upload courantes

**"Invalid Bundle Identifier"**
```
Solution :
1. Bundle ID déjà utilisé par une autre app
2. Changer dans Xcode : com.votrenom.technocorner2025
3. Refaire : Archive → Upload
```

**"Upload failed - Network error"**
```
Solution :
1. Vérifier connexion internet stable
2. Désactiver VPN si actif
3. Réessayer l'upload (peut reprendre où ça s'est arrêté)
```

**"Processing timeout"**
```
Solution :
1. Upload réussi mais traitement Apple en cours
2. Attendre 15-30 minutes
3. Vérifier sur appstoreconnect.apple.com
```

### 7.3 Vérification finale

**Checklist avant de quitter Xcode :**
- ✅ Archive créée avec status "Valid"
- ✅ Upload terminé avec "Upload Successful"
- ✅ Email de confirmation reçu d'Apple
- ✅ Pas d'erreurs rouges dans Xcode

**Prochaines étapes :**
1. **Aller sur appstoreconnect.apple.com**
2. **Attendre 10-30 minutes** que le build soit traité
3. **Configurer les métadonnées** de l'app
4. **Soumettre pour révision Apple**

---

## PARTIE 8 : Conseils et bonnes pratiques

### 8.1 Optimisation des performances

**Avant chaque archive :**
```bash
# Nettoyer le cache Capacitor
npx cap sync ios --clear

# Optimiser les fichiers web
# - Compresser les images
# - Minifier le CSS/JS si nécessaire
# - Tester sur simulateur avant archive
```

### 8.2 Gestion des versions

**Pour les mises à jour futures :**
1. **Modifier le code** dans www/index.html
2. **Synchroniser :** npx cap sync ios
3. **Incrémenter la version** dans Xcode
   - Version 1.0.0 → 1.0.1 (correction)
   - Version 1.0.0 → 1.1.0 (nouvelle fonctionnalité)
   - Version 1.0.0 → 2.0.0 (changement majeur)
4. **Build :** Incrémenter de 1, 2, 3, 4...

### 8.3 Sauvegardes importantes

**Fichiers à sauvegarder :**
- `capacitor.config.ts` (configuration)
- `www/index.html` (votre app)
- Bundle Identifier utilisé
- Certificats de signature (automatiques mais notez l'ID)

Cette configuration Xcode détaillée vous permet de publier TechnoCorner sur l'App Store avec une compréhension complète de chaque étape du processus.