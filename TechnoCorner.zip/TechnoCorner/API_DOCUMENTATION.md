# API Documentation - TechnoCorner External Integration

## Overview

Cette API permet aux organisateurs externes d'intégrer leurs systèmes de billetterie avec la plateforme TechnoCorner tout en centralisant la génération et validation des QR codes.

## Authentification

Toutes les requêtes API nécessitent une authentification via clé API.

**Format:** `Authorization: Bearer {keyId}:{keySecret}`

**Exemple:** `Authorization: Bearer tk_abc123def456:9f8e7d6c5b4a39282716150948372615`

## Endpoints

### 1. Créer un événement

**POST** `/api/external/events`

Crée un nouvel événement dans le système externe.

**Body:**
```json
{
  "externalEventId": "event_123",
  "title": "Soirée Techno Underground",
  "description": "Une nuit de musique électronique exceptionnelle",
  "date": "2024-12-25",
  "time": "22:00",
  "venue": "Club Underground",
  "location": "Paris, France",
  "maxTickets": 500
}
```

**Réponse (201):**
```json
{
  "success": true,
  "event": {
    "id": 42,
    "externalEventId": "event_123",
    "title": "Soirée Techno Underground",
    "status": "active",
    "createdAt": "2024-06-06T10:30:00Z"
  }
}
```

### 2. Générer un QR code de billet

**POST** `/api/external/tickets/generate`

Génère un QR code unique pour un billet acheté via votre système externe.

**Body:**
```json
{
  "externalEventId": "event_123",
  "externalTicketId": "ticket_789",
  "buyerName": "Jean Dupont",
  "buyerEmail": "jean.dupont@email.com",
  "ticketType": "VIP",
  "price": "45€"
}
```

**Réponse (201):**
```json
{
  "success": true,
  "ticket": {
    "id": 156,
    "qrCode": "A1B2C3D4E5F67890",
    "qrCodeImage": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
    "status": "valid",
    "createdAt": "2024-06-06T10:35:00Z"
  }
}
```

### 3. Valider un QR code

**POST** `/api/external/tickets/validate`

Valide un QR code à l'entrée de l'événement.

**Body:**
```json
{
  "qrCode": "A1B2C3D4E5F67890"
}
```

**Réponse (200) - Valide:**
```json
{
  "valid": true,
  "ticket": {
    "buyerName": "Jean Dupont",
    "buyerEmail": "jean.dupont@email.com",
    "ticketType": "VIP",
    "eventTitle": "Soirée Techno Underground",
    "venue": "Club Underground",
    "validatedAt": "2024-06-06T22:15:00Z"
  }
}
```

**Réponse (200) - Déjà utilisé:**
```json
{
  "valid": false,
  "error": "Ticket already used",
  "ticket": {
    "buyerName": "Jean Dupont",
    "usedAt": "2024-06-06T21:45:00Z"
  }
}
```

### 4. Statistiques d'événement

**GET** `/api/external/events/{externalEventId}/stats`

Récupère les statistiques de vente pour un événement.

**Réponse (200):**
```json
{
  "event": {
    "title": "Soirée Techno Underground",
    "venue": "Club Underground",
    "date": "2024-12-25",
    "maxTickets": 500
  },
  "stats": {
    "totalTickets": 347,
    "validTickets": 320,
    "usedTickets": 25,
    "cancelledTickets": 2,
    "availableTickets": 153
  }
}
```

## Webhooks

Si configuré dans vos paramètres API, le système enverra des notifications webhook vers votre URL.

### Événements webhook

**ticket.generated** - Nouveau billet généré
```json
{
  "event": "ticket.generated",
  "timestamp": "2024-06-06T10:35:00Z",
  "data": {
    "ticket": {
      "id": 156,
      "externalTicketId": "ticket_789",
      "qrCode": "A1B2C3D4E5F67890",
      "buyerEmail": "jean.dupont@email.com",
      "eventTitle": "Soirée Techno Underground"
    }
  }
}
```

**ticket.validated** - Billet validé à l'entrée
```json
{
  "event": "ticket.validated",
  "timestamp": "2024-06-06T22:15:00Z",
  "data": {
    "ticket": {
      "id": 156,
      "qrCode": "A1B2C3D4E5F67890",
      "buyerName": "Jean Dupont",
      "eventTitle": "Soirée Techno Underground",
      "validatedAt": "2024-06-06T22:15:00Z"
    }
  }
}
```

## Gestion des erreurs

**401 Unauthorized**
```json
{
  "error": "Invalid API key"
}
```

**403 Forbidden**
```json
{
  "error": "Insufficient permissions for ticket generation"
}
```

**429 Too Many Requests**
```json
{
  "error": "Rate limit exceeded"
}
```

**400 Bad Request**
```json
{
  "error": "Missing required fields: externalEventId, title, date, venue"
}
```

## Limites

- **Rate Limit:** 1000 requêtes par heure par défaut
- **QR Codes:** Uniques et sécurisés, générés automatiquement
- **Webhooks:** Timeout de 30 secondes
- **Audit:** Toutes les requêtes sont loggées pour sécurité

## Intégration recommandée

### Workflow typique:

1. **Créer l'événement** via `/api/external/events`
2. **Pour chaque vente de billet:**
   - Générer le QR code via `/api/external/tickets/generate`
   - Intégrer le QR code dans votre email/PDF de billet
3. **À l'entrée de l'événement:**
   - Scanner le QR code
   - Valider via `/api/external/tickets/validate`
4. **Suivi des ventes:**
   - Consulter les stats via `/api/external/events/{id}/stats`

## Support technique

Pour obtenir vos clés API ou signaler un problème, contactez l'équipe TechnoCorner.

---

*Cette API vous permet de bénéficier de l'infrastructure de QR codes centralisée tout en gardant votre propre système de billetterie.*