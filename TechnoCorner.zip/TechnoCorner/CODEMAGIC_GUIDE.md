# Guide Complet Codemagic : Publier TechnoCorner sur l'App Store

## Vue d'ensemble

Codemagic est une plateforme de build cloud qui compile votre application iOS automatiquement et la publie sur l'App Store, sans avoir besoin d'Xcode sur votre Mac.

**Temps total estimé : 45 minutes de configuration + build automatique**

---

## ÉTAPE 1 : Préparation du projet local (10 minutes)

### 1.1 Créer le dossier de travail

```bash
# Aller dans votre dossier utilisateur
cd ~

# Créer le dossier du projet
mkdir technocorner-codemagic
cd technocorner-codemagic

# Vérifier la localisation
pwd
```

**Résultat attendu :** `/Users/votre-nom/technocorner-codemagic`

### 1.2 Créer la structure complète du projet

```bash
# Créer les dossiers nécessaires
mkdir -p www
mkdir -p ios
mkdir -p android

# Créer package.json
cat > package.json << 'EOF'
{
  "name": "technocorner",
  "version": "1.0.0",
  "description": "TechnoCorner - Application iOS pour événements techno",
  "main": "index.js",
  "scripts": {
    "build": "echo 'Build completed'",
    "ios:build": "npx cap build ios",
    "ios:sync": "npx cap sync ios"
  },
  "dependencies": {
    "@capacitor/cli": "^6.1.0",
    "@capacitor/core": "^6.1.0",
    "@capacitor/ios": "^6.1.0",
    "@capacitor/android": "^6.1.0",
    "@capacitor/splash-screen": "^6.0.0",
    "@capacitor/status-bar": "^6.0.0"
  },
  "keywords": ["techno", "events", "ios", "music"],
  "author": "TechnoCorner Team",
  "license": "MIT",
  "repository": {
    "type": "git",
    "url": "git+https://github.com/VOTRE_NOM/technocorner.git"
  }
}
EOF
```

**Explication :** Ce package.json configure le projet avec toutes les dépendances Capacitor nécessaires pour iOS.

### 1.3 Créer l'application web TechnoCorner

```bash
cat > www/index.html << 'EOF'
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>TechnoCorner</title>
    <meta name="theme-color" content="#667eea">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
            overflow-x: hidden;
        }
        
        .container {
            max-width: 400px;
            width: 100%;
            background: rgba(255, 255, 255, 0.1);
            padding: 40px 30px;
            border-radius: 25px;
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }
        
        .title {
            font-size: 2.8rem;
            font-weight: 800;
            margin-bottom: 15px;
            text-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            letter-spacing: -1px;
        }
        
        .subtitle {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 35px;
            line-height: 1.5;
            font-weight: 400;
        }
        
        .feature {
            background: rgba(255, 255, 255, 0.12);
            padding: 25px 20px;
            margin: 18px 0;
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.15);
            transition: all 0.3s cubic-bezier(0.4, 0.0, 0.2, 1);
        }
        
        .feature:hover {
            transform: translateY(-3px);
            background: rgba(255, 255, 255, 0.18);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }
        
        .feature-title {
            font-size: 1.3rem;
            margin-bottom: 10px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .feature-description {
            font-size: 0.95rem;
            opacity: 0.85;
            line-height: 1.4;
            margin: 0;
        }
        
        .status {
            margin-top: 35px;
            padding: 18px;
            background: rgba(0, 255, 100, 0.15);
            border-radius: 12px;
            border: 1px solid rgba(0, 255, 100, 0.3);
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        .version {
            margin-top: 25px;
            font-size: 0.8rem;
            opacity: 0.6;
            font-weight: 300;
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 30px 20px;
            }
            .title {
                font-size: 2.4rem;
            }
            .subtitle {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="title">🎧 TechnoCorner</h1>
        <p class="subtitle">
            Découvrez la scène techno, connectez-vous avec la communauté électronique
        </p>
        
        <div class="feature">
            <h3 class="feature-title">
                <span>🎵</span>
                <span>Événements</span>
            </h3>
            <p class="feature-description">
                Trouvez les meilleurs événements techno près de chez vous. Soirées, festivals, afters.
            </p>
        </div>
        
        <div class="feature">
            <h3 class="feature-title">
                <span>👥</span>
                <span>Communauté</span>
            </h3>
            <p class="feature-description">
                Partagez vos moments, connectez-vous avec d'autres passionnés de musique électronique.
            </p>
        </div>
        
        <div class="feature">
            <h3 class="feature-title">
                <span>🎫</span>
                <span>Scanner</span>
            </h3>
            <p class="feature-description">
                Scannez et validez vos billets d'événements avec notre système anti-fraude avancé.
            </p>
        </div>
        
        <div class="status">
            ✅ Application TechnoCorner - Build Codemagic Ready
        </div>
        
        <div class="version">
            Version 1.0.0 • Build Cloud iOS
        </div>
    </div>
    
    <script>
        console.log('TechnoCorner Codemagic build loaded');
        
        document.addEventListener('DOMContentLoaded', function() {
            console.log('TechnoCorner ready for iOS deployment');
        });
    </script>
</body>
</html>
EOF
```

### 1.4 Créer la configuration Capacitor

```bash
cat > capacitor.config.ts << 'EOF'
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.technocorner.app',
  appName: 'TechnoCorner',
  webDir: 'www',
  bundledWebRuntime: false,
  server: {
    androidScheme: 'https'
  },
  ios: {
    contentInset: 'automatic'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#667eea',
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      showSpinner: false
    },
    StatusBar: {
      style: 'light'
    }
  }
};

export default config;
EOF
```

### 1.5 Créer la configuration Codemagic

```bash
cat > codemagic.yaml << 'EOF'
workflows:
  ios-workflow:
    name: TechnoCorner iOS Build
    max_build_duration: 60
    instance_type: mac_mini_m1
    integrations:
      app_store_connect: codemagic
    environment:
      vars:
        XCODE_WORKSPACE: "ios/App/App.xcworkspace"
        XCODE_SCHEME: "App"
        BUNDLE_ID: "com.technocorner.app"
        APP_STORE_APP_ID: 123456789 # À modifier avec votre App ID
      ios_signing:
        distribution_type: app_store
        bundle_identifier: com.technocorner.app
    scripts:
      - name: Install dependencies
        script: |
          npm ci
      - name: Capacitor update
        script: |
          npx cap update ios
      - name: Set up code signing settings on Xcode project
        script: |
          xcode-project use-profiles
      - name: Build ipa for distribution
        script: |
          xcode-project build-ipa \
            --workspace "$XCODE_WORKSPACE" \
            --scheme "$XCODE_SCHEME"
    artifacts:
      - build/ios/ipa/*.ipa
    publishing:
      app_store_connect:
        auth: integration
        submit_to_app_store: true
        cancel_previous_submissions: true
        submit_to_testflight: false
EOF
```

**Explication :** Ce fichier configure Codemagic pour build automatiquement votre app iOS et la publier sur l'App Store.

### 1.6 Vérifier la structure du projet

```bash
# Vérifier tous les fichiers
ls -la

# Vérifier le contenu www
ls -la www/

# Tester l'HTML localement
open www/index.html
```

**Résultat attendu :** Safari affiche l'interface TechnoCorner avec le message "Build Codemagic Ready".

---

## ÉTAPE 2 : Création du repository GitHub (10 minutes)

### 2.1 Initialiser Git localement

```bash
# Initialiser le repository Git
git init

# Créer .gitignore
cat > .gitignore << 'EOF'
node_modules/
.DS_Store
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.env
.env.local
.env.development.local
.env.test.local
.env.production.local
ios/App/build/
android/app/build/
dist/
EOF

# Ajouter tous les fichiers
git add .

# Premier commit
git commit -m "Initial TechnoCorner project for Codemagic iOS build"
```

### 2.2 Créer le repository sur GitHub

1. **Ouvrez votre navigateur**
2. **Allez sur [github.com](https://github.com)**
3. **Connectez-vous à votre compte**
4. **Cliquez le bouton "+" en haut à droite**
5. **Sélectionnez "New repository"**

**Configuration du repository :**
- **Repository name :** `technocorner-ios`
- **Description :** `TechnoCorner - Application iOS pour événements techno`
- **Visibility :** Public (ou Private si vous préférez)
- **Ne cochez PAS** "Add a README file"
- **Ne cochez PAS** "Add .gitignore"
- **Ne cochez PAS** "Choose a license"

6. **Cliquez "Create repository"**

### 2.3 Connecter le projet local à GitHub

GitHub vous affichera des commandes. Copiez et collez dans votre Terminal :

```bash
# Remplacez VOTRE_NOM par votre nom d'utilisateur GitHub
git remote add origin https://github.com/VOTRE_NOM/technocorner-ios.git
git branch -M main
git push -u origin main
```

**Exemple concret :**
Si votre nom GitHub est "johndoe", la commande sera :
```bash
git remote add origin https://github.com/johndoe/technocorner-ios.git
git branch -M main
git push -u origin main
```

**Résultat attendu :** Tous vos fichiers sont maintenant visibles sur GitHub.

---

## ÉTAPE 3 : Configuration du compte Codemagic (10 minutes)

### 3.1 Créer un compte Codemagic

1. **Ouvrez [codemagic.io](https://codemagic.io)**
2. **Cliquez "Get started for free"**
3. **Sélectionnez "Sign up with GitHub"**
4. **Autorisez Codemagic à accéder à votre GitHub**

**Note :** L'inscription avec GitHub simplifie la connexion aux repositories.

### 3.2 Connecter votre repository

1. **Une fois connecté, cliquez "Add application"**
2. **Sélectionnez "GitHub"**
3. **Trouvez et sélectionnez "technocorner-ios"** dans la liste
4. **Cliquez "Select"**

### 3.3 Configurer le projet

1. **Project type :** Sélectionnez "Capacitor"
2. **Cliquez "Finish: Add application"**

**Résultat attendu :** Votre projet TechnoCorner apparaît dans le dashboard Codemagic.

---

## ÉTAPE 4 : Configuration des certificats Apple (15 minutes)

### 4.1 Prérequis Apple Developer

**Vous devez avoir :**
- Un compte Apple Developer actif (99$/an)
- Accès à [developer.apple.com](https://developer.apple.com)

### 4.2 Configurer App Store Connect Integration

1. **Dans Codemagic, allez dans "Teams" → "Integrations"**
2. **Cliquez "Add integration"**
3. **Sélectionnez "App Store Connect"**

### 4.3 Générer une clé API App Store Connect

**Sur developer.apple.com :**

1. **Allez dans "Certificates, Identifiers & Profiles"**
2. **Section "Keys" → Cliquez "+"**
3. **Key Name :** `Codemagic TechnoCorner`
4. **Cochez "App Store Connect API"**
5. **Cliquez "Continue"**
6. **Cliquez "Register"**
7. **Téléchargez le fichier .p8** (important : vous ne pourrez plus le télécharger)
8. **Notez l'Issuer ID et Key ID**

### 4.4 Configurer l'intégration dans Codemagic

**Retour dans Codemagic :**

1. **Nom de l'intégration :** `TechnoCorner AppStore`
2. **Issuer ID :** Collez l'Issuer ID d'Apple
3. **Key ID :** Collez le Key ID d'Apple
4. **Private Key :** Ouvrez le fichier .p8 téléchargé et collez son contenu
5. **Cliquez "Save"**

### 4.5 Créer l'App ID sur App Store Connect

1. **Allez sur [appstoreconnect.apple.com](https://appstoreconnect.apple.com)**
2. **My Apps → "+" → "New App"**
3. **Platforms :** iOS
4. **Name :** TechnoCorner
5. **Primary Language :** French
6. **Bundle ID :** com.technocorner.app
7. **SKU :** TECHNOCORNER2025
8. **User Access :** Full Access
9. **Cliquez "Create"**

**Notez l'App ID** (nombre affiché dans l'URL ou dans App Information).

---

## ÉTAPE 5 : Configuration du build Codemagic (5 minutes)

### 5.1 Modifier codemagic.yaml

**Retournez dans votre Terminal :**

```bash
# Ouvrir le fichier de configuration
nano codemagic.yaml
```

**Modifiez la ligne :**
```yaml
APP_STORE_APP_ID: 123456789 # Remplacez par votre vrai App ID
```

**Par :**
```yaml
APP_STORE_APP_ID: VOTRE_VRAI_APP_ID # Le numéro de votre app sur App Store Connect
```

**Sauvegardez avec Ctrl+X, puis Y, puis Entrée.**

### 5.2 Mettre à jour le repository

```bash
# Ajouter les modifications
git add codemagic.yaml

# Commit avec les changements
git commit -m "Update App Store App ID for Codemagic build"

# Pousser vers GitHub
git push origin main
```

---

## ÉTAPE 6 : Lancer le premier build (5 minutes)

### 6.1 Démarrer le build

**Dans Codemagic :**

1. **Allez dans votre projet TechnoCorner**
2. **Onglet "Build"**
3. **Sélectionnez la branche "main"**
4. **Workflow :** `ios-workflow`
5. **Cliquez "Start new build"**

### 6.2 Surveiller le build

**Le build passe par ces étapes :**

1. **Environment preparation** (2-3 minutes)
   - Installation de macOS et Xcode dans le cloud

2. **Install dependencies** (1-2 minutes)
   - `npm ci` pour installer les packages

3. **Capacitor update** (1 minute)
   - Synchronisation des fichiers web vers iOS

4. **Code signing setup** (2-3 minutes)
   - Configuration automatique des certificats Apple

5. **Build ipa** (5-10 minutes)
   - Compilation de l'application iOS

6. **Publish to App Store** (2-3 minutes)
   - Upload automatique vers App Store Connect

**Temps total :** 15-25 minutes pour le premier build.

### 6.3 Vérifier le statut

**Indicateurs de succès :**
- ✅ Toutes les étapes en vert
- 📱 Fichier .ipa généré
- 🚀 Upload vers App Store réussi

**En cas d'erreur :**
- ❌ Étape en rouge : cliquez pour voir les logs détaillés
- 🔧 Corrigez le problème dans votre code
- 🔄 Poussez vers GitHub pour relancer automatiquement

---

## ÉTAPE 7 : Finalisation sur App Store Connect (10 minutes)

### 7.1 Vérifier l'upload

1. **Retournez sur [appstoreconnect.apple.com](https://appstoreconnect.apple.com)**
2. **My Apps → TechnoCorner**
3. **Section "1.0 Prepare for Submission"**
4. **Scrollez jusqu'à "Build"**
5. **Cliquez le "+" à côté de "Build"**
6. **Sélectionnez le build** uploadé par Codemagic

**Note :** Il peut falloir 10-15 minutes pour que le build apparaisse.

### 7.2 Compléter les métadonnées

**Screenshots (obligatoire) :**
- Prendre 3 captures d'écran de l'app (iPhone 15 Pro : 1290x2796 pixels)
- Les uploader dans App Store Connect

**Description :**
```
Découvrez la scène techno avec TechnoCorner !

FONCTIONNALITÉS PRINCIPALES :
• Trouvez les meilleurs événements techno près de chez vous
• Connectez-vous avec la communauté électronique
• Scannez et validez vos billets d'événements
• Partagez vos moments et photos
• Recommandations personnalisées

Rejoignez la plus grande communauté techno francophone !
```

**Keywords :**
`techno,événements,musique,électronique,soirée,festival,billets,communauté,dj,clubs`

### 7.3 Soumission finale

1. **Vérifiez que toutes les sections ont une icône verte ✅**
2. **Cliquez "Submit for Review"**
3. **Répondez aux questions de compliance**
4. **Cliquez "Submit"**

---

## ÉTAPE 8 : Automatisation pour les mises à jour

### 8.1 Workflow automatique

**Désormais, pour chaque mise à jour :**

```bash
# Modifiez votre code
# Par exemple, changez le texte dans www/index.html

# Commitez et poussez
git add .
git commit -m "Update app version 1.0.1"
git push origin main
```

**Codemagic détecte automatiquement le push et :**
1. Build la nouvelle version
2. L'upload vers App Store Connect
3. Vous envoie une notification de succès/échec

### 8.2 Surveillance des builds

**Dashboard Codemagic :**
- 📊 Historique de tous les builds
- ⏱️ Temps de build par étape
- 📧 Notifications email automatiques
- 📱 App mobile Codemagic pour surveiller

### 8.3 Gestion des versions

**Pour les mises à jour App Store :**

1. **Incrémentez la version** dans `capacitor.config.ts`
2. **Poussez vers GitHub**
3. **Codemagic build automatiquement**
4. **Créez une nouvelle version** dans App Store Connect
5. **Soumettez pour révision**

---

## RÉSUMÉ DES AVANTAGES CODEMAGIC

### ✅ Avantages
- **Zéro configuration Xcode locale**
- **Builds automatiques** à chaque push GitHub
- **Machines macOS** puissantes dans le cloud
- **Intégration directe** App Store Connect
- **500 minutes gratuites** par mois
- **Support technique** inclus
- **Notifications** email/Slack automatiques

### 📊 Statistiques typiques
- **Premier build :** 20-30 minutes
- **Builds suivants :** 15-20 minutes
- **Taux de succès :** 95%+ après configuration
- **Délai App Store :** 24-48h après soumission

### 💰 Coûts
- **Plan gratuit :** 500 minutes/mois (environ 25-30 builds)
- **Plan Pro :** 19$/mois pour plus de builds
- **Économie vs développeur iOS local :** Significative

---

## DÉPANNAGE COURANT

### Erreur : "Bundle identifier already exists"
**Solution :**
```bash
# Changez le bundle ID dans capacitor.config.ts
appId: 'com.votrenom.technocorner'

# Pushez la modification
git add . && git commit -m "Fix bundle ID" && git push
```

### Erreur : "Code signing failed"
**Solution :**
1. Vérifiez l'intégration App Store Connect dans Codemagic
2. Assurez-vous que votre compte Apple Developer est actif
3. Regénérez la clé API si nécessaire

### Erreur : "Build not appearing in App Store Connect"
**Solution :**
1. Attendez 15-30 minutes (traitement Apple)
2. Vérifiez les emails d'Apple pour erreurs
3. Consultez les logs Codemagic pour l'étape "Publish"

### Build qui traîne en longueur
**Solution :**
1. Vérifiez le statut sur status.codemagic.io
2. Annulez et relancez le build si nécessaire
3. Contactez le support Codemagic si récurrent

---

## PROCHAINES ÉTAPES

Une fois votre application approuvée par Apple (24-48h) :

1. **Partagez le lien App Store** avec vos utilisateurs
2. **Surveillez les reviews** et ratings
3. **Analysez les statistiques** dans App Store Connect
4. **Planifiez les mises à jour** avec nouvelles fonctionnalités

**Votre pipeline de développement iOS est maintenant entièrement automatisé !**

Chaque modification de code déclenche automatiquement :
- Build iOS dans le cloud
- Tests de qualité
- Upload vers App Store Connect
- Notification de résultat

**TechnoCorner sera bientôt disponible sur l'App Store via Codemagic !**