import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import type { EventFilters } from "@/lib/types";

interface EventFiltersProps {
  filters: EventFilters;
  onFiltersChange: (filters: EventFilters) => void;
}

const categories = [
  { value: "all", label: "Tous" },
  { value: "club", label: "Clubs" },
  { value: "festival", label: "Festivals" },
  { value: "underground", label: "Underground" },
  { value: "workshop", label: "Workshops" },
  { value: "outdoor", label: "Outdoor" }
];

export function EventFilters({ filters, onFiltersChange }: EventFiltersProps) {
  const [searchInput, setSearchInput] = useState(filters.search);

  const handleCategoryChange = (category: string) => {
    onFiltersChange({ ...filters, category });
  };

  const handleSortChange = (sortBy: string) => {
    onFiltersChange({ ...filters, sortBy });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFiltersChange({ ...filters, search: searchInput });
  };

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 bg-slate-900/30 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <h2 className="text-2xl font-bold text-white">Événements à venir</h2>
          
          {/* Filter Buttons */}
          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <Button
                key={category.value}
                variant={filters.category === category.value ? "default" : "outline"}
                onClick={() => handleCategoryChange(category.value)}
                className={
                  filters.category === category.value
                    ? "bg-primary text-white neon-glow"
                    : "bg-slate-800/50 text-slate-300 border-slate-600 hover:bg-primary hover:text-white hover:border-primary transition-all duration-300"
                }
              >
                {category.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Search and Sort */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <form onSubmit={handleSearchSubmit} className="flex-1 relative">
            <Input
              type="text"
              placeholder="Rechercher des événements..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="w-full pl-10 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400 focus:border-primary"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          </form>
          
          <Select value={filters.sortBy} onValueChange={handleSortChange}>
            <SelectTrigger className="w-full sm:w-48 bg-slate-800/50 border-slate-600 text-white">
              <SelectValue placeholder="Trier par" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Date (plus récent)</SelectItem>
              <SelectItem value="popularity">Popularité</SelectItem>
              <SelectItem value="price-asc">Prix (croissant)</SelectItem>
              <SelectItem value="price-desc">Prix (décroissant)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </section>
  );
}
