import { Link, useLocation } from "wouter";
import { Home, Users, Calendar, Scan, User } from "lucide-react";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "Accueil" },
    { path: "/community", icon: Users, label: "Communauté" },
    { path: "/create", icon: Calendar, label: "Créer" },
    { path: "/mobile-scanner", icon: Scan, label: "Scanner" },
    { path: "/profile", icon: User, label: "Profil" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-sm border-t border-primary/20 safe-area-inset-bottom z-40">
      <div className="flex justify-around items-center py-2">
        {navItems.map((item) => {
          const isActive = location === item.path;
          const Icon = item.icon;
          
          return (
            <Link key={item.path} href={item.path}>
              <div className={`flex flex-col items-center py-2 px-3 rounded-lg transition-all ${
                isActive 
                  ? "bg-primary/20 text-primary" 
                  : "text-slate-400 hover:text-white"
              }`}>
                <Icon className="w-5 h-5 mb-1" />
                <span className="text-xs font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}