import { useState, useEffect, useCallback } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { insertEventSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, X, Upload, Image } from "lucide-react";

const createEventFormSchema = insertEventSchema.extend({
  djInput: z.string().optional(),
  pricingTiers: z.string().optional(),
}).refine((data) => {
  // Validation des champs obligatoires
  return data.title && data.title.trim().length > 0;
}, {
  message: "Le titre de l'événement est obligatoire",
  path: ["title"],
}).refine((data) => {
  return data.description && data.description.trim().length > 0;
}, {
  message: "La description de l'événement est obligatoire",
  path: ["description"],
}).refine((data) => {
  return data.date && data.date.trim().length > 0;
}, {
  message: "La date de l'événement est obligatoire",
  path: ["date"],
}).refine((data) => {
  return data.venue && data.venue.trim().length > 0;
}, {
  message: "Le lieu de l'événement est obligatoire",
  path: ["venue"],
}).refine((data) => {
  return data.location && data.location.trim().length > 0;
}, {
  message: "L'emplacement de l'événement est obligatoire",
  path: ["location"],
}).refine((data) => {
  return data.category && data.category.trim().length > 0;
}, {
  message: "La catégorie de l'événement est obligatoire",
  path: ["category"],
}).refine((data) => {
  return data.organizerName && data.organizerName.trim().length > 0;
}, {
  message: "Le nom de l'organisateur est obligatoire",
  path: ["organizerName"],
}).refine((data) => {
  return data.organizerEmail && data.organizerEmail.trim().length > 0;
}, {
  message: "L'email de l'organisateur est obligatoire",
  path: ["organizerEmail"],
}).refine((data) => {
  // Si une date de fin est fournie, elle doit être postérieure à la date de début
  if (data.endDate && data.date) {
    return new Date(data.endDate) >= new Date(data.date);
  }
  return true;
}, {
  message: "La date de fin doit être postérieure ou égale à la date de début",
  path: ["endDate"],
});

type CreateEventFormData = z.infer<typeof createEventFormSchema>;

export function CreateEventForm() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [djList, setDjList] = useState<string[]>([]);
  const [djInput, setDjInput] = useState("");
  const [isFreeEvent, setIsFreeEvent] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [pricingTiers, setPricingTiers] = useState([
    { type: "early", price: "", label: "Early Bird" },
    { type: "regular", price: "", label: "Prix Normal" },
    { type: "late", price: "", label: "Last Minute" },
    { type: "members", price: "", label: "Members" }
  ]);

  const form = useForm<CreateEventFormData>({
    resolver: zodResolver(createEventFormSchema),
    defaultValues: {
      title: "",
      description: "",
      date: "",
      time: "",
      endTime: "",
      venue: "",
      location: "",
      price: "",
      category: "",
      djs: [],
      imageUrl: "",
      organizerName: "",
      organizerEmail: "",
      organizerPhone: "",
      organizerWebsite: "",
      enableTicketing: "true",
      ticketsAvailable: null,
    },
  });

  // Surveiller le champ billetterie pour détecter les événements sans billetterie
  const watchedTicketing = form.watch("enableTicketing");
  
  useEffect(() => {
    const isWithoutTicketing = watchedTicketing === "false";
    setIsFreeEvent(isWithoutTicketing);
  }, [watchedTicketing]);

  // Fonction pour convertir un fichier en base64
  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  // Gestion du drag and drop
  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    const imageFile = files.find(file => file.type.startsWith('image/'));
    
    if (imageFile) {
      try {
        const base64 = await convertFileToBase64(imageFile);
        setPreviewImage(base64);
        form.setValue("imageUrl", base64);
      } catch (error) {
        toast({
          title: "Erreur",
          description: "Impossible de traiter l'image",
          variant: "destructive",
        });
      }
    }
  }, [form, toast]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  // Gestion de l'upload via input file
  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      try {
        const base64 = await convertFileToBase64(file);
        setPreviewImage(base64);
        form.setValue("imageUrl", base64);
      } catch (error) {
        toast({
          title: "Erreur",
          description: "Impossible de traiter l'image",
          variant: "destructive",
        });
      }
    }
  }, [form, toast]);

  const createEventMutation = useMutation({
    mutationFn: async (data: CreateEventFormData) => {
      const { djInput, ...eventData } = data;
      const finalData = { ...eventData, djs: djList };
      return apiRequest("POST", "/api/events", finalData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      toast({
        title: "Événement créé avec succès!",
        description: "Votre événement a été publié et est maintenant visible.",
      });
      setLocation("/");
    },
    onError: (error: any) => {
      toast({
        title: "Erreur lors de la création",
        description: error.message || "Une erreur est survenue lors de la création de l'événement.",
        variant: "destructive",
      });
    },
  });

  const addDj = () => {
    if (djInput.trim() && !djList.includes(djInput.trim())) {
      setDjList([...djList, djInput.trim()]);
      setDjInput("");
    }
  };

  const removeDj = (index: number) => {
    setDjList(djList.filter((_, i) => i !== index));
  };

  const onSubmit = (data: CreateEventFormData) => {
    createEventMutation.mutate(data);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
        <CardHeader>
          <CardTitle className="text-2xl font-bold techno-gradient">
            Créer un nouvel événement
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Titre de l'événement</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="WAREHOUSE REVOLUTION" 
                          {...field} 
                          className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Catégorie</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-slate-800/50 border-slate-600 text-white">
                            <SelectValue placeholder="Sélectionner une catégorie" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="club">Club</SelectItem>
                          <SelectItem value="festival">Festival</SelectItem>
                          <SelectItem value="underground">Underground</SelectItem>
                          <SelectItem value="workshop">Workshop</SelectItem>
                          <SelectItem value="outdoor">Outdoor</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Date de début</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Date de fin (optionnelle)</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white"
                            placeholder="Pour les événements multi-jours"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Heure de début *</FormLabel>
                        <FormControl>
                          <Input 
                            type="time" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="endTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Heure de fin (optionnelle)</FormLabel>
                        <FormControl>
                          <Input 
                            type="time" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Section Prix avec niveaux multiples */}
                <div className="space-y-4">
                  <FormLabel className="text-white">Configuration des prix</FormLabel>
                  
                  {/* Prix principal (obligatoire) */}
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white text-sm">Prix principal *</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="25€" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Niveaux de prix optionnels */}
                  <div className="space-y-3">
                    <div className="text-sm text-slate-400">
                      Niveaux de prix optionnels (laissez vide si non utilisés)
                    </div>
                    
                    {pricingTiers.map((tier, index) => (
                      <div key={tier.type} className="flex items-center space-x-3">
                        <div className="w-24 text-sm text-slate-300">
                          {tier.label}
                        </div>
                        <Input
                          placeholder="ex: 20€"
                          value={tier.price}
                          onChange={(e) => {
                            const newTiers = [...pricingTiers];
                            newTiers[index].price = e.target.value;
                            setPricingTiers(newTiers);
                            
                            // Mettre à jour le champ caché
                            const tiersWithValues = newTiers.filter(t => t.price.trim() !== "");
                            form.setValue("pricingTiers", JSON.stringify(tiersWithValues));
                          }}
                          className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400 flex-1"
                        />
                      </div>
                    ))}
                  </div>

                  {/* Champ caché pour les niveaux de prix */}
                  <FormField
                    control={form.control}
                    name="pricingTiers"
                    render={({ field }) => (
                      <input type="hidden" {...field} />
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="venue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Lieu</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Warehouse District" 
                          {...field} 
                          className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Ville</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Paris" 
                          {...field} 
                          className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-white">Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Décrivez votre événement..." 
                        className="min-h-24 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Zone de drag and drop pour l'image */}
              <div className="space-y-4">
                <FormLabel className="text-white">Image de l'événement (optionnel)</FormLabel>
                
                {/* Aperçu de l'image */}
                {previewImage && (
                  <div className="relative">
                    <img 
                      src={previewImage} 
                      alt="Aperçu" 
                      className="w-full h-48 object-cover rounded-lg border border-slate-600"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={() => {
                        setPreviewImage(null);
                        form.setValue("imageUrl", "");
                      }}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
                
                {/* Zone de drag and drop */}
                {!previewImage && (
                  <div
                    className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 ${
                      isDragOver 
                        ? "border-cyan-400 bg-cyan-400/10" 
                        : "border-slate-600 hover:border-slate-500"
                    }`}
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                  >
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    
                    <div className="space-y-4">
                      <div className="mx-auto w-12 h-12 bg-slate-700 rounded-full flex items-center justify-center">
                        {isDragOver ? (
                          <Upload className="w-6 h-6 text-cyan-400" />
                        ) : (
                          <Image className="w-6 h-6 text-slate-400" />
                        )}
                      </div>
                      
                      <div>
                        <p className="text-white font-medium">
                          {isDragOver 
                            ? "Déposez votre image ici" 
                            : "Glissez-déposez une image ou cliquez pour sélectionner"
                          }
                        </p>
                        <p className="text-slate-400 text-sm mt-1">
                          Formats acceptés: JPG, PNG, GIF (max 10MB)
                        </p>
                      </div>
                      
                      <Button
                        type="button"
                        variant="outline"
                        className="border-slate-600 text-slate-300 hover:bg-slate-700"
                      >
                        Parcourir les fichiers
                      </Button>
                    </div>
                  </div>
                )}
                
                {/* Champ caché pour la valeur */}
                <FormField
                  control={form.control}
                  name="imageUrl"
                  render={({ field }) => (
                    <input type="hidden" {...field} value={field.value || ""} />
                  )}
                />
              </div>

              {/* DJ Section */}
              <div className="space-y-4">
                <FormLabel className="text-white">DJs / Artistes (optionnel)</FormLabel>
                <div className="flex gap-2">
                  <Input
                    placeholder="Nom du DJ"
                    value={djInput}
                    onChange={(e) => setDjInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addDj())}
                    className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                  />
                  <Button type="button" onClick={addDj} className="bg-primary hover:bg-primary/80">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                {djList.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {djList.map((dj, index) => (
                      <div key={index} className="flex items-center gap-1 bg-primary/20 px-3 py-1 rounded-full">
                        <span className="text-white text-sm">{dj}</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeDj(index)}
                          className="h-auto p-0 text-white hover:text-red-400"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Section Billetterie */}
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-white mb-4">Billetterie</h3>
                
                <FormField
                  control={form.control}
                  name="enableTicketing"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Activer la billetterie</FormLabel>
                      <FormControl>
                        <Select onValueChange={field.onChange} defaultValue={field.value || "false"}>
                          <SelectTrigger className="bg-slate-800/50 border-slate-600 text-white">
                            <SelectValue placeholder="Choisir..." />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-800 border-slate-600">
                            <SelectItem value="false">Non - Événement gratuit/sans billetterie</SelectItem>
                            <SelectItem value="true">Oui - Vendre des billets</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {form.watch("enableTicketing") === "true" && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="ticketsAvailable"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Nombre de billets disponibles (optionnel)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="Laissez vide pour illimité" 
                              {...field} 
                              value={field.value || ""}
                              onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : null)}
                              className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}
              </div>

              {/* Organizer Info */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Informations organisateur</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="organizerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Nom</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Votre nom ou organisation" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="organizerEmail"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Email</FormLabel>
                        <FormControl>
                          <Input 
                            type="email" 
                            placeholder="contact@example.com" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="organizerPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Téléphone (optionnel)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="+33 1 23 45 67 89" 
                            {...field} 
                            value={field.value || ""}
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Site web de l'organisateur */}
                <FormField
                  control={form.control}
                  name="organizerWebsite"
                  render={({ field }) => (
                    <FormItem className="ring-2 ring-accent/50 rounded-lg p-4 bg-accent/5">
                      <FormLabel className="text-accent font-bold flex items-center gap-2">
                        {isFreeEvent ? "Lien de l'événement (optionnel)" : "Lien de la billeterie (optionnel)"}
                      </FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://votre-site.com" 
                          {...field} 
                          value={field.value || ""}
                          className="bg-accent/10 border-accent/60 text-white placeholder-accent/60 ring-2 ring-accent/30 transition-all duration-300"
                        />
                      </FormControl>
                      <div className="text-sm mt-1 text-accent/80 font-medium">
                        {isFreeEvent 
                          ? "🎯 Les visiteurs seront redirigés vers le lien de votre événement gratuit" 
                          : "🎯 Les visiteurs seront redirigés vers votre lien de billeterie pour acheter leurs billets"
                        }
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* URL de webhook pour recevoir les données des participants */}
                {!isFreeEvent && (
                  <FormField
                    control={form.control}
                    name="organizerWebhookUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">URL Webhook (optionnel)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://votre-site.com/webhook/participants" 
                            {...field}
                            value={field.value || ""} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <div className="text-sm text-slate-400">
                          📡 Recevez automatiquement les données des participants après leur achat
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {/* Clé API pour sécuriser les webhooks */}
                {!isFreeEvent && form.watch("organizerWebhookUrl") && (
                  <FormField
                    control={form.control}
                    name="organizerApiKey"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Clé API Webhook (optionnel)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="votre-cle-api-secrete" 
                            {...field}
                            value={field.value || ""} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <div className="text-sm text-slate-400">
                          🔐 Clé secrète envoyée dans l'en-tête Authorization pour sécuriser vos webhooks
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>

              <div className="flex gap-4 pt-6">
                <Button
                  type="submit"
                  disabled={createEventMutation.isPending}
                  className="bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 neon-glow flex-1"
                >
                  {createEventMutation.isPending ? "Création..." : "Publier l'événement"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation("/")}
                  className="border-slate-600 text-slate-300 hover:bg-slate-800"
                >
                  Annuler
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
