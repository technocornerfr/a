import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Music, Menu, LogOut, BarChart3, MessageCircle, Building, Settings, Trash2, Search, Scan } from "lucide-react";
import { MobileMenu } from "../mobile-menu";
import { apiRequest, queryClient } from "@/lib/queryClient";

export function Header() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Vérifier l'état de connexion
  const { data: currentUser } = useQuery({
    queryKey: ["/api/auth/current"],
    queryFn: () => apiRequest("GET", "/api/auth/current"),
    retry: false,
  });

  const handleLogout = async () => {
    // Nettoyer le cache immédiatement
    queryClient.clear();
    
    // Faire l'appel de déconnexion en arrière-plan
    try {
      await apiRequest("POST", "/api/auth/logout");
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error);
    }
    
    // Forcer un rechargement complet de la page
    window.location.reload();
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-md border-b border-primary/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center neon-glow">
                <Music className="text-white text-lg" />
              </div>
              <h1 className="font-mono font-bold text-xl text-white">TechnoCorner</h1>
            </Link>

            {/* Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/">
                <span className={`text-slate-300 hover:text-primary transition-colors duration-300 ${location === '/' ? 'text-primary' : ''}`}>
                  Événements
                </span>
              </Link>



              <Link href="/community">
                <span className={`text-slate-300 hover:text-primary transition-colors duration-300 ${location === '/community' ? 'text-primary' : ''}`}>
                  Communauté
                </span>
              </Link>

              <Link href="/about">
                <span className={`text-slate-300 hover:text-primary transition-colors duration-300 ${location === '/about' ? 'text-primary' : ''}`}>
                  À propos
                </span>
              </Link>

              {currentUser && (
                <Link href={`/profile/${currentUser.id}`}>
                  <span className={`text-slate-300 hover:text-primary transition-colors duration-300 ${location.startsWith('/profile') ? 'text-primary' : ''}`}>
                    Profil
                  </span>
                </Link>
              )}

              <Link href="/organizer">
                <span className={`text-slate-300 hover:text-secondary transition-colors duration-300 ${location === '/organizer' ? 'text-secondary' : ''}`}>
                  <Building className="w-4 h-4 inline mr-1" />
                  Organisateur
                </span>
              </Link>




              
              {currentUser && (
                <Link href="/manage-events">
                  <span className={`text-slate-300 hover:text-primary transition-colors duration-300 ${location === '/manage-events' ? 'text-primary' : ''}`}>
                    <Settings className="w-4 h-4 inline mr-1" />
                    Mes événements
                  </span>
                </Link>
              )}
              
              {!currentUser && (
                <Link href="/login">
                  <span className={`text-slate-300 hover:text-primary transition-colors duration-300 ${location === '/login' ? 'text-primary' : ''}`}>
                    Connexion
                  </span>
                </Link>
              )}
            </nav>

            {/* CTA Button */}
            {currentUser ? (
              <Button 
                onClick={handleLogout}
                className="hidden md:block bg-gradient-to-r from-red-500 to-red-600 hover:scale-105 transition-all duration-300 neon-glow"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Se déconnecter
              </Button>
            ) : (
              <Link href="/register" className="hidden md:block">
                <Button className="bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 neon-glow">
                  S'inscrire
                </Button>
              </Link>
            )}

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-slate-300 hover:text-primary"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="text-xl" />
            </Button>
          </div>
        </div>
      </header>

      <MobileMenu 
        isOpen={isMobileMenuOpen} 
        onClose={() => setIsMobileMenuOpen(false)} 
      />
    </>
  );
}
