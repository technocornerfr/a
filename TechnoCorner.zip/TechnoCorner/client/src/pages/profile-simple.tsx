import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowLeft, Edit, Save, X, User as UserIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { type User as UserType } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const { toast } = useToast();

  // Get current authenticated user
  const { data: user, isLoading } = useQuery<UserType>({
    queryKey: ["/api/auth/current"],
  });

  // Simple state for form fields
  const [formData, setFormData] = useState({
    email: "",
    firstName: "",
    lastName: "",
    bio: "",
    city: "",
    country: "",
    website: "",
    profileImageUrl: "",
  });

  // Reset form when user data loads
  useEffect(() => {
    if (user) {
      setFormData({
        email: user.email || "",
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        bio: user.bio || "",
        city: user.city || "",
        country: user.country || "",
        website: user.website || "",
        profileImageUrl: user.profileImageUrl || "",
      });
    }
  }, [user]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      if (!user?.id) throw new Error('Utilisateur non connecté');
      
      console.log('🚀 Sending data to server:', data);
      console.log('🌐 URL:', `/api/user/${user.id}`);
      
      const response = await fetch(`/api/user/${user.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      console.log('📡 Response status:', response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Server error:', errorText);
        throw new Error(`Erreur ${response.status}: ${errorText}`);
      }
      
      const result = await response.json();
      console.log('✅ Success response:', result);
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/current"] });
      setIsEditing(false);
      toast({
        title: "Profil mis à jour",
        description: "Vos informations ont été sauvegardées avec succès.",
      });
    },
    onError: (error) => {
      console.error('💥 Mutation error:', error);
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour le profil.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    console.log('🎯 handleSubmit called');
    console.log('📝 Form data:', formData);
    updateProfileMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-cyan-400 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-center">
          <h2 className="text-2xl font-bold mb-4">Utilisateur non trouvé</h2>
          <Link href="/">
            <Button>Retour à l'accueil</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header avec navigation */}
          <div className="flex items-center gap-4 mb-8">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Retour
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-white">Profil utilisateur</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Colonne de gauche - Photo et infos de base */}
            <div className="lg:col-span-1">
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardContent className="p-6 text-center">
                  <div className="relative inline-block mb-4">
                    {user.profileImageUrl ? (
                      <img
                        src={user.profileImageUrl}
                        alt="Photo de profil"
                        className="w-32 h-32 rounded-full object-cover border-4 border-cyan-400/20"
                      />
                    ) : (
                      <div className="w-32 h-32 rounded-full bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center border-4 border-cyan-400/20">
                        <UserIcon className="w-16 h-16 text-white" />
                      </div>
                    )}
                  </div>
                  
                  <h2 className="text-2xl font-bold text-white mb-2">
                    @{user.username}
                  </h2>
                  
                  {user.firstName || user.lastName ? (
                    <p className="text-slate-300 text-lg mb-4">
                      {user.firstName} {user.lastName}
                    </p>
                  ) : null}
                  
                  {user.city && (
                    <p className="text-slate-400 mb-2">{user.city}{user.country && `, ${user.country}`}</p>
                  )}
                  
                  {user.website && (
                    <a 
                      href={user.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-cyan-400 hover:text-cyan-300 text-sm"
                    >
                      {user.website}
                    </a>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Colonne de droite - Informations détaillées */}
            <div className="lg:col-span-2">
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardHeader className="border-b border-slate-700">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-white text-xl">
                      Informations personnelles
                    </CardTitle>
                    <Button
                      onClick={() => setIsEditing(!isEditing)}
                      variant="outline"
                      size="sm"
                      className="border-slate-600 text-slate-300 hover:text-white"
                    >
                      {isEditing ? (
                        <>
                          <X className="w-4 h-4 mr-2" />
                          Annuler
                        </>
                      ) : (
                        <>
                          <Edit className="w-4 h-4 mr-2" />
                          Modifier
                        </>
                      )}
                    </Button>
                  </div>
                </CardHeader>

                <CardContent className="p-6">
                  {isEditing ? (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-slate-300 text-sm font-medium mb-2 block">Prénom</label>
                          <Input
                            placeholder="Votre prénom"
                            className="bg-slate-700/50 border-slate-600 text-white"
                            value={formData.firstName}
                            onChange={(e) => handleInputChange('firstName', e.target.value)}
                          />
                        </div>

                        <div>
                          <label className="text-slate-300 text-sm font-medium mb-2 block">Nom</label>
                          <Input
                            placeholder="Votre nom"
                            className="bg-slate-700/50 border-slate-600 text-white"
                            value={formData.lastName}
                            onChange={(e) => handleInputChange('lastName', e.target.value)}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-slate-300 text-sm font-medium mb-2 block">Email</label>
                        <Input
                          type="email"
                          placeholder="votre@email.com"
                          className="bg-slate-700/50 border-slate-600 text-white"
                          value={formData.email}
                          onChange={(e) => handleInputChange('email', e.target.value)}
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 text-sm font-medium mb-2 block">URL de la photo de profil</label>
                        <Input
                          placeholder="https://exemple.com/photo.jpg"
                          className="bg-slate-700/50 border-slate-600 text-white"
                          value={formData.profileImageUrl}
                          onChange={(e) => handleInputChange('profileImageUrl', e.target.value)}
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 text-sm font-medium mb-2 block">Bio</label>
                        <Textarea
                          placeholder="Parlez-nous de vous..."
                          className="bg-slate-700/50 border-slate-600 text-white"
                          value={formData.bio}
                          onChange={(e) => handleInputChange('bio', e.target.value)}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-slate-300 text-sm font-medium mb-2 block">Ville</label>
                          <Input
                            placeholder="Paris"
                            className="bg-slate-700/50 border-slate-600 text-white"
                            value={formData.city}
                            onChange={(e) => handleInputChange('city', e.target.value)}
                          />
                        </div>

                        <div>
                          <label className="text-slate-300 text-sm font-medium mb-2 block">Pays</label>
                          <Input
                            placeholder="France"
                            className="bg-slate-700/50 border-slate-600 text-white"
                            value={formData.country}
                            onChange={(e) => handleInputChange('country', e.target.value)}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-slate-300 text-sm font-medium mb-2 block">Site web</label>
                        <Input
                          placeholder="https://monsite.com"
                          className="bg-slate-700/50 border-slate-600 text-white"
                          value={formData.website}
                          onChange={(e) => handleInputChange('website', e.target.value)}
                        />
                      </div>

                      <div className="flex gap-3 pt-4">
                        <Button
                          onClick={handleSubmit}
                          disabled={updateProfileMutation.isPending}
                          className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700"
                        >
                          <Save className="w-4 h-4 mr-2" />
                          {updateProfileMutation.isPending ? "Sauvegarde..." : "Sauvegarder"}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {user.bio && (
                        <div>
                          <h3 className="text-slate-300 text-sm font-medium mb-2">Bio</h3>
                          <p className="text-white whitespace-pre-wrap">{user.bio}</p>
                        </div>
                      )}
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {user.email && (
                          <div>
                            <h3 className="text-slate-300 text-sm font-medium mb-2">Email</h3>
                            <p className="text-white">{user.email}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}