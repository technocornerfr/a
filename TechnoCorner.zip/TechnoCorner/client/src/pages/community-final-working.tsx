import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Heart, MessageCircle, Share2, RefreshCw } from "lucide-react";
import { Header } from "@/components/layout/header";
import { useAuth } from "@/hooks/useAuth";

interface Post {
  id: number;
  content: string;
  imageUrl?: string | null;
  type: string;
  likesCount: number;
  commentsCount: number;
  createdAt: string;
  userId: number;
  author: {
    id: number;
    username: string;
    profileImageUrl?: string | null;
  };
  comments?: any[];
}

export default function CommunityFinalWorking() {
  const [feedMode, setFeedMode] = useState<"recommended" | "recent">("recent");
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();

  const loadPosts = async () => {
    setLoading(true);
    setError("");
    
    try {
      const url = feedMode === "recommended" ? "/api/posts/recommended" : "/api/posts";
      console.log(`Loading posts from: ${url}`);
      
      const response = await fetch(url);
      console.log(`Response status: ${response.status}`);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      console.log(`Received data:`, { type: typeof data, isArray: Array.isArray(data), length: data?.length });
      
      if (Array.isArray(data)) {
        setPosts(data);
        console.log(`Successfully set ${data.length} posts`);
      } else {
        console.error("Data is not an array:", data);
        setPosts([]);
        setError("Format de données invalide");
      }
    } catch (err: any) {
      console.error("Error loading posts:", err);
      setError(err.message);
      setPosts([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPosts();
  }, [feedMode]);

  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      const now = new Date();
      const hours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
      
      if (hours < 1) return "À l'instant";
      if (hours < 24) return `Il y a ${hours}h`;
      const days = Math.floor(hours / 24);
      if (days < 7) return `Il y a ${days}j`;
      
      return date.toLocaleDateString('fr-FR');
    } catch {
      return "Date inconnue";
    }
  };

  const handleLike = (postId: number) => {
    if (!isAuthenticated) {
      toast({
        title: "Connexion requise",
        description: "Connectez-vous pour liker",
        variant: "destructive",
      });
      return;
    }

    fetch(`/api/posts/${postId}/like`, {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    })
    .then(response => {
      if (response.ok) {
        toast({ title: "Post liké!" });
        loadPosts();
      }
    })
    .catch(() => {
      toast({
        title: "Erreur",
        description: "Impossible de liker",
        variant: "destructive",
      });
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800">
      <Header />
      
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-4">
              Communauté TechnoCorner
            </h1>
            <p className="text-lg text-slate-300">
              Découvrez les discussions de la communauté techno
            </p>
          </div>

          <div className="flex justify-center mb-8">
            <div className="bg-slate-900/50 backdrop-blur-sm border border-primary/20 rounded-lg p-1 flex items-center">
              <Button
                variant={feedMode === "recommended" ? "default" : "ghost"}
                onClick={() => setFeedMode("recommended")}
                className={`px-6 py-2 rounded-md transition-all duration-300 ${
                  feedMode === "recommended" 
                    ? "bg-gradient-to-r from-primary to-secondary text-white shadow-lg" 
                    : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                }`}
              >
                Recommandés
              </Button>
              <Button
                variant={feedMode === "recent" ? "default" : "ghost"}
                onClick={() => setFeedMode("recent")}
                className={`px-6 py-2 rounded-md transition-all duration-300 ${
                  feedMode === "recent" 
                    ? "bg-gradient-to-r from-primary to-secondary text-white shadow-lg" 
                    : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                }`}
              >
                Chronologique
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={loadPosts}
                disabled={loading}
                className="ml-2 text-slate-400 hover:text-white"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>

          <div className="space-y-6">
            {loading && (
              <div className="text-center text-slate-400 py-8">
                <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4" />
                Chargement des posts...
              </div>
            )}

            {error && (
              <Card className="bg-red-900/20 border-red-500/20">
                <CardContent className="p-6 text-center">
                  <p className="text-red-400">Erreur: {error}</p>
                  <Button onClick={loadPosts} className="mt-4" variant="outline">
                    Réessayer
                  </Button>
                </CardContent>
              </Card>
            )}

            {!loading && !error && posts.length === 0 && (
              <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                <CardContent className="p-6 text-center">
                  <p className="text-slate-400">Aucun post disponible</p>
                  <Button onClick={loadPosts} className="mt-4" variant="outline">
                    Actualiser
                  </Button>
                </CardContent>
              </Card>
            )}

            {!loading && posts.length > 0 && posts.map((post) => (
              <Card key={post.id} className="bg-slate-900/50 backdrop-blur-sm border-primary/20 hover:border-primary/40 transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={post.author.profileImageUrl ?? undefined} />
                      <AvatarFallback className="bg-gradient-to-r from-primary to-secondary text-white">
                        {post.author.username[0]?.toUpperCase() || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h4 className="font-semibold text-white">{post.author.username}</h4>
                      <p className="text-sm text-slate-400">{formatDate(post.createdAt)}</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <p className="text-slate-200 leading-relaxed whitespace-pre-wrap">{post.content}</p>
                  </div>

                  {post.imageUrl && post.imageUrl !== null && (
                    <div className="mb-4">
                      <img 
                        src={post.imageUrl} 
                        alt="Post" 
                        className="rounded-lg max-w-full h-auto"
                      />
                    </div>
                  )}

                  <Separator className="mb-4 bg-slate-700" />

                  <div className="flex items-center space-x-6 mb-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleLike(post.id)}
                      className="text-slate-400 hover:text-red-400 transition-colors"
                    >
                      <Heart className="w-4 h-4 mr-2" />
                      {post.likesCount}
                    </Button>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-slate-400 hover:text-blue-400 transition-colors"
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      {post.commentsCount}
                    </Button>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-slate-400 hover:text-green-400 transition-colors"
                    >
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* Section des commentaires */}
                  {post.comments && Array.isArray(post.comments) && post.comments.length > 0 && (
                    <div className="mt-4">
                      <Separator className="mb-3 bg-slate-700" />
                      <h5 className="text-sm font-medium text-slate-300 mb-3">
                        Commentaires ({post.comments.length})
                      </h5>
                      <div className="space-y-3">
                        {post.comments.map((comment: any) => (
                          <div key={comment.id || Math.random()} className="flex space-x-3">
                            <Avatar className="w-6 h-6 flex-shrink-0">
                              <AvatarImage src={comment.author?.profileImageUrl || undefined} />
                              <AvatarFallback className="bg-gradient-to-r from-primary/50 to-secondary/50 text-white text-xs">
                                {comment.author?.username?.[0]?.toUpperCase() || "U"}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="bg-slate-800/50 rounded-lg px-3 py-2">
                                <div className="flex items-center space-x-2 mb-1">
                                  <span className="text-sm font-medium text-slate-200">
                                    {comment.author?.username || "Utilisateur"}
                                  </span>
                                  <span className="text-xs text-slate-400">
                                    {comment.createdAt ? formatDate(comment.createdAt) : ""}
                                  </span>
                                </div>
                                <p className="text-sm text-slate-300 leading-relaxed">
                                  {comment.content || ""}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}

            {!loading && posts.length > 0 && (
              <div className="text-center py-6">
                <p className="text-slate-400">{posts.length} posts affichés</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}