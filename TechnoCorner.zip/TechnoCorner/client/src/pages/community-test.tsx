import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/header";

export default function CommunityTest() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");

  const testAPI = async () => {
    setLoading(true);
    setError("");
    setData(null);

    try {
      console.log("Starting API test...");
      const response = await fetch("/api/posts");
      console.log("Response received:", response.status, response.statusText);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await response.json();
      console.log("Data parsed:", result);
      console.log("Data type:", typeof result);
      console.log("Is array:", Array.isArray(result));
      console.log("Length:", result?.length);
      
      setData(result);
      
    } catch (err: any) {
      console.error("API test failed:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800">
      <Header />
      
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-4">Test API Posts</h1>
          </div>

          <div className="mb-6">
            <Button onClick={testAPI} disabled={loading} className="w-full">
              {loading ? "Test en cours..." : "Tester l'API Posts"}
            </Button>
          </div>

          {error && (
            <Card className="bg-red-900/20 border-red-500/20 mb-6">
              <CardContent className="p-4">
                <h3 className="text-red-400 font-semibold mb-2">Erreur:</h3>
                <p className="text-red-300">{error}</p>
              </CardContent>
            </Card>
          )}

          {data && (
            <Card className="bg-green-900/20 border-green-500/20 mb-6">
              <CardContent className="p-4">
                <h3 className="text-green-400 font-semibold mb-2">Succès!</h3>
                <div className="text-green-300 space-y-1">
                  <p>Type: {typeof data}</p>
                  <p>Est un tableau: {Array.isArray(data) ? "Oui" : "Non"}</p>
                  <p>Nombre d'éléments: {Array.isArray(data) ? data.length : "N/A"}</p>
                </div>
              </CardContent>
            </Card>
          )}

          {data && Array.isArray(data) && data.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-white">Posts récupérés:</h2>
              {data.slice(0, 3).map((post: any) => (
                <Card key={post.id} className="bg-slate-900/50 border-primary/20">
                  <CardContent className="p-4">
                    <div className="text-white">
                      <p><strong>ID:</strong> {post.id}</p>
                      <p><strong>Auteur:</strong> {post.author?.username || "Inconnu"}</p>
                      <p><strong>Contenu:</strong> {post.content?.substring(0, 100)}...</p>
                      <p><strong>Likes:</strong> {post.likesCount || 0}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {data.length > 3 && (
                <p className="text-slate-400 text-center">
                  ... et {data.length - 3} autres posts
                </p>
              )}
            </div>
          )}

          {data && Array.isArray(data) && data.length === 0 && (
            <Card className="bg-yellow-900/20 border-yellow-500/20">
              <CardContent className="p-4">
                <p className="text-yellow-400">L'API retourne un tableau vide</p>
              </CardContent>
            </Card>
          )}

          {data && !Array.isArray(data) && (
            <Card className="bg-orange-900/20 border-orange-500/20">
              <CardContent className="p-4">
                <h3 className="text-orange-400 font-semibold mb-2">Données reçues (pas un tableau):</h3>
                <pre className="text-orange-300 text-sm overflow-auto">
                  {JSON.stringify(data, null, 2)}
                </pre>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}