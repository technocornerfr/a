import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, MapPin, User, Mail, QrCode, Download } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function TicketDetail() {
  const { ticketId } = useParams();
  
  const { data: ticket, isLoading } = useQuery({
    queryKey: ["/api/tickets", ticketId],
    enabled: !!ticketId,
  });

  const { data: qrCodeData } = useQuery({
    queryKey: ["/api/tickets", ticketId, "qrcode"],
    enabled: !!ticketId,
  });

  const downloadQRCode = () => {
    if (qrCodeData?.qrCode) {
      const link = document.createElement('a');
      link.download = `billet-${ticket?.id}-qrcode.png`;
      link.href = qrCodeData.qrCode;
      link.click();
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black p-6">
        <div className="max-w-2xl mx-auto">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-700 rounded w-1/3"></div>
            <div className="h-96 bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!ticket) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black p-6">
        <div className="max-w-2xl mx-auto text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Billet non trouvé</h1>
          <p className="text-gray-400">Ce billet n'existe pas ou a été supprimé.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black p-6">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-8 text-center">
          🎫 Mon Billet Techno
        </h1>

        <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm">
          <CardHeader className="text-center border-b border-purple-500/20">
            <CardTitle className="text-2xl text-white">{ticket.event?.title}</CardTitle>
            <Badge 
              variant={ticket.status === "confirmed" ? "default" : "secondary"}
              className={ticket.status === "confirmed" 
                ? "bg-green-600 text-white" 
                : "bg-gray-600 text-white"
              }
            >
              {ticket.status === "confirmed" ? "✓ Confirmé" : "En attente"}
            </Badge>
          </CardHeader>

          <CardContent className="space-y-6 p-6">
            {/* Informations de l'événement */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3 text-gray-300">
                <CalendarDays className="h-5 w-5 text-purple-400" />
                <span>
                  {ticket.event?.date 
                    ? format(new Date(ticket.event.date), "EEEE d MMMM yyyy", { locale: fr })
                    : "Date à confirmer"
                  }
                </span>
              </div>
              
              <div className="flex items-center space-x-3 text-gray-300">
                <MapPin className="h-5 w-5 text-purple-400" />
                <span>{ticket.event?.venue || "Lieu à confirmer"}</span>
              </div>
            </div>

            {/* Informations du détenteur */}
            <div className="border-t border-purple-500/20 pt-4 space-y-3">
              <h3 className="text-lg font-semibold text-white">Détenteur du billet</h3>
              <div className="flex items-center space-x-3 text-gray-300">
                <User className="h-5 w-5 text-purple-400" />
                <span>{ticket.buyerName}</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <Mail className="h-5 w-5 text-purple-400" />
                <span>{ticket.buyerEmail}</span>
              </div>
            </div>

            {/* QR Code */}
            <div className="border-t border-purple-500/20 pt-6 text-center">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center justify-center space-x-2">
                <QrCode className="h-5 w-5 text-purple-400" />
                <span>QR Code d'entrée</span>
              </h3>
              
              {qrCodeData?.qrCode ? (
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg inline-block">
                    <img 
                      src={qrCodeData.qrCode} 
                      alt="QR Code du billet" 
                      className="w-48 h-48 mx-auto"
                    />
                  </div>
                  <p className="text-sm text-gray-400 max-w-md mx-auto">
                    Présentez ce QR code à l'entrée de l'événement. 
                    Vous pouvez le télécharger ou prendre une capture d'écran.
                  </p>
                  <Button 
                    onClick={downloadQRCode}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Télécharger le QR code
                  </Button>
                </div>
              ) : (
                <div className="text-gray-400">
                  <QrCode className="h-24 w-24 mx-auto mb-4 opacity-50" />
                  <p>Génération du QR code en cours...</p>
                </div>
              )}
            </div>

            {/* Informations du billet */}
            <div className="border-t border-purple-500/20 pt-4 text-sm text-gray-400 space-y-2">
              <div className="flex justify-between">
                <span>ID du billet:</span>
                <span className="font-mono">#{ticket.id}</span>
              </div>
              <div className="flex justify-between">
                <span>Date d'achat:</span>
                <span>
                  {format(new Date(ticket.purchaseDate), "dd/MM/yyyy à HH:mm", { locale: fr })}
                </span>
              </div>
              {ticket.ticketCode && (
                <div className="flex justify-between">
                  <span>Code:</span>
                  <span className="font-mono">{ticket.ticketCode}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-400">
            ⚡ TechnoCorner - Votre passeport pour la scène électronique ⚡
          </p>
        </div>
      </div>
    </div>
  );
}