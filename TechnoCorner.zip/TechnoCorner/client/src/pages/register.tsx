import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Music, UserPlus } from "lucide-react";
import { insertUserSchema } from "@shared/schema";

const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(6, "Le mot de passe doit contenir au moins 6 caractères"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Les mots de passe ne correspondent pas",
  path: ["confirmPassword"],
});

type RegisterFormData = z.infer<typeof registerSchema>;

export default function Register() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Vérifier si l'utilisateur est déjà connecté
  const { data: currentUser } = useQuery({
    queryKey: ["/api/auth/current"],
    queryFn: () => apiRequest("GET", "/api/auth/current"),
    retry: false,
  });

  // Rediriger si déjà connecté
  useEffect(() => {
    if (currentUser) {
      setLocation("/");
    }
  }, [currentUser, setLocation]);

  const form = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegisterFormData) => {
      const { confirmPassword, ...userData } = data;
      return apiRequest("POST", "/api/auth/register", userData);
    },
    onSuccess: () => {
      toast({
        title: "Inscription réussie!",
        description: "Votre compte a été créé avec succès. Vous pouvez maintenant vous connecter.",
      });
      setLocation("/login");
    },
    onError: (error: any) => {
      toast({
        title: "Erreur d'inscription",
        description: error.message || "Une erreur est survenue lors de la création du compte.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: RegisterFormData) => {
    registerMutation.mutate(data);
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto mb-4 neon-glow">
              <Music className="text-white text-2xl" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Inscription</h1>
            <p className="text-slate-300">Rejoignez la communauté TechnoCorner</p>
          </div>

          <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-white text-center">
                Créer un compte
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Nom d'utilisateur</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Choisissez un nom d'utilisateur" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Mot de passe</FormLabel>
                        <FormControl>
                          <Input 
                            type="password"
                            placeholder="Créez un mot de passe (min. 6 caractères)" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Confirmer le mot de passe</FormLabel>
                        <FormControl>
                          <Input 
                            type="password"
                            placeholder="Confirmez votre mot de passe" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    disabled={registerMutation.isPending}
                    className="w-full bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 neon-glow"
                  >
                    <UserPlus className="w-4 h-4 mr-2" />
                    {registerMutation.isPending ? "Création..." : "Créer mon compte"}
                  </Button>
                </form>
              </Form>

              <div className="mt-6 text-center">
                <p className="text-slate-400">
                  Déjà un compte ?{" "}
                  <Link href="/login">
                    <span className="text-primary hover:text-secondary transition-colors cursor-pointer">
                      Se connecter
                    </span>
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}