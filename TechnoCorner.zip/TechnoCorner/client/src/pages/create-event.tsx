import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { CreateEventForm } from "@/components/create-event-form";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function CreateEvent() {
  const { user: currentUser, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto">
            <div className="animate-pulse space-y-4">
              <div className="h-8 bg-gray-700 rounded w-1/3 mx-auto"></div>
              <div className="h-96 bg-gray-700 rounded"></div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto text-center">
            <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
              <CardHeader>
                <CardTitle className="text-white text-2xl">
                  🎵 Connexion requise
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-slate-300 text-lg">
                  Vous devez être connecté pour créer un événement sur TechnoCorner
                </p>
                <p className="text-slate-400">
                  Connectez-vous pour partager votre passion pour la musique électronique et organiser des événements inoubliables !
                </p>
                <div className="flex gap-4 justify-center">
                  <Link href="/login">
                    <Button className="bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 neon-glow">
                      Se connecter
                    </Button>
                  </Link>
                  <Link href="/register">
                    <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10">
                      S'inscrire
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 techno-gradient">
              Créer un événement
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Partagez votre passion pour la techno et créez un événement mémorable
            </p>
          </div>
          <CreateEventForm />
        </div>
      </main>
      <Footer />
    </div>
  );
}
