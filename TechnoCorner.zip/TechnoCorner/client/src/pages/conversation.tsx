import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useRoute } from "wouter";
import { ArrowLeft, Send, User as UserIcon, Phone, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { type User as UserType } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";

interface Message {
  id: number;
  senderId: number;
  receiverId: number;
  content: string;
  createdAt: string;
  isRead: number;
}

export default function Conversation() {
  const [match, params] = useRoute("/conversation/:userId");
  const otherUserId = params?.userId ? parseInt(params.userId) : null;
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Get current authenticated user
  const { data: currentUser } = useQuery<UserType>({
    queryKey: ["/api/auth/current"],
    queryFn: async () => {
      const response = await fetch('/api/auth/current', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        },
        credentials: 'include'
      });
      
      if (!response.ok) {
        return null;
      }
      
      return response.json();
    },
    staleTime: 0,
    gcTime: 0,
  });

  // Get other user info
  const { data: otherUser } = useQuery<UserType>({
    queryKey: ["/api/user", otherUserId],
    queryFn: async () => {
      if (!otherUserId) return null;
      
      const response = await fetch(`/api/user/${otherUserId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        },
        credentials: 'include'
      });
      
      if (!response.ok) return null;
      return response.json();
    },
    enabled: !!otherUserId,
  });

  // Get conversation messages
  const { data: messages = [], refetch: refetchMessages } = useQuery<Message[]>({
    queryKey: ["/api/messages/conversation", otherUserId],
    queryFn: async () => {
      if (!otherUserId) return [];
      
      const response = await fetch(`/api/messages/conversation/${otherUserId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        },
        credentials: 'include'
      });
      
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!otherUserId && !!currentUser,
    refetchInterval: 3000, // Poll every 3 seconds for new messages
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!otherUserId) throw new Error("Utilisateur destinataire manquant");
      
      const response = await apiRequest("POST", "/api/messages/send", {
        receiverId: otherUserId,
        content: content.trim(),
      });
      return response;
    },
    onSuccess: () => {
      setNewMessage("");
      refetchMessages();
      toast({
        title: "Message envoyé !",
        description: "Votre message a été envoyé avec succès.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Impossible d'envoyer le message.",
        variant: "destructive",
      });
    },
  });

  // Mark messages as read when conversation opens
  useEffect(() => {
    if (otherUserId && currentUser) {
      fetch(`/api/messages/conversation/${otherUserId}/read`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include'
      });
    }
  }, [otherUserId, currentUser]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    sendMessageMutation.mutate(newMessage);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-center max-w-md mx-auto">
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg p-8">
            <UserIcon className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-4">Connexion requise</h2>
            <p className="text-slate-300 mb-6">
              Vous devez être connecté pour accéder aux messages.
            </p>
            <Link href="/login">
              <Button className="bg-gradient-to-r from-primary to-secondary">
                Se connecter
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (!otherUserId || !otherUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-center max-w-md mx-auto">
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg p-8">
            <UserIcon className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-4">Utilisateur non trouvé</h2>
            <p className="text-slate-300 mb-6">
              Cet utilisateur n'existe pas ou n'est pas accessible.
            </p>
            <Link href="/">
              <Button variant="outline">
                Retour à l'accueil
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header avec navigation */}
          <div className="flex items-center justify-between mb-6 bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg p-4">
            <div className="flex items-center gap-4">
              <Link href="/community">
                <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Retour
                </Button>
              </Link>
              
              <div className="flex items-center gap-3">
                <Avatar className="w-10 h-10 ring-2 ring-cyan-400/30">
                  <AvatarImage src={otherUser.profileImageUrl || undefined} />
                  <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-purple-500 text-white">
                    {otherUser.username.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                
                <div>
                  <Link href={`/profile/${otherUser.id}`}>
                    <h2 className="text-white font-semibold hover:text-cyan-400 transition-colors">
                      @{otherUser.username}
                    </h2>
                  </Link>
                  {otherUser.firstName || otherUser.lastName ? (
                    <p className="text-slate-400 text-sm">
                      {otherUser.firstName} {otherUser.lastName}
                    </p>
                  ) : null}
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <Phone className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <Video className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Zone de messages */}
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg overflow-hidden">
            {/* Messages container */}
            <div className="h-96 overflow-y-auto p-4 space-y-4">
              {messages.length === 0 ? (
                <div className="text-center text-slate-400 py-8">
                  <UserIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Aucun message pour le moment.</p>
                  <p className="text-sm">Commencez la conversation !</p>
                </div>
              ) : (
                messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        message.senderId === currentUser.id
                          ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white'
                          : 'bg-slate-700 text-slate-200'
                      }`}
                    >
                      <p className="break-words">{message.content}</p>
                      <p className={`text-xs mt-1 ${
                        message.senderId === currentUser.id ? 'text-cyan-100' : 'text-slate-400'
                      }`}>
                        {new Date(message.createdAt).toLocaleTimeString('fr-FR', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input zone */}
            <div className="border-t border-slate-700 p-4">
              <div className="flex gap-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Tapez votre message..."
                  className="flex-1 bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-cyan-400"
                  disabled={sendMessageMutation.isPending}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim() || sendMessageMutation.isPending}
                  className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}