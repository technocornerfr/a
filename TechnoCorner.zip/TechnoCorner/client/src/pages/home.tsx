import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, Rocket, Users, TrendingUp } from "lucide-react";
import { EventCard } from "@/components/event-card";
import { EventFilters } from "@/components/event-filters";
import type { Event } from "@shared/schema";
import type { EventFilters as EventFiltersType, EventStats } from "@/lib/types";

export default function Home() {
  const [filters, setFilters] = useState<EventFiltersType>({
    category: "all",
    search: "",
    sortBy: "date",
  });
  const [searchInput, setSearchInput] = useState("");

  // Fetch events with forced refresh
  const { data: eventsData, isLoading: eventsLoading } = useQuery<Event[]>({
    queryKey: ["/api/events", filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.category !== "all") params.append("category", filters.category);
      if (filters.search) params.append("search", filters.search);
      if (filters.sortBy) params.append("sortBy", filters.sortBy);
      const response = await fetch(`/api/events?${params.toString()}`, {
        headers: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      console.log("Events data received:", data);
      console.log("Events array length:", Array.isArray(data) ? data.length : 'not array');
      return Array.isArray(data) ? data : [];
    },
    staleTime: 0,
    gcTime: 0,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });

  const events = Array.isArray(eventsData) ? eventsData : [];

  // Fetch stats
  const { data: stats } = useQuery<EventStats>({
    queryKey: ["/api/stats"],
  });

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFilters({ ...filters, search: searchInput });
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          {/* Floating Elements */}
          <div className="absolute top-20 left-10 w-20 h-20 bg-primary/20 rounded-full blur-xl floating-animation"></div>
          <div className="absolute top-40 right-20 w-32 h-32 bg-secondary/20 rounded-full blur-xl floating-animation" style={{ animationDelay: "1s" }}></div>
          <div className="absolute bottom-20 left-1/3 w-24 h-24 bg-accent/20 rounded-full blur-xl floating-animation" style={{ animationDelay: "2s" }}></div>

          <div className="text-center relative z-10">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 techno-gradient">
              TechnoCorner
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 mb-8 max-w-3xl mx-auto leading-relaxed">
              Découvrez les meilleurs événements de musique techno. 
              Connectez-vous avec la scène électronique, créez votre profil et tissez des liens avec la communauté techno.
            </p>
            
            {/* Search Bar */}
            <div className="max-w-2xl mx-auto mb-12">
              <form onSubmit={handleSearchSubmit} className="relative">
                <Input
                  type="text"
                  placeholder="Rechercher des événements..."
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  className="w-full px-6 py-4 bg-slate-900/80 backdrop-blur-sm border border-primary/30 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-300"
                />
                <Button 
                  type="submit"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-primary to-secondary px-6 py-2 rounded-xl text-white neon-glow hover:scale-105 transition-all duration-300"
                >
                  <Search className="w-4 h-4" />
                </Button>
              </form>
            </div>


          </div>
        </div>
      </section>

      {/* Event Filters */}
      <EventFilters filters={filters} onFiltersChange={setFilters} />

      {/* Featured Events Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">

          {eventsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="bg-slate-900/50 backdrop-blur-sm rounded-2xl overflow-hidden border border-primary/20 animate-pulse">
                  <div className="h-48 bg-slate-800"></div>
                  <CardContent className="p-6">
                    <div className="h-4 bg-slate-800 rounded mb-2"></div>
                    <div className="h-6 bg-slate-800 rounded mb-3"></div>
                    <div className="h-4 bg-slate-800 rounded mb-3"></div>
                    <div className="h-4 bg-slate-800 rounded mb-4"></div>
                    <div className="flex justify-between">
                      <div className="h-6 w-16 bg-slate-800 rounded"></div>
                      <div className="h-10 w-24 bg-slate-800 rounded"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : Array.isArray(events) && events.length > 0 ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {events.map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
              
              {/* Load More Button */}
              <div className="text-center mt-12">
                <Button className="bg-gradient-to-r from-primary to-secondary px-8 py-3 rounded-xl text-white font-medium hover:scale-105 transition-all duration-300 neon-glow">
                  Charger plus d'événements
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <p className="text-xl text-slate-400 mb-4">Aucun événement trouvé</p>
              <p className="text-slate-500 mb-8">Essayez de modifier vos filtres ou créez le premier événement!</p>
              <Link href="/create">
                <Button className="bg-gradient-to-r from-primary to-secondary neon-glow">
                  Créer un événement
                </Button>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Create Event CTA */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-primary/20 via-secondary/20 to-accent/20 relative overflow-hidden">
        <div className="max-w-4xl mx-auto text-center relative z-10">
          {/* Floating Elements */}
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-primary/30 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-accent/30 rounded-full blur-2xl animate-pulse" style={{ animationDelay: "1s" }}></div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Organisez votre événement
          </h2>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Partagez votre passion pour la techno avec la communauté. 
            Créez et promouvez vos événements en quelques clics.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/create">
              <Button className="bg-gradient-to-r from-primary to-secondary px-8 py-4 rounded-xl text-white font-semibold text-lg hover:scale-105 transition-all duration-300 pulse-glow">
                <TrendingUp className="w-5 h-5 mr-2" />
                Créer un événement
              </Button>
            </Link>
            <Button 
              variant="outline" 
              className="border-2 border-primary px-8 py-4 rounded-xl text-primary font-semibold text-lg hover:bg-primary hover:text-white transition-all duration-300"
            >
              <Users className="w-5 h-5 mr-2" />
              En savoir plus
            </Button>
          </div>
          
          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto mb-4 neon-glow">
                <Rocket className="text-white text-2xl" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Publication rapide</h3>
              <p className="text-slate-300">Publiez votre événement en moins de 5 minutes</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-secondary to-accent rounded-2xl flex items-center justify-center mx-auto mb-4 neon-glow-secondary">
                <Users className="text-white text-2xl" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Large audience</h3>
              <p className="text-slate-300">Touchez des milliers de passionnés de techno</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-accent to-primary rounded-2xl flex items-center justify-center mx-auto mb-4 neon-glow-accent">
                <TrendingUp className="text-white text-2xl" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Analytics</h3>
              <p className="text-slate-300">Suivez les performances de vos événements</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
