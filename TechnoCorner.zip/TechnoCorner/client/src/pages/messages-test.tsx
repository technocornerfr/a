import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export default function MessagesTest() {
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Test avec utilisateur ID 5 (Banger)
  const otherUserId = 5;

  const fetchMessages = async () => {
    setLoading(true);
    console.log("=== TEST RÉCUPÉRATION MESSAGES ===");
    
    try {
      const response = await fetch(`/api/messages/conversation/${otherUserId}`, {
        credentials: "include"
      });
      
      console.log("Statut de la réponse:", response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log("Messages récupérés:", data);
        setMessages(data);
      } else {
        console.log("Erreur:", await response.text());
        setMessages([]);
      }
    } catch (error) {
      console.error("Erreur de récupération:", error);
      setMessages([]);
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    console.log("=== ENVOI MESSAGE TEST ===");
    
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({
          senderId: 2, // ID root
          receiverId: otherUserId,
          content: newMessage
        })
      });

      if (response.ok) {
        toast({
          title: "Message envoyé !",
          description: "Votre message a été envoyé avec succès."
        });
        setNewMessage("");
        fetchMessages(); // Recharger les messages
      } else {
        toast({
          title: "Erreur",
          description: "Impossible d'envoyer le message"
        });
      }
    } catch (error) {
      console.error("Erreur d'envoi:", error);
      toast({
        title: "Erreur",
        description: "Erreur lors de l'envoi du message"
      });
    }
  };

  useEffect(() => {
    fetchMessages();
  }, []);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Test Messagerie - Conversation avec Banger</h1>
      
      <Card className="p-4 mb-4">
        <div className="flex gap-2 mb-4">
          <Button onClick={fetchMessages} disabled={loading}>
            {loading ? "Chargement..." : "Actualiser les messages"}
          </Button>
        </div>
        
        <div className="space-y-2 mb-4 max-h-96 overflow-y-auto">
          {messages.length === 0 ? (
            <p className="text-gray-500">Aucun message trouvé</p>
          ) : (
            messages.map((message: any) => (
              <div
                key={message.id}
                className={`p-3 rounded-lg ${
                  message.senderId === 2
                    ? "bg-blue-100 ml-auto max-w-xs"
                    : "bg-gray-100 mr-auto max-w-xs"
                }`}
              >
                <p className="text-sm text-gray-600">
                  {message.senderId === 2 ? "Moi" : "Banger"} - {new Date(message.createdAt).toLocaleString()}
                </p>
                <p>{message.content}</p>
              </div>
            ))
          )}
        </div>
        
        <div className="flex gap-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Tapez votre message..."
            onKeyPress={(e) => e.key === "Enter" && sendMessage()}
          />
          <Button onClick={sendMessage}>Envoyer</Button>
        </div>
      </Card>
      
      <div className="mt-4 p-4 bg-gray-50 rounded">
        <p className="text-sm text-gray-600">
          Total de messages affichés: {messages.length}
        </p>
        <p className="text-sm text-gray-600">
          Vérifiez la console du navigateur pour les logs détaillés
        </p>
      </div>
    </div>
  );
}