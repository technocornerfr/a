import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow, format, isToday, isYesterday } from "date-fns";
import { fr } from "date-fns/locale";
import { Link } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Send, 
  Image, 
  Music,
  Calendar,
  MapPin,
  Trash2,
  MoreHorizontal,
  Users,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import type { Post, PostComment, User } from "@shared/schema";

interface PostWithDetails extends Post {
  author: User;
  isLiked: boolean;
  likesCount: number;
  commentsCount: number;
  comments?: (PostComment & { author: User })[];
}

export default function Community() {
  const [newPostContent, setNewPostContent] = useState("");
  const [newPostImage, setNewPostImage] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [expandedComments, setExpandedComments] = useState<Set<number>>(new Set());
  const [commentInputs, setCommentInputs] = useState<Record<number, string>>({});
  const [feedMode, setFeedMode] = useState<"recommended" | "recent">("recommended");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Récupérer l'utilisateur actuel
  const { user: currentUser, isAuthenticated } = useAuth();

  // Fonction pour formater les dates de façon intelligente
  const formatPostDate = (dateInput: any) => {
    if (!dateInput) return 'Date inconnue';
    
    try {
      let date: Date;
      
      // Si c'est déjà une Date
      if (dateInput instanceof Date) {
        date = dateInput;
      } 
      // Si c'est une string
      else if (typeof dateInput === 'string') {
        // Remplacer l'espace par un T pour le format ISO si nécessaire
        const cleanedDate = dateInput.replace(' ', 'T');
        date = new Date(cleanedDate);
      } 
      // Sinon essayer de convertir
      else {
        date = new Date(dateInput);
      }
      
      // Vérifier que la date est valide
      if (!date || isNaN(date.getTime())) {
        console.warn('Date invalide:', dateInput);
        return 'Date inconnue';
      }
      
      const now = new Date();
      
      if (isToday(date)) {
        return `Aujourd'hui à ${format(date, 'HH:mm')}`;
      } else if (isYesterday(date)) {
        return `Hier à ${format(date, 'HH:mm')}`;
      } else {
        const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
        if (diffInDays < 7) {
          return formatDistanceToNow(date, { addSuffix: true, locale: fr });
        } else {
          return format(date, 'dd MMM yyyy à HH:mm', { locale: fr });
        }
      }
    } catch (error) {
      console.error('Erreur de formatage de date:', error, 'Input:', dateInput);
      return 'il y a quelques instants';
    }
  };

  // Fonctions pour gérer le drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    const mediaFiles = files.filter(file => 
      file.type.startsWith('image/') || file.type.startsWith('video/')
    );
    
    if (mediaFiles.length > 0) {
      setUploadedFiles(prev => [...prev, ...mediaFiles]);
      toast({
        title: "Fichiers ajoutés !",
        description: `${mediaFiles.length} fichier(s) prêt(s) à être partagé(s).`,
      });
    } else {
      toast({
        title: "Format non supporté",
        description: "Veuillez déposer des images ou des vidéos uniquement.",
        variant: "destructive",
      });
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const mediaFiles = files.filter(file => 
      file.type.startsWith('image/') || file.type.startsWith('video/')
    );
    
    if (mediaFiles.length > 0) {
      setUploadedFiles(prev => [...prev, ...mediaFiles]);
      toast({
        title: "Fichiers sélectionnés !",
        description: `${mediaFiles.length} fichier(s) prêt(s) à être partagé(s).`,
      });
    }
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  // Fonction pour compresser les vidéos avant upload
  const compressVideo = async (file: File): Promise<File> => {
    // Pour les vidéos, on limite la taille
    if (file.size > 10 * 1024 * 1024) { // Plus de 10MB
      toast({
        title: "Vidéo trop volumineuse",
        description: "Veuillez choisir une vidéo de moins de 10MB pour un chargement optimal.",
        variant: "destructive",
      });
      throw new Error("Video too large");
    }
    return file;
  };

  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Récupérer les posts selon le mode sélectionné
  const { data: posts, isLoading, error } = useQuery<PostWithDetails[]>({
    queryKey: feedMode === "recommended" ? ["/api/posts/recommended"] : ["/api/posts"],
    queryFn: getQueryFn({ on401: "returnEmpty" }),
  });

  // Les posts à afficher - toujours utiliser les posts récupérés avec vérification null
  const displayedPosts = Array.isArray(posts) ? posts : [];
  
  // Debug: Log post data to see what's being received
  console.log("Community component - posts data:", posts);
  console.log("Community component - displayed posts:", displayedPosts);
  if (displayedPosts.length > 0) {
    const post1 = displayedPosts.find(p => p.id === 1);
    if (post1) {
      console.log("Post 1 in frontend:", post1);
      console.log("Post 1 comments in frontend:", post1.comments);
    }
  }

  // Mutation pour enregistrer les interactions utilisateur
  const recordInteractionMutation = useMutation({
    mutationFn: async ({ postId, type, value }: { postId: number; type: string; value?: number }) => {
      return apiRequest("POST", `/api/posts/${postId}/interaction`, { type, value });
    },
    onError: (error) => {
      console.log("Erreur lors de l'enregistrement de l'interaction:", error);
      // Ne pas afficher d'erreur à l'utilisateur car c'est en arrière-plan
    },
  });

  // Mutation pour créer un nouveau post
  const createPostMutation = useMutation({
    mutationFn: async (postData: { content: string; imageUrl?: string; mediaFiles?: string[] }) => {
      return apiRequest("POST", "/api/posts", postData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setNewPostContent("");
      setNewPostImage("");
      setUploadedFiles([]);
      toast({
        title: "Post publié !",
        description: "Votre post a été partagé avec la communauté.",
      });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de publier votre post.",
        variant: "destructive",
      });
    },
  });

  // Mutation pour liker/unliker un post
  const likeMutation = useMutation({
    mutationFn: async ({ postId, isLiked }: { postId: number; isLiked: boolean }) => {
      // Enregistrer l'interaction pour l'algorithme de recommandation
      recordInteractionMutation.mutate({ postId, type: "like", value: isLiked ? -1 : 1 });
      return apiRequest("POST", `/api/posts/${postId}/${isLiked ? 'unlike' : 'like'}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/recommended"] });
    },
  });

  // Mutation pour ajouter un commentaire
  const commentMutation = useMutation({
    mutationFn: async ({ postId, content }: { postId: number; content: string }) => {
      // Enregistrer l'interaction pour l'algorithme de recommandation
      recordInteractionMutation.mutate({ postId, type: "comment", value: 2.0 });
      return apiRequest("POST", `/api/posts/${postId}/comments`, { content });
    },
    onSuccess: (_, { postId }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/recommended"] });
      setCommentInputs(prev => ({ ...prev, [postId]: "" }));
      toast({
        title: "Commentaire ajouté !",
        description: "Votre commentaire a été publié.",
      });
    },
  });

  // Mutation pour supprimer un commentaire
  const deleteCommentMutation = useMutation({
    mutationFn: async (commentId: number) => {
      const response = await apiRequest("DELETE", `/api/comments/${commentId}`);
      if (!response.ok) {
        throw new Error('Erreur lors de la suppression du commentaire');
      }
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Commentaire supprimé !",
        description: "Le commentaire a été supprimé avec succès.",
      });
    },
    onError: (error) => {
      console.error("Erreur suppression commentaire:", error);
      toast({
        title: "Erreur",
        description: "Impossible de supprimer le commentaire. Veuillez réessayer.",
        variant: "destructive",
      });
    },
  });

  const handleCreatePost = async () => {
    if (!newPostContent.trim() && uploadedFiles.length === 0) return;
    
    try {
      // Vérifier et compresser les fichiers si nécessaire
      const processedFiles = await Promise.all(
        uploadedFiles.map(async (file) => {
          if (file.type.startsWith('video/')) {
            return await compressVideo(file);
          }
          return file;
        })
      );
      
      // Afficher un indicateur de chargement plus détaillé
      toast({
        title: "Publication en cours...",
        description: `Traitement de ${processedFiles.length} fichier(s)`,
      });
      
      // Convertir les fichiers en base64 de façon optimisée
      const mediaFiles = await Promise.all(
        processedFiles.map(async (file, index) => {
          // Mise à jour du progrès
          if (processedFiles.length > 1) {
            toast({
              title: "Traitement...",
              description: `Fichier ${index + 1}/${processedFiles.length}`,
            });
          }
          return await convertFileToBase64(file);
        })
      );
      
      const postData = {
        content: newPostContent,
        imageUrl: newPostImage || undefined,
        mediaFiles: mediaFiles.length > 0 ? mediaFiles : undefined,
      };
      
      createPostMutation.mutate(postData);
    } catch (error) {
      console.error("Erreur lors de la création du post:", error);
      if ((error as Error).message === "Video too large") {
        return; // Le toast d'erreur a déjà été affiché
      }
      toast({
        title: "Erreur",
        description: "Impossible de traiter les fichiers uploadés.",
        variant: "destructive",
      });
    }
  };

  const handleLike = (postId: number, isLiked: boolean) => {
    likeMutation.mutate({ postId, isLiked });
  };

  const handleComment = (postId: number) => {
    const content = commentInputs[postId]?.trim();
    if (!content) return;
    
    commentMutation.mutate({ postId, content });
  };

  // Mutation pour supprimer un post
  const deleteMutation = useMutation({
    mutationFn: async (postId: number) => {
      return apiRequest("DELETE", `/api/posts/${postId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Post supprimé !",
        description: "Votre post a été supprimé avec succès.",
      });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de supprimer le post.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (postId: number) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer ce post ?")) {
      deleteMutation.mutate(postId);
    }
  };

  const toggleComments = (postId: number) => {
    setExpandedComments(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
        // Enregistrer une interaction de vue prolongée quand l'utilisateur ouvre les commentaires
        if (currentUser) {
          recordInteractionMutation.mutate({ postId, type: "view", value: 1.5 });
        }
      }
      return newSet;
    });
  };

  // Afficher un message d'invitation pour les utilisateurs non connectés, mais permettre la lecture
  const LoginPrompt = () => (
    <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20 mb-6">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Rejoignez la conversation !</h3>
            <p className="text-slate-300 text-sm">
              Connectez-vous pour partager vos expériences techno avec la communauté
            </p>
          </div>
          <Button 
            onClick={() => window.location.href = '/login'}
            className="bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300"
          >
            Se connecter
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              Communauté TechnoCorner
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Partagez vos moments techno, découvrez de nouveaux artistes et connectez-vous avec la communauté
            </p>
          </div>

          <div className="flex flex-col lg:grid lg:grid-cols-3 gap-8">
            {/* Feed principal */}
            <div className="w-full lg:col-span-2 space-y-6">
              {/* Afficher l'invitation à se connecter ou le formulaire de création */}
              {!currentUser ? (
                <LoginPrompt />
              ) : (
                <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                  <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Send className="w-5 h-5 mr-2 text-primary" />
                    Partager avec la communauté
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <Avatar>
                      <AvatarImage src={currentUser.profileImageUrl || undefined} />
                      <AvatarFallback className="bg-primary text-white">
                        {currentUser.username?.[0]?.toUpperCase() || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <Textarea
                        placeholder="Quoi de neuf dans la scène techno ? Partagez vos découvertes, vos sets préférés, vos prochains événements..."
                        value={newPostContent}
                        onChange={(e) => setNewPostContent(e.target.value)}
                        className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400 min-h-[100px] resize-none"
                      />
                    </div>
                  </div>
                  
                  {/* Zone de drag and drop pour les fichiers */}
                  <div className="space-y-3">
                    <Label className="text-white text-sm">Photos et vidéos</Label>
                    <div
                      className={`relative border-2 border-dashed rounded-lg p-6 transition-all duration-300 ${
                        isDragOver 
                          ? 'border-primary bg-primary/10 scale-105' 
                          : 'border-slate-600 hover:border-slate-500'
                      }`}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                    >
                      <input
                        type="file"
                        multiple
                        accept="image/*,video/*"
                        onChange={handleFileSelect}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      <div className="text-center">
                        <Image className={`mx-auto h-12 w-12 mb-4 ${isDragOver ? 'text-primary' : 'text-slate-400'}`} />
                        <p className={`text-sm ${isDragOver ? 'text-primary' : 'text-slate-300'}`}>
                          {isDragOver 
                            ? 'Déposez vos fichiers ici !' 
                            : 'Glissez-déposez vos photos/vidéos ou cliquez pour sélectionner'
                          }
                        </p>
                        <p className="text-xs text-slate-500 mt-2">
                          Formats supportés: Images (JPG, PNG, GIF) et Vidéos (MP4, WebM)
                        </p>
                      </div>
                    </div>

                    {/* Aperçu des fichiers uploadés */}
                    {uploadedFiles.length > 0 && (
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {uploadedFiles.map((file, index) => (
                          <div key={index} className="relative group">
                            <div className="aspect-square bg-slate-800 rounded-lg overflow-hidden">
                              {file.type.startsWith('image/') ? (
                                <img
                                  src={URL.createObjectURL(file)}
                                  alt={file.name}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                  <div className="text-center">
                                    <div className="w-8 h-8 mx-auto mb-2 bg-secondary rounded-full flex items-center justify-center">
                                      <span className="text-white text-xs">▶</span>
                                    </div>
                                    <p className="text-xs text-slate-300 truncate px-2">{file.name}</p>
                                  </div>
                                </div>
                              )}
                            </div>
                            <button
                              onClick={() => removeFile(index)}
                              className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Option URL d'image classique */}
                    <div>
                      <Label htmlFor="postImage" className="text-white text-sm">Ou ajouter une image par URL</Label>
                      <Input
                        id="postImage"
                        placeholder="https://example.com/image.jpg"
                        value={newPostImage}
                        onChange={(e) => setNewPostImage(e.target.value)}
                        className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                      />
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="flex space-x-2">
                      <Badge variant="outline" className="text-slate-400 border-slate-600">
                        <Image className="w-3 h-3 mr-1" />
                        Photo
                      </Badge>
                      <Badge variant="outline" className="text-slate-400 border-slate-600">
                        <Music className="w-3 h-3 mr-1" />
                        Track
                      </Badge>
                      <Badge variant="outline" className="text-slate-400 border-slate-600">
                        <Calendar className="w-3 h-3 mr-1" />
                        Événement
                      </Badge>
                    </div>
                    <Button 
                      onClick={handleCreatePost}
                      disabled={(!newPostContent.trim() && uploadedFiles.length === 0) || createPostMutation.isPending}
                      className="bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300"
                    >
                      {createPostMutation.isPending ? (
                        <div className="flex items-center space-x-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          <span>Publication...</span>
                        </div>
                      ) : "Publier"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* Onglets pour choisir le type de feed */}
              {currentUser && (
                <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-white">Feed</h3>
                      <div className="flex bg-slate-800 rounded-lg p-1">
                        <button
                          onClick={() => setFeedMode("recommended")}
                          className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-200 ${
                            feedMode === "recommended"
                              ? "bg-gradient-to-r from-primary to-secondary text-white shadow-lg"
                              : "text-slate-400 hover:text-white"
                          }`}
                        >
                          Recommandé
                        </button>
                        <button
                          onClick={() => setFeedMode("recent")}
                          className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-200 ${
                            feedMode === "recent"
                              ? "bg-gradient-to-r from-primary to-secondary text-white shadow-lg"
                              : "text-slate-400 hover:text-white"
                          }`}
                        >
                          Récent
                        </button>
                      </div>
                    </div>
                    {feedMode === "recommended" && (
                      <p className="text-sm text-slate-400 mt-2">
                        Contenu personnalisé basé sur vos préférences et interactions
                      </p>
                    )}
                    {feedMode === "recent" && (
                      <p className="text-sm text-slate-400 mt-2">
                        Posts les plus récents de la communauté
                      </p>
                    )}
                  </CardHeader>
                </Card>
              )}

              {/* Liste des posts */}
              {isLoading ? (
                <div className="space-y-6">
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} className="bg-slate-900/50 backdrop-blur-sm border-slate-700">
                      <CardContent className="p-6">
                        <div className="animate-pulse">
                          <div className="flex items-center space-x-3 mb-4">
                            <div className="w-10 h-10 bg-slate-700 rounded-full"></div>
                            <div className="space-y-2">
                              <div className="h-4 bg-slate-700 rounded w-24"></div>
                              <div className="h-3 bg-slate-700 rounded w-16"></div>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <div className="h-4 bg-slate-700 rounded"></div>
                            <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (!displayedPosts || displayedPosts.length === 0) ? (
                <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-700">
                  <CardContent className="p-12 text-center">
                    <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Aucun post pour le moment</h3>
                    <p className="text-slate-400">
                      Soyez le premier à partager quelque chose avec la communauté !
                    </p>
                  </CardContent>
                </Card>
              ) : (
                displayedPosts.map((post) => (
                  <Card key={post.id} className="bg-slate-900/50 backdrop-blur-sm border-slate-700 relative">
                    <CardContent className="p-6">
                      {/* Indicateur de recommandation */}
                      {feedMode === "recommended" && (post as any).recommendationScore > 0 && (
                        <div className="absolute top-2 right-2 bg-gradient-to-r from-primary to-secondary text-white px-2 py-1 rounded-full text-xs font-medium flex items-center">
                          ✨ Recommandé
                          {(post as any).recommendationScore > 20 && <span className="ml-1">🔥</span>}
                        </div>
                      )}
                      
                      {/* En-tête du post */}
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={post.author.profileImageUrl || undefined} />
                            <AvatarFallback className="bg-secondary text-white">
                              {post.author.username?.[0]?.toUpperCase() || "U"}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 
                              className="font-semibold text-white hover:text-cyan-400 transition-colors cursor-pointer"
                              onClick={() => window.location.href = `/profile/${post.author.id}`}
                            >
                              @{post.author.username}
                            </h3>
                            <p className="text-sm text-slate-400">
                              {formatPostDate(post.createdAt)}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          {/* Bouton de suppression - toujours visible pour tester */}
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleDelete(post.id)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                            disabled={deleteMutation.isPending}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Contenu du post */}
                      <div className="mb-4">
                        <p className="text-white leading-relaxed whitespace-pre-wrap">{post.content}</p>
                        {post.imageUrl && (
                          <div className="mt-4">
                            {post.type === 'video' ? (
                              <div className="relative bg-black rounded-lg overflow-hidden">
                                <video 
                                  src={post.imageUrl} 
                                  controls
                                  className="w-full max-h-96 object-contain"
                                  preload="metadata"
                                  style={{ maxHeight: '400px' }}
                                >
                                  Votre navigateur ne supporte pas la lecture vidéo.
                                </video>
                                <div className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                                  📹 Vidéo
                                </div>
                              </div>
                            ) : (
                              <div className="relative">
                                <img 
                                  src={post.imageUrl} 
                                  alt="Post media" 
                                  className="w-full rounded-lg max-h-96 object-cover cursor-pointer hover:opacity-95 transition-opacity"
                                  onClick={() => {
                                    // Ouvrir l'image en plein écran
                                    const modal = document.createElement('div');
                                    modal.className = 'fixed inset-0 bg-black/90 flex items-center justify-center z-50 cursor-pointer';
                                    modal.innerHTML = `<img src="${post.imageUrl}" class="max-w-full max-h-full object-contain">`;
                                    modal.onclick = () => document.body.removeChild(modal);
                                    document.body.appendChild(modal);
                                  }}
                                />
                                <div className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                                  🖼️ Image
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      <Separator className="bg-slate-700 mb-4" />

                      {/* Actions du post */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-6">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleLike(post.id, post.isLiked)}
                            className={`text-slate-400 hover:text-red-400 ${post.isLiked ? 'text-red-400' : ''}`}
                          >
                            <Heart className={`w-4 h-4 mr-2 ${post.isLiked ? 'fill-current' : ''}`} />
                            {post.likesCount}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleComments(post.id)}
                            className="text-slate-400 hover:text-blue-400 transition-colors"
                          >
                            <MessageCircle className="w-4 h-4 mr-2" />
                            {post.commentsCount} commentaire{post.commentsCount !== 1 ? 's' : ''}
                            {expandedComments.has(post.id) ? (
                              <ChevronUp className="w-4 h-4 ml-2" />
                            ) : (
                              <ChevronDown className="w-4 h-4 ml-2" />
                            )}
                          </Button>
                          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-green-400">
                            <Share2 className="w-4 h-4 mr-2" />
                            Partager
                          </Button>
                        </div>
                      </div>

                      {/* Section commentaires - affichage forcé pour debug */}
                      <div className="mt-4 pt-4 border-t border-slate-700">
                        <div className="mb-2 text-slate-400 text-sm">
                          Debug: {post.comments?.length || 0} commentaires trouvés
                        </div>
                        {post.comments && post.comments.length > 0 ? (
                          <div className="space-y-3">
                            {post.comments.map((comment) => (
                              <div key={comment.id} className="flex items-start space-x-3">
                                <Avatar className="w-8 h-8">
                                  <AvatarImage src={comment.author.profileImageUrl || undefined} />
                                  <AvatarFallback className="bg-accent text-white text-xs">
                                    {comment.author.username?.[0]?.toUpperCase() || "U"}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                  <div className="bg-slate-800/50 rounded-lg p-3">
                                    <div className="flex items-center space-x-2 mb-1">
                                      <span className="font-semibold text-white text-sm">
                                        {comment.author.username}
                                      </span>
                                      <span className="text-xs text-slate-400">
                                        {formatPostDate(comment.createdAt)}
                                      </span>
                                    </div>
                                    <p className="text-slate-300 text-sm">{comment.content}</p>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-slate-400 text-sm">Aucun commentaire pour ce post</div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

            {/* Sidebar */}
            <div className="w-full lg:w-auto space-y-6 order-last lg:order-none">
              {/* Informations sur l'algorithme de recommandation */}
              {currentUser && feedMode === "recommended" && (
                <Card className="bg-gradient-to-br from-primary/10 to-secondary/10 backdrop-blur-sm border-primary/30">
                  <CardHeader>
                    <CardTitle className="text-white text-lg flex items-center">
                      <div className="w-2 h-2 bg-primary rounded-full mr-2 animate-pulse"></div>
                      IA Recommandation
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm text-slate-300">
                      <p className="mb-2">Notre IA analyse vos interactions pour personnaliser votre feed :</p>
                      <ul className="space-y-1 text-xs text-slate-400">
                        <li>• Utilisateurs suivis</li>
                        <li>• Posts likés et commentés</li>
                        <li>• Genres musicaux préférés</li>
                        <li>• Engagement récent</li>
                      </ul>
                    </div>
                    <Separator className="bg-slate-700" />
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">Algorithme actif</span>
                      <span className="text-primary font-medium">✨ Smart Feed</span>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Événements trending */}
              <Card className="bg-slate-900/50 backdrop-blur-sm border-accent/20">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Trending Events</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-accent" />
                      <span className="text-white text-sm font-medium">Underground Session</span>
                    </div>
                    <div className="flex items-center space-x-2 text-xs text-slate-400">
                      <MapPin className="w-3 h-3" />
                      <span>Paris - 30 Mai</span>
                    </div>
                  </div>
                  <Separator className="bg-slate-700" />
                  <div className="text-center">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full border-accent text-accent hover:bg-accent hover:text-white"
                      onClick={() => window.location.href = '/'}
                    >
                      Voir tous les événements
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}