import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Ticket, CreditCard, CheckCircle } from "lucide-react";
import type { Event } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";

// Charger Stripe avec la clé publique
const stripePublishableKey = import.meta.env.VITE_STRIPE_PUBLIC_KEY;

if (!stripePublishableKey) {
  console.warn('Missing Stripe publishable key - checkout functionality will be limited');
}

const stripePromise = stripePublishableKey ? loadStripe(stripePublishableKey) : Promise.resolve(null);

// Fonction utilitaire pour valider les emails
const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Composant pour les réservations gratuites avec QR code
interface FreeTicketBookingProps {
  event: Event;
  buyerInfo: {
    name: string;
    email: string;
  };
}

const FreeTicketBooking = ({ event, buyerInfo }: FreeTicketBookingProps) => {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const freeTicketMutation = useMutation({
    mutationFn: async () => {
      // Créer un billet gratuit directement sans passer par Stripe
      const response = await apiRequest("POST", "/api/free-ticket", {
        eventId: event.id,
        buyerName: buyerInfo.name,
        buyerEmail: buyerInfo.email
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la réservation");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      const { ticket, emailSent } = data;
      
      toast({
        title: "Réservation confirmée !",
        description: emailSent 
          ? "Votre billet gratuit a été envoyé par email et est disponible ci-dessous."
          : "Votre billet gratuit est prêt ! Vous pouvez le télécharger et l'imprimer.",
      });
      
      // Rediriger vers la page de succès avec les données du billet
      const ticketParams = new URLSearchParams({
        ticket: encodeURIComponent(JSON.stringify(ticket)),
        emailSent: emailSent.toString()
      });
      
      setTimeout(() => {
        setLocation(`/ticket-success?${ticketParams.toString()}`);
      }, 1500);
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur de réservation",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const isFormValid = buyerInfo.name.trim() && buyerInfo.email.trim() && isValidEmail(buyerInfo.email);

  return (
    <div className="space-y-4">
      <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-4">
        <div className="flex items-center gap-3 mb-2">
          <CheckCircle className="w-5 h-5 text-green-400" />
          <h4 className="text-green-400 font-semibold">Événement gratuit</h4>
        </div>
        <p className="text-green-300 text-sm">
          Cet événement est gratuit ! Confirmez simplement vos informations pour recevoir votre billet avec QR code d'entrée.
        </p>
      </div>

      <Button
        onClick={() => freeTicketMutation.mutate()}
        disabled={!isFormValid || freeTicketMutation.isPending}
        className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
      >
        {freeTicketMutation.isPending ? (
          <>
            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
            Génération du billet...
          </>
        ) : (
          <>
            <Ticket className="w-4 h-4 mr-2" />
            Confirmer ma réservation gratuite
          </>
        )}
      </Button>

      <div className="text-xs text-slate-400 text-center">
        Vous recevrez votre billet par email avec un QR code pour l'entrée
      </div>
    </div>
  );
};

interface CheckoutFormProps {
  event: Event;
  clientSecret: string;
  buyerInfo: {
    name: string;
    email: string;
  };
  onSuccess: () => void;
}

const CheckoutForm = ({ event, clientSecret, buyerInfo, onSuccess }: CheckoutFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      console.log("Confirmation du paiement en cours...");
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/checkout-success?eventId=${event.id}`,
          receipt_email: buyerInfo.email,
        },
        redirect: "if_required"
      });

      console.log("Résultat confirmation:", { error, paymentIntent });

      if (error) {
        console.error("Erreur Stripe:", error);
        toast({
          title: "Erreur de paiement",
          description: error.message || "Erreur lors du traitement du paiement",
          variant: "destructive",
        });
      } else if (paymentIntent && paymentIntent.status === 'succeeded') {
        console.log("Paiement réussi:", paymentIntent.id);
        
        // Générer automatiquement le billet avec QR code
        try {
          const ticketResponse = await apiRequest("POST", "/api/complete-purchase", {
            paymentIntentId: paymentIntent.id
          });
          
          const ticketData = await ticketResponse.json();
          console.log("Billet généré:", ticketData);
          
          // Stocker les données du billet pour la page de téléchargement
          localStorage.setItem('lastTicket', JSON.stringify(ticketData.ticket));
          
          toast({
            title: "Paiement réussi!",
            description: "Votre billet a été généré avec un QR code. Vous allez être redirigé vers la page de téléchargement.",
          });
          
          // Rediriger vers la page de téléchargement
          setTimeout(() => {
            window.location.href = "/ticket-download";
          }, 1500);
        } catch (ticketError) {
          console.error("Erreur génération billet:", ticketError);
          toast({
            title: "Paiement réussi, mais...",
            description: "Le billet n'a pas pu être généré automatiquement. Contactez le support.",
            variant: "destructive",
          });
        }
      } else {
        console.log("Statut inattendu:", paymentIntent?.status);
        toast({
          title: "Paiement en attente",
          description: "Votre paiement est en cours de traitement.",
          variant: "default",
        });
      }
    } catch (error: any) {
      console.error("Erreur catch:", error);
      toast({
        title: "Erreur",
        description: error?.message || "Une erreur inattendue s'est produite.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="p-4 bg-slate-800/30 rounded-lg border border-slate-700">
        <PaymentElement 
          options={{
            layout: "tabs",
          }}
        />
      </div>
      
      <Button
        type="submit"
        disabled={!stripe || isProcessing}
        className="w-full bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 neon-glow"
      >
        <CreditCard className="w-4 h-4 mr-2" />
        {isProcessing ? "Traitement..." : `Payer ${event.price}`}
      </Button>
    </form>
  );
};

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [clientSecret, setClientSecret] = useState("");
  const [paymentBreakdown, setPaymentBreakdown] = useState<any>(null);
  const [buyerInfo, setBuyerInfo] = useState({
    name: "",
    email: "",
  });

  // Récupérer l'ID de l'événement depuis l'URL
  const urlParams = new URLSearchParams(window.location.search);
  const eventId = urlParams.get('eventId');

  // Récupérer les détails de l'événement
  const { data: event, isLoading: eventLoading } = useQuery<Event>({
    queryKey: ['/api/events', eventId],
    queryFn: () => fetch(`/api/events/${eventId}`).then(res => {
      if (!res.ok) throw new Error("Event not found");
      return res.json();
    }),
    enabled: !!eventId,
  });

  // Validation email simple
  const isValidEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  useEffect(() => {
    if (event && buyerInfo.name.trim() && buyerInfo.email.trim() && isValidEmail(buyerInfo.email)) {
      // Créer le payment intent avec les informations de l'acheteur
      apiRequest("POST", "/api/create-payment-intent", { 
        eventId: event.id, 
        buyerInfo: {
          name: buyerInfo.name.trim(),
          email: buyerInfo.email.trim()
        }
      })
        .then((res) => res.json())
        .then((data) => {
          setClientSecret(data.clientSecret);
          setPaymentBreakdown(data.breakdown);
        })
        .catch(() => {
          toast({
            title: "Erreur",
            description: "Impossible de préparer le paiement.",
            variant: "destructive",
          });
        });
    }
  }, [event, buyerInfo.name, buyerInfo.email]);

  if (!eventId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20 p-4">
        <div className="max-w-md mx-auto pt-20">
          <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
            <CardContent className="p-6 text-center">
              <p className="text-white">Événement non spécifié</p>
              <Button onClick={() => setLocation("/")} className="mt-4">
                Retour à l'accueil
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (eventLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20 p-4">
        <div className="max-w-md mx-auto pt-20">
          <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
            <CardContent className="p-6 text-center">
              <p className="text-white">Événement non trouvé</p>
              <Button onClick={() => setLocation("/")} className="mt-4">
                Retour à l'accueil
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const handleSuccess = () => {
    setLocation(`/event/${event.id}?purchased=true`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20">
      <div className="fixed inset-0 bg-gradient-to-br from-slate-900/50 via-transparent to-transparent pointer-events-none"></div>
      <div className="relative z-10 p-4 sm:p-6 lg:p-8">
        <div className="max-w-4xl mx-auto pt-8">
          <Button
            onClick={() => setLocation(`/event/${event.id}`)}
            variant="ghost"
            className="mb-8 text-slate-400 hover:text-white hover:scale-105 transition-all duration-300"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour à l'événement
          </Button>

          {/* Titre principal avec gradient techno */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              Finaliser votre achat
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Vous êtes à un clic de rejoindre l'événement techno le plus attendu !
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Résumé de l'événement */}
            <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20 hover:border-primary/40 transition-colors duration-300">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Ticket className="w-5 h-5 mr-2 text-primary" />
                  Résumé de votre commande
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-white font-semibold text-xl">{event.title}</h3>
                  <p className="text-slate-400 text-sm">{new Date(event.date).toLocaleDateString('fr-FR', { 
                    weekday: 'long',
                    day: 'numeric', 
                    month: 'long', 
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}</p>
                  <p className="text-slate-400 text-sm">{event.venue}, {event.location}</p>
                </div>
                
                <div className="border-t border-slate-600 pt-4">
                  {(() => {
                    // Nettoyer le prix et vérifier s'il est à 0
                    const cleanPrice = event.price?.toString().replace(/[^\d.,]/g, '') || '0';
                    const numericPrice = parseFloat(cleanPrice.replace(',', '.'));
                    const isFree = numericPrice === 0;
                    const displayPrice = isFree ? "Gratuit" : event.price;
                    
                    return (
                      <>
                        <div className="flex justify-between text-white">
                          <span>Billet d'entrée</span>
                          <span className={`font-semibold ${isFree ? 'text-green-400' : 'text-primary'}`}>
                            {displayPrice}
                          </span>
                        </div>
                        <div className="flex justify-between text-white font-bold text-lg mt-2">
                          <span>Total</span>
                          <span className={`${isFree ? 'text-green-400' : 'text-secondary'}`}>
                            {displayPrice}
                          </span>
                        </div>
                      </>
                    );
                  })()}
                </div>

                {event.ticketsAvailable && (event.ticketsSold || 0) !== undefined && (
                  <div className="text-sm text-slate-400 bg-slate-800/50 p-3 rounded-lg">
                    <span className="text-accent">{(event.ticketsAvailable - (event.ticketsSold || 0))}</span> billets restants sur {event.ticketsAvailable}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Formulaire de paiement */}
            <Card className="bg-slate-900/50 backdrop-blur-sm border-secondary/20 hover:border-secondary/40 transition-colors duration-300">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <CreditCard className="w-5 h-5 mr-2 text-secondary" />
                  Informations de paiement
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Informations acheteur */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="buyerName" className="text-white font-semibold">Nom complet</Label>
                    <Input
                      id="buyerName"
                      value={buyerInfo.name}
                      onChange={(e) => setBuyerInfo(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Votre nom complet"
                      className="bg-slate-800/50 border-slate-600 text-white focus:border-primary hover:border-slate-500 transition-colors"
                    />
                  </div>
                  <div>
                    <Label htmlFor="buyerEmail" className="text-white font-semibold">Email</Label>
                    <Input
                      id="buyerEmail"
                      type="email"
                      value={buyerInfo.email}
                      onChange={(e) => setBuyerInfo(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="votre@email.com"
                      className={`bg-slate-800/50 border-slate-600 text-white focus:border-secondary hover:border-slate-500 transition-colors ${
                        buyerInfo.email && !isValidEmail(buyerInfo.email) 
                          ? 'border-red-500 focus:border-red-500' 
                          : ''
                      }`}
                    />
                    {buyerInfo.email && !isValidEmail(buyerInfo.email) && (
                      <p className="text-red-400 text-sm mt-1">
                        Veuillez saisir une adresse email valide (ex: nom@domaine.com)
                      </p>
                    )}
                  </div>
                </div>

                {/* Décomposition des frais */}
                {paymentBreakdown && (
                  <div className="bg-slate-800/30 border border-secondary/20 rounded-lg p-4 space-y-2">
                    <h4 className="text-white font-semibold mb-2">Détail du paiement</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between text-slate-300">
                        <span>Prix du billet</span>
                        <span>{paymentBreakdown.ticketPrice}€</span>
                      </div>
                      <div className="flex justify-between text-slate-400 text-xs">
                        <span>Frais Stripe (2.9% + 0.30€)</span>
                        <span>-{paymentBreakdown.stripeFee}€</span>
                      </div>
                      <div className="flex justify-between text-slate-400 text-xs">
                        <span>Commission plateforme (2.5%)</span>
                        <span>-{paymentBreakdown.platformFee}€</span>
                      </div>
                      <div className="border-t border-slate-600 pt-1 flex justify-between text-accent font-semibold">
                        <span>Revenus organisateur</span>
                        <span>{paymentBreakdown.organizerAmount}€</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Logique conditionnelle selon le type d'événement */}
                {(() => {
                  // Vérifier si l'événement est gratuit
                  const cleanPrice = event.price?.toString().replace(/[^\d.,]/g, '') || '0';
                  const numericPrice = parseFloat(cleanPrice.replace(',', '.'));
                  const isFree = numericPrice === 0;
                  
                  if (isFree) {
                    return <FreeTicketBooking event={event} buyerInfo={buyerInfo} />;
                  } else {
                    // Formulaire de paiement Stripe pour événements payants
                    return clientSecret && buyerInfo.name && buyerInfo.email ? (
                      <Elements key={clientSecret} stripe={stripePromise} options={{ clientSecret }}>
                        <CheckoutForm 
                          event={event} 
                          clientSecret={clientSecret}
                          buyerInfo={buyerInfo}
                          onSuccess={handleSuccess}
                        />
                      </Elements>
                    ) : (
                      <div className="text-center text-slate-400 py-8 bg-slate-800/30 rounded-lg border border-slate-700">
                        {!buyerInfo.name || !buyerInfo.email 
                          ? "Veuillez remplir vos informations pour continuer"
                          : "Préparation du paiement..."
                        }
                      </div>
                    );
                  }
                })()}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}