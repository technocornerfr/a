import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/header";

export default function CommunitySimpleTest() {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const loadPosts = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/posts");
      if (!response.ok) throw new Error("Erreur de chargement");
      const data = await response.json();
      setPosts(Array.isArray(data) ? data : []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPosts();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800">
      <Header />
      
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-4xl font-bold text-white mb-8 text-center">
            Communauté TechnoCorner
          </h1>

          {loading && (
            <div className="text-center text-white py-8">
              Chargement...
            </div>
          )}

          {error && (
            <Card className="bg-red-900/20 border-red-500/20 mb-6">
              <CardContent className="p-4">
                <p className="text-red-400">Erreur: {error}</p>
                <Button onClick={loadPosts} className="mt-4">
                  Réessayer
                </Button>
              </CardContent>
            </Card>
          )}

          {!loading && !error && (
            <div className="space-y-4">
              <p className="text-white text-center">
                {posts.length} posts trouvés
              </p>
              
              {posts.map((post) => (
                <Card key={post.id} className="bg-slate-900/50 border-primary/20">
                  <CardContent className="p-4">
                    <div className="text-white">
                      <div className="flex items-center space-x-2 mb-2">
                        <strong>{post.author?.username || "Utilisateur"}</strong>
                        <span className="text-slate-400 text-sm">
                          {new Date(post.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="mb-2">{post.content}</p>
                      <div className="flex space-x-4 text-sm text-slate-400">
                        <span>❤️ {post.likesCount || 0}</span>
                        <span>💬 {post.commentsCount || 0}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}