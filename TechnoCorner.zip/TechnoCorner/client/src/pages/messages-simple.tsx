import { Link } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { MessageCircle, ArrowLeft, Mail } from "lucide-react";

export default function MessagesPage() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <Card className="bg-slate-800 border-slate-700 p-8">
            <CardContent className="text-center">
              <MessageCircle className="h-16 w-16 text-cyan-400 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-white mb-2">
                Connexion requise
              </h2>
              <p className="text-slate-400">
                Vous devez être connecté pour accéder à vos messages
              </p>
              <div className="mt-6">
                <Link href="/login">
                  <Button className="bg-cyan-600 hover:bg-cyan-700">
                    Se connecter
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col">
      <Header />
      
      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Retour
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-white">Messages privés</h1>
          </div>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-8 text-center">
              <Mail className="h-16 w-16 text-cyan-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-4">
                Système de messagerie en cours de finalisation
              </h3>
              <p className="text-slate-400 mb-6">
                La messagerie privée sera bientôt disponible ! Vous pourrez échanger des messages 
                privés avec les autres membres de la communauté.
              </p>
              <div className="space-y-4">
                <div className="text-left bg-slate-700/50 p-4 rounded-lg">
                  <h4 className="text-white font-medium mb-2">Fonctionnalités à venir :</h4>
                  <ul className="text-slate-300 space-y-1 text-sm">
                    <li>• Messages privés en temps réel</li>
                    <li>• Historique des conversations</li>
                    <li>• Notifications de nouveaux messages</li>
                    <li>• Interface intuitive et responsive</li>
                  </ul>
                </div>
                <Link href="/community">
                  <Button className="bg-cyan-600 hover:bg-cyan-700">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Aller à la communauté
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}