import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, Mail, QrCode, Calendar, MapPin, Euro } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Ticket {
  id: number;
  code: string;
  eventTitle: string;
  eventDate: string;
  venue: string;
  location: string;
  buyerName: string;
  buyerEmail: string;
  qrCode: string;
  price: string;
}

export default function TicketDownload() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [ticketData, setTicketData] = useState<Ticket | null>(null);

  // Récupérer les données du billet depuis l'URL ou le localStorage
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const ticketJson = urlParams.get('ticket') || localStorage.getItem('lastTicket');
    
    if (ticketJson) {
      try {
        const ticket = JSON.parse(decodeURIComponent(ticketJson));
        setTicketData(ticket);
        // Nettoyer le localStorage après affichage
        localStorage.removeItem('lastTicket');
      } catch (error) {
        console.error("Erreur parsing ticket:", error);
        toast({
          title: "Erreur",
          description: "Impossible de charger les données du billet",
          variant: "destructive",
        });
      }
    }
  }, []);

  const downloadTicketImage = () => {
    if (!ticketData) return;

    // Créer un canvas pour générer l'image du billet
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Dimensions du billet
    canvas.width = 800;
    canvas.height = 600;

    // Fond gradient
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, '#667eea');
    gradient.addColorStop(1, '#764ba2');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Fond blanc pour le contenu
    ctx.fillStyle = 'white';
    ctx.fillRect(50, 50, canvas.width - 100, canvas.height - 100);

    // Titre
    ctx.fillStyle = '#333';
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('🎵 TechnoCorner', canvas.width / 2, 120);

    // Titre de l'événement
    ctx.font = 'bold 28px Arial';
    ctx.fillStyle = '#667eea';
    ctx.fillText(ticketData.eventTitle, canvas.width / 2, 170);

    // Informations de l'événement
    ctx.font = '20px Arial';
    ctx.fillStyle = '#333';
    ctx.textAlign = 'left';
    
    const details = [
      `📅 ${new Date(ticketData.eventDate).toLocaleDateString('fr-FR', { 
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
      })}`,
      `📍 ${ticketData.venue}`,
      `🏙️ ${ticketData.location}`,
      `🎫 ${ticketData.code}`,
      `👤 ${ticketData.buyerName}`,
      `💰 ${ticketData.price}`
    ];

    details.forEach((detail, index) => {
      ctx.fillText(detail, 80, 220 + (index * 35));
    });

    // QR Code (si disponible)
    if (ticketData.qrCode) {
      const qrImg = new Image();
      qrImg.onload = () => {
        ctx.drawImage(qrImg, canvas.width - 200, 200, 150, 150);
        
        // Télécharger l'image
        const link = document.createElement('a');
        link.download = `billet-${ticketData.code}.png`;
        link.href = canvas.toDataURL();
        link.click();
      };
      qrImg.src = ticketData.qrCode;
    } else {
      // Télécharger sans QR code
      const link = document.createElement('a');
      link.download = `billet-${ticketData.code}.png`;
      link.href = canvas.toDataURL();
      link.click();
    }

    toast({
      title: "Téléchargement lancé",
      description: "Votre billet a été téléchargé",
    });
  };

  const downloadQRCode = () => {
    if (!ticketData?.qrCode) return;

    const link = document.createElement('a');
    link.download = `qr-code-${ticketData.code}.png`;
    link.href = ticketData.qrCode;
    link.click();

    toast({
      title: "QR Code téléchargé",
      description: "Le QR code a été sauvegardé",
    });
  };

  if (!ticketData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20 flex items-center justify-center p-4">
        <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20 max-w-md">
          <CardContent className="p-6 text-center">
            <h2 className="text-white text-xl mb-4">Billet introuvable</h2>
            <p className="text-slate-400 mb-6">
              Aucune donnée de billet n'a été trouvée. Effectuez d'abord un achat.
            </p>
            <Button onClick={() => setLocation("/")} className="w-full">
              Retour à l'accueil
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20">
      <div className="fixed inset-0 bg-gradient-to-br from-slate-900/50 via-transparent to-transparent pointer-events-none"></div>
      <div className="relative z-10 p-4 sm:p-6 lg:p-8">
        <div className="max-w-4xl mx-auto pt-8">
          <Button
            onClick={() => setLocation("/")}
            variant="ghost"
            className="mb-8 text-slate-400 hover:text-white hover:scale-105 transition-all duration-300"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour à l'accueil
          </Button>

          {/* Titre principal */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              Votre billet électronique
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Téléchargez ou imprimez votre billet pour l'événement
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Billet visuel */}
            <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20 hover:border-primary/40 transition-colors duration-300">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <span className="flex items-center">
                    🎵 TechnoCorner
                  </span>
                  <Badge variant="outline" className="text-primary border-primary">
                    Valide
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold text-white mb-4">{ticketData.eventTitle}</h2>
                  
                  <div className="space-y-3">
                    <div className="flex items-center text-slate-300">
                      <Calendar className="w-5 h-5 mr-3 text-primary" />
                      {new Date(ticketData.eventDate).toLocaleDateString('fr-FR', { 
                        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
                      })}
                    </div>
                    
                    <div className="flex items-center text-slate-300">
                      <MapPin className="w-5 h-5 mr-3 text-primary" />
                      {ticketData.venue}, {ticketData.location}
                    </div>
                    
                    <div className="flex items-center text-slate-300">
                      <Euro className="w-5 h-5 mr-3 text-primary" />
                      {ticketData.price}
                    </div>
                  </div>
                </div>

                <div className="border-t border-slate-600 pt-4">
                  <p className="text-slate-400 text-sm mb-2">Code du billet</p>
                  <code className="bg-slate-800 text-primary px-3 py-2 rounded font-mono text-lg">
                    {ticketData.code}
                  </code>
                </div>

                <div className="border-t border-slate-600 pt-4">
                  <p className="text-slate-400 text-sm mb-2">Titulaire</p>
                  <p className="text-white font-semibold">{ticketData.buyerName}</p>
                  <p className="text-slate-400 text-sm">{ticketData.buyerEmail}</p>
                </div>
              </CardContent>
            </Card>

            {/* QR Code et actions */}
            <Card className="bg-slate-900/50 backdrop-blur-sm border-secondary/20 hover:border-secondary/40 transition-colors duration-300">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <QrCode className="w-5 h-5 mr-2 text-secondary" />
                  QR Code d'entrée
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {ticketData.qrCode && (
                  <div className="text-center">
                    <img 
                      src={ticketData.qrCode} 
                      alt="QR Code du billet" 
                      className="mx-auto border-4 border-secondary/30 rounded-lg max-w-[250px]"
                    />
                    <p className="text-slate-400 text-sm mt-3">
                      Présentez ce QR code à l'entrée de l'événement
                    </p>
                  </div>
                )}

                <div className="space-y-4">
                  <Button 
                    onClick={downloadTicketImage}
                    className="w-full bg-primary hover:bg-primary/80"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Télécharger le billet complet
                  </Button>

                  {ticketData.qrCode && (
                    <Button 
                      onClick={downloadQRCode}
                      variant="outline"
                      className="w-full border-secondary text-secondary hover:bg-secondary/10"
                    >
                      <QrCode className="w-4 h-4 mr-2" />
                      Télécharger QR code seul
                    </Button>
                  )}

                  <div className="bg-slate-800/30 border border-accent/20 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Mail className="w-4 h-4 mr-2 text-accent" />
                      <span className="text-white font-semibold">Email envoyé</span>
                    </div>
                    <p className="text-slate-400 text-sm">
                      Une copie de ce billet a été envoyée à {ticketData.buyerEmail}
                    </p>
                  </div>
                </div>

                <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-4">
                  <h4 className="text-yellow-300 font-semibold mb-2">Conseils importantes</h4>
                  <ul className="text-yellow-200 text-sm space-y-1">
                    <li>• Arrivez 30 minutes avant l'événement</li>
                    <li>• Ayez une pièce d'identité sur vous</li>
                    <li>• Le QR code fonctionne sur téléphone ou imprimé</li>
                    <li>• Conservez ce billet précieusement</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}