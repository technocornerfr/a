import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CalendarIcon, MapPinIcon, UsersIcon, RefreshCwIcon } from "lucide-react";

export default function EventbriteAdmin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreating, setIsCreating] = useState(false);
  const [newEvent, setNewEvent] = useState({
    title: "",
    description: "",
    date: "",
    time: "",
    endTime: "",
    venue: "",
    location: "",
    price: "",
    category: "electronic",
    ticketsAvailable: 100
  });

  // Query for current events
  const { data: events = [], isLoading } = useQuery({
    queryKey: ["/api/events"],
  });

  // Mutation for syncing Eventbrite events
  const syncMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/sync-eventbrite", { method: "POST" });
      return response.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Synchronisation terminée",
        description: `${data.count} événements Eventbrite importés`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur de synchronisation",
        description: error.message || "Impossible de synchroniser avec Eventbrite",
        variant: "destructive",
      });
    },
  });

  // Mutation for creating events
  const createMutation = useMutation({
    mutationFn: async (eventData: any) => {
      const response = await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(eventData),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Événement créé",
        description: "L'événement a été créé avec succès",
      });
      setIsCreating(false);
      setNewEvent({
        title: "",
        description: "",
        date: "",
        time: "",
        endTime: "",
        venue: "",
        location: "",
        price: "",
        category: "electronic",
        ticketsAvailable: 100
      });
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur de création",
        description: error.message || "Impossible de créer l'événement",
        variant: "destructive",
      });
    },
  });

  const handleCreateEvent = () => {
    if (!newEvent.title || !newEvent.date || !newEvent.venue) {
      toast({
        title: "Champs requis",
        description: "Veuillez remplir au minimum le titre, la date et le lieu",
        variant: "destructive",
      });
      return;
    }

    const eventData = {
      ...newEvent,
      organizerEmail: "eventbrite@technocorner.local",
      organizerName: "Eventbrite Import",
      enableTicketing: "true",
      djs: [],
    };

    createMutation.mutate(eventData);
  };

  const eventbriteEvents = Array.isArray(events) ? events.filter((event: any) => 
    event.organizerEmail === "eventbrite@technocorner.local"
  ) : [];
  
  const manualEvents = Array.isArray(events) ? events.filter((event: any) => 
    event.organizerEmail !== "eventbrite@technocorner.local"
  ) : [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-blue-900 text-white p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Administration Eventbrite
          </h1>
          <p className="text-xl text-gray-300">
            Gérez l'intégration avec Eventbrite et créez des événements
          </p>
        </div>

        {/* Synchronization Section */}
        <Card className="bg-gray-900/50 border-purple-500/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-300">
              <RefreshCwIcon className="h-5 w-5" />
              Synchronisation Eventbrite
            </CardTitle>
            <CardDescription>
              Synchronisez automatiquement les événements depuis votre compte Eventbrite
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">
                Événements Eventbrite actuels: {eventbriteEvents.length}
              </span>
              <Button
                onClick={() => syncMutation.mutate()}
                disabled={syncMutation.isPending}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {syncMutation.isPending ? "Synchronisation..." : "Synchroniser"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Manual Event Creation */}
        <Card className="bg-gray-900/50 border-purple-500/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-300">
              <CalendarIcon className="h-5 w-5" />
              Créer un événement manuellement
            </CardTitle>
            <CardDescription>
              Créez des événements directement dans TechnoCorner
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!isCreating ? (
              <Button
                onClick={() => setIsCreating(true)}
                className="bg-green-600 hover:bg-green-700"
              >
                Nouvel événement
              </Button>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Titre *</Label>
                    <Input
                      id="title"
                      value={newEvent.title}
                      onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                      className="bg-gray-800 border-gray-600"
                      placeholder="Nom de l'événement"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="category">Catégorie</Label>
                    <select
                      id="category"
                      value={newEvent.category}
                      onChange={(e) => setNewEvent({ ...newEvent, category: e.target.value })}
                      className="w-full p-2 bg-gray-800 border border-gray-600 rounded-md"
                    >
                      <option value="electronic">Electronic</option>
                      <option value="techno">Techno</option>
                      <option value="house">House</option>
                      <option value="trance">Trance</option>
                      <option value="dnb">Drum & Bass</option>
                      <option value="ambient">Ambient</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date">Date *</Label>
                    <Input
                      id="date"
                      type="date"
                      value={newEvent.date}
                      onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                      className="bg-gray-800 border-gray-600"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time">Heure de début</Label>
                    <Input
                      id="time"
                      type="time"
                      value={newEvent.time}
                      onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
                      className="bg-gray-800 border-gray-600"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="venue">Lieu *</Label>
                    <Input
                      id="venue"
                      value={newEvent.venue}
                      onChange={(e) => setNewEvent({ ...newEvent, venue: e.target.value })}
                      className="bg-gray-800 border-gray-600"
                      placeholder="Nom du lieu"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">Adresse</Label>
                    <Input
                      id="location"
                      value={newEvent.location}
                      onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                      className="bg-gray-800 border-gray-600"
                      placeholder="Adresse complète"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price">Prix</Label>
                    <Input
                      id="price"
                      value={newEvent.price}
                      onChange={(e) => setNewEvent({ ...newEvent, price: e.target.value })}
                      className="bg-gray-800 border-gray-600"
                      placeholder="15€"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tickets">Billets disponibles</Label>
                    <Input
                      id="tickets"
                      type="number"
                      value={newEvent.ticketsAvailable}
                      onChange={(e) => setNewEvent({ ...newEvent, ticketsAvailable: parseInt(e.target.value) })}
                      className="bg-gray-800 border-gray-600"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newEvent.description}
                    onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                    className="bg-gray-800 border-gray-600 min-h-[100px]"
                    placeholder="Description de l'événement..."
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={handleCreateEvent}
                    disabled={createMutation.isPending}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {createMutation.isPending ? "Création..." : "Créer l'événement"}
                  </Button>
                  <Button
                    onClick={() => setIsCreating(false)}
                    variant="outline"
                    className="border-gray-600"
                  >
                    Annuler
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Events Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-gray-900/50 border-purple-500/20">
            <CardHeader>
              <CardTitle className="text-purple-300">Événements Eventbrite</CardTitle>
              <CardDescription>
                Événements synchronisés depuis Eventbrite
              </CardDescription>
            </CardHeader>
            <CardContent>
              {eventbriteEvents.length === 0 ? (
                <p className="text-gray-400 text-center py-4">
                  Aucun événement Eventbrite trouvé
                </p>
              ) : (
                <div className="space-y-2">
                  {eventbriteEvents.map((event: any) => (
                    <div key={event.id} className="p-3 bg-gray-800 rounded-lg">
                      <h4 className="font-medium">{event.title}</h4>
                      <p className="text-sm text-gray-400">{event.date} - {event.venue}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-purple-500/20">
            <CardHeader>
              <CardTitle className="text-purple-300">Événements manuels</CardTitle>
              <CardDescription>
                Événements créés directement dans TechnoCorner
              </CardDescription>
            </CardHeader>
            <CardContent>
              {manualEvents.length === 0 ? (
                <p className="text-gray-400 text-center py-4">
                  Aucun événement manuel trouvé
                </p>
              ) : (
                <div className="space-y-2">
                  {manualEvents.map((event: any) => (
                    <div key={event.id} className="p-3 bg-gray-800 rounded-lg">
                      <h4 className="font-medium">{event.title}</h4>
                      <p className="text-sm text-gray-400">{event.date} - {event.venue}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}