import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, Mail, QrCode, Calendar, MapPin, Euro, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Ticket {
  id: number;
  code: string;
  eventTitle: string;
  eventDate: string;
  venue: string;
  location: string;
  buyerName: string;
  buyerEmail: string;
  qrCode: string;
  price: string;
  type?: string;
}

export default function TicketSuccess() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [ticketData, setTicketData] = useState<Ticket | null>(null);
  const [emailSent, setEmailSent] = useState(false);

  useEffect(() => {
    // Récupérer les données du billet depuis l'URL ou le localStorage
    const urlParams = new URLSearchParams(window.location.search);
    const ticketJson = urlParams.get('ticket');
    const emailSentParam = urlParams.get('emailSent') === 'true';
    
    // Essayer aussi localStorage comme fallback
    const storedTicket = localStorage.getItem('lastTicket');
    
    if (ticketJson || storedTicket) {
      try {
        const ticket = JSON.parse(decodeURIComponent(ticketJson || storedTicket || ''));
        setTicketData(ticket);
        setEmailSent(emailSentParam);
        
        // Nettoyer le localStorage après récupération
        if (storedTicket) {
          localStorage.removeItem('lastTicket');
        }
      } catch (error) {
        console.error("Erreur parsing ticket:", error);
        toast({
          title: "Erreur",
          description: "Impossible de charger les données du billet",
          variant: "destructive",
        });
      }
    } else {
      // Pas de données de billet, rediriger vers l'accueil
      setLocation('/');
    }
  }, []);

  const downloadTicketImage = () => {
    if (!ticketData) return;
    
    // Créer un canvas pour générer l'image du billet
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 800;
    canvas.height = 600;

    // Fond du billet
    const gradient = ctx.createLinearGradient(0, 0, 800, 600);
    gradient.addColorStop(0, '#667eea');
    gradient.addColorStop(1, '#764ba2');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 800, 600);

    // Zone principale blanche
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(50, 50, 700, 500);

    // Texte du billet
    ctx.fillStyle = '#333333';
    ctx.font = 'bold 32px Arial';
    ctx.fillText('BILLET D\'ENTRÉE', 80, 120);
    
    ctx.font = 'bold 24px Arial';
    ctx.fillText(ticketData.eventTitle, 80, 170);
    
    ctx.font = '18px Arial';
    ctx.fillText(`Date: ${ticketData.eventDate}`, 80, 210);
    ctx.fillText(`Lieu: ${ticketData.venue}`, 80, 240);
    ctx.fillText(`Nom: ${ticketData.buyerName}`, 80, 270);
    ctx.fillText(`Code: ${ticketData.code}`, 80, 300);
    ctx.fillText(`Prix: ${ticketData.price}`, 80, 330);

    // QR Code (si disponible)
    if (ticketData.qrCode) {
      const qrImg = new Image();
      qrImg.onload = () => {
        ctx.drawImage(qrImg, 500, 200, 200, 200);
        
        // Télécharger l'image
        const link = document.createElement('a');
        link.download = `billet-${ticketData.code}.png`;
        link.href = canvas.toDataURL();
        link.click();
      };
      qrImg.src = ticketData.qrCode;
    } else {
      // Télécharger sans QR code
      const link = document.createElement('a');
      link.download = `billet-${ticketData.code}.png`;
      link.href = canvas.toDataURL();
      link.click();
    }
  };

  const printTicket = () => {
    if (!ticketData) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Billet - ${ticketData.eventTitle}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          .ticket { border: 2px dashed #667eea; padding: 30px; max-width: 600px; }
          .header { text-align: center; margin-bottom: 30px; }
          .qr-code { text-align: center; margin: 20px 0; }
          .qr-code img { max-width: 200px; }
          .details { margin: 20px 0; }
          .important { background: #fff3cd; padding: 15px; border: 1px solid #ffeaa7; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="ticket">
          <div class="header">
            <h1>BILLET D'ENTRÉE</h1>
            <h2>${ticketData.eventTitle}</h2>
          </div>
          
          <div class="details">
            <p><strong>Date:</strong> ${ticketData.eventDate}</p>
            <p><strong>Lieu:</strong> ${ticketData.venue}</p>
            <p><strong>Adresse:</strong> ${ticketData.location}</p>
            <p><strong>Nom:</strong> ${ticketData.buyerName}</p>
            <p><strong>Code:</strong> ${ticketData.code}</p>
            <p><strong>Prix:</strong> ${ticketData.price}</p>
          </div>
          
          ${ticketData.qrCode ? `
            <div class="qr-code">
              <img src="${ticketData.qrCode}" alt="QR Code" />
              <p>Présentez ce QR code à l'entrée</p>
            </div>
          ` : ''}
          
          <div class="important">
            <h4>Instructions d'entrée:</h4>
            <ul>
              <li>Présentez ce billet à l'entrée</li>
              <li>Arrivez 30 minutes avant le début</li>
              <li>Une pièce d'identité pourra être demandée</li>
            </ul>
          </div>
        </div>
      </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.print();
  };

  if (!ticketData) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Chargement...</h1>
          <p>Récupération des données du billet...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-6">
        <Button
          variant="outline"
          onClick={() => setLocation('/')}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Retour à l'accueil
        </Button>
      </div>

      {/* Message de succès */}
      <Card className="mb-6 border-green-200 bg-green-50">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3 text-green-800">
            <CheckCircle className="w-6 h-6" />
            <div>
              <h3 className="font-semibold">Billet généré avec succès !</h3>
              <p className="text-sm">
                {emailSent 
                  ? "Votre billet a été envoyé par email et est également disponible ci-dessous."
                  : "Votre billet est disponible ci-dessous. Vous pouvez le télécharger ou l'imprimer."
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Billet principal */}
      <Card className="mb-6">
        <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
          <CardTitle className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <QrCode className="w-6 h-6" />
              BILLET D'ENTRÉE
            </div>
            <h2 className="text-2xl font-bold">{ticketData.eventTitle}</h2>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="p-8">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Informations du billet */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="font-semibold">Date</p>
                  <p>{ticketData.eventDate}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="font-semibold">Lieu</p>
                  <p>{ticketData.venue}</p>
                  <p className="text-sm text-gray-600">{ticketData.location}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Euro className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="font-semibold">Prix</p>
                  <Badge variant="secondary">{ticketData.price}</Badge>
                </div>
              </div>
              
              <div>
                <p className="font-semibold">Titulaire</p>
                <p>{ticketData.buyerName}</p>
                <p className="text-sm text-gray-600">{ticketData.buyerEmail}</p>
              </div>
              
              <div>
                <p className="font-semibold">Code billet</p>
                <p className="font-mono text-lg">{ticketData.code}</p>
              </div>
            </div>
            
            {/* QR Code */}
            {ticketData.qrCode && (
              <div className="text-center">
                <p className="font-semibold mb-4">QR Code d'entrée</p>
                <div className="inline-block p-4 bg-white border-2 border-dashed border-purple-300 rounded-lg">
                  <img 
                    src={ticketData.qrCode} 
                    alt="QR Code" 
                    className="w-48 h-48 mx-auto"
                  />
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  Présentez ce QR code à l'entrée
                </p>
              </div>
            )}
          </div>
          
          {/* Instructions */}
          <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h4 className="font-semibold mb-2">Instructions importantes :</h4>
            <ul className="text-sm space-y-1">
              <li>• Conservez ce billet précieusement</li>
              <li>• Présentez le QR code à l'entrée (sur téléphone ou imprimé)</li>
              <li>• Arrivez 30 minutes avant le début de l'événement</li>
              <li>• Une pièce d'identité pourra vous être demandée</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex flex-wrap gap-4 justify-center">
        <Button onClick={downloadTicketImage} className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Télécharger le billet
        </Button>
        
        <Button variant="outline" onClick={printTicket} className="flex items-center gap-2">
          <QrCode className="w-4 h-4" />
          Imprimer le billet
        </Button>
        
        {!emailSent && (
          <Button variant="outline" className="flex items-center gap-2">
            <Mail className="w-4 h-4" />
            Renvoyer par email
          </Button>
        )}
      </div>
    </div>
  );
}