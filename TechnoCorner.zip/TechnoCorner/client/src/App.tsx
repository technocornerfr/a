import { Switch, Route, useLocation, Link } from "wouter";
import { queryClient, apiRequest } from "./lib/queryClient";
import { QueryClientProvider, useQuery, useMutation } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { useAuth } from "@/hooks/useAuth";
import { useMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, useEffect } from "react";
import { initGA } from "./lib/analytics";
import { useAnalytics } from "./hooks/use-analytics";
import { InstallPrompt } from "@/components/mobile/install-prompt";
import { BottomNav } from "@/components/mobile/bottom-nav";
import Home from "@/pages/home";
import CreateEvent from "@/pages/create-event";
import EventDetail from "@/pages/event-detail";
// import Community from "@/pages/community";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Profile from "@/pages/profile";
import Checkout from "@/pages/checkout";
import About from "@/pages/about";
import Community from "@/pages/community-final-working";
import TicketDetail from "@/pages/ticket-detail";
import TicketDownload from "@/pages/ticket-download";
import VerifyTicket from "@/pages/verify-ticket";
import MobileScanner from "@/pages/mobile-scanner";
import ScannerDemo from "@/pages/scanner-demo";
import PhotoScanner from "@/pages/photo-scanner";
import Analytics from "@/pages/analytics";
import OrganizerDashboard from "@/pages/organizer-dashboard";
import EventManagement from "@/pages/event-management";

import NotFound from "@/pages/not-found";
import MessagesTest from "@/pages/messages-test";
import MessagesWorking from "@/pages/messages-working";
import Conversation from "@/pages/conversation";
import MessagesFinal from "@/pages/messages-final";
import EventbriteAdmin from "@/pages/eventbrite-admin";
import TicketSuccess from "@/pages/ticket-success";

function MessageInput({ onSendMessage, disabled }: { onSendMessage: (content: string) => void; disabled: boolean }) {
  const [content, setContent] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (content.trim()) {
      onSendMessage(content.trim());
      setContent("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex space-x-2">
      <Input
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Tapez votre message..."
        disabled={disabled}
        className="flex-1"
      />
      <Button type="submit" disabled={disabled || !content.trim()}>
        Envoyer
      </Button>
    </form>
  );
}

function MessagesComponent() {
  const { user } = useAuth();
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [newMessage, setNewMessage] = useState("");
  
  // Vérifier si un utilisateur a été sélectionné depuis un profil
  useEffect(() => {
    const savedUserId = localStorage.getItem('selectedUserId');
    const savedUsername = localStorage.getItem('selectedUsername');
    if (savedUserId && savedUsername) {
      setSelectedUser({
        id: parseInt(savedUserId),
        username: savedUsername
      });
      // Nettoyer le localStorage après utilisation
      localStorage.removeItem('selectedUserId');
      localStorage.removeItem('selectedUsername');
    }
  }, []);

  const sendMessageMutation = useMutation({
    mutationFn: async (data: { receiverId: number; content: string }) => {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          senderId: user?.id,
          receiverId: data.receiverId,
          content: data.content
        }),
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Erreur envoi message');
      return response.json();
    },
    onSuccess: () => {
      setNewMessage("");
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim() && selectedUser) {
      sendMessageMutation.mutate({ 
        receiverId: selectedUser.id, 
        content: newMessage.trim() 
      });
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Connexion requise</h2>
          <p className="text-muted-foreground">Veuillez vous connecter pour accéder à vos messages.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Messages</h1>
        <div className="max-w-4xl mx-auto">
          {/* Zone de chat */}
          <div className="bg-card rounded-lg border flex flex-col h-[600px]">
            {selectedUser ? (
              <>
                {/* En-tête de la conversation */}
                <div className="p-4 border-b">
                  <h3 className="font-semibold">
                    Conversation avec {selectedUser.username}
                  </h3>
                </div>

                {/* Messages */}
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                  <p className="text-muted-foreground text-center">
                    Début de la conversation avec {selectedUser.username}
                  </p>
                </div>

                {/* Zone de saisie */}
                <div className="p-4 border-t">
                  <form onSubmit={handleSendMessage} className="flex space-x-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Tapez votre message..."
                      disabled={sendMessageMutation.isPending}
                      className="flex-1"
                    />
                    <Button 
                      type="submit" 
                      disabled={sendMessageMutation.isPending || !newMessage.trim()}
                    >
                      {sendMessageMutation.isPending ? "Envoi..." : "Envoyer"}
                    </Button>
                  </form>
                  {sendMessageMutation.isSuccess && (
                    <p className="text-green-600 text-sm mt-2">Message envoyé !</p>
                  )}
                  {sendMessageMutation.isError && (
                    <p className="text-red-600 text-sm mt-2">Erreur lors de l'envoi du message</p>
                  )}
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-muted-foreground mb-4">
                    Pour envoyer un message, visitez le profil d'un utilisateur depuis la communauté et cliquez sur "Envoyer un message"
                  </p>
                  <Link href="/community">
                    <Button>Aller à la communauté</Button>
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function AppRouter() {
  const [location] = useLocation();
  
  // Track page views when routes change
  useAnalytics();
  
  // Route messages avec gestion spéciale
  if (location === "/messages" || location.startsWith("/messages/")) {
    return <MessagesWorking />;
  }
  
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/create" component={CreateEvent} />
      <Route path="/event/:id" component={EventDetail} />
      <Route path="/checkout" component={Checkout} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/profile" component={Profile} />
      <Route path="/profile/:id" component={Profile} />
      <Route path="/about" component={About} />
      <Route path="/community" component={Community} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/organizer" component={OrganizerDashboard} />
      <Route path="/manage-events" component={EventManagement} />

      <Route path="/ticket/:id" component={TicketDetail} />
      <Route path="/ticket-download" component={TicketDownload} />
      <Route path="/ticket-success" component={TicketSuccess} />
      <Route path="/verify-ticket" component={VerifyTicket} />
      <Route path="/mobile-scanner" component={MobileScanner} />
      <Route path="/scanner-demo" component={ScannerDemo} />
      <Route path="/photo-scanner" component={PhotoScanner} />
      <Route path="/messages-test" component={MessagesTest} />
      <Route path="/messages" component={MessagesFinal} />
      <Route path="/messages/:userId" component={MessagesWorking} />
      <Route path="/messages-working/:userId" component={MessagesWorking} />
      <Route path="/conversation/:userId" component={Conversation} />
      <Route path="/eventbrite-admin" component={EventbriteAdmin} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const { isMobile } = useMobile();

  // Initialize Google Analytics when app loads
  useEffect(() => {
    // Verify required environment variable is present
    if (!import.meta.env.VITE_GA_MEASUREMENT_ID) {
      console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    } else {
      initGA();
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className={`min-h-screen bg-background ${isMobile ? 'pb-16' : ''}`}>
          <Header />
          <main className="flex-1">
            <AppRouter />
          </main>
          {!isMobile && <Footer />}
          {isMobile && <BottomNav />}
          <InstallPrompt />
          <Toaster />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;