import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import type { User } from "@shared/schema";

export function useAuth() {
  const { data: user, isLoading, error } = useQuery<User>({
    queryKey: ["/api/auth/current"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    retry: false,
    staleTime: 0, // Force refetch to ensure fresh data
    gcTime: 0, // Prevent caching issues
  });

  return {
    user: user || null,
    isLoading,
    isAuthenticated: !!user && !!user.id,
    error,
  };
}