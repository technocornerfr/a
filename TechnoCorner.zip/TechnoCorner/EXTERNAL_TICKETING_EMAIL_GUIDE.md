# Guide d'envoi automatique de billets par email - Organisateurs externes

## Vue d'ensemble

Le système TechnoCorner envoie désormais automatiquement les billets par email lorsqu'un achat est effectué via l'API externe. Chaque billet généré déclenche un envoi d'email professionnel avec QR code intégré.

## Fonctionnalités

### Envoi automatique
- ✅ Email envoyé automatiquement lors de la génération d'un billet
- ✅ Template professionnel avec QR code intégré
- ✅ Informations complètes de l'événement
- ✅ Instructions d'entrée claires
- ✅ Identification de l'organisateur externe

### Contenu de l'email
- QR code haute résolution téléchargeable
- Détails complets de l'événement (date, lieu, prix)
- Code billet unique pour référence
- Instructions d'entrée et de sécurité
- Branding combiné (organisateur + TechnoCorner)

## Utilisation

### 1. Génération de billet avec email automatique

```bash
POST /api/external/tickets/generate
Content-Type: application/json
X-API-Key: your_api_key_id
X-API-Secret: your_api_secret

{
  "externalEventId": "your_event_id",
  "externalTicketId": "unique_ticket_id",
  "buyerName": "Jean Dupont",
  "buyerEmail": "jean.dupont@email.com",
  "ticketType": "VIP",
  "price": "45€"
}
```

### 2. Réponse avec confirmation d'envoi

```json
{
  "success": true,
  "ticket": {
    "id": 156,
    "qrCode": "A1B2C3D4E5F67890",
    "qrCodeImage": "data:image/png;base64,iVBORw0KGg...",
    "status": "valid",
    "createdAt": "2024-06-06T10:35:00Z"
  }
}
```

## Configuration requise

### Prérequis
1. Clé API externe active avec permissions `tickets:generate`
2. Événement externe créé via `/api/external/events/create`
3. Adresse email valide de l'acheteur

### Variables d'environnement
- `SENDGRID_API_KEY` : Clé API SendGrid configurée côté TechnoCorner

## Template d'email

### Informations incluses
- **En-tête** : Branding combiné organisateur + TechnoCorner
- **Détails événement** : Titre, date, lieu, prix
- **QR Code** : Image haute résolution pour l'entrée
- **Instructions** : Guide d'utilisation du billet
- **Contact** : Informations de support

### Personnalisation
- Nom de l'organisateur affiché dans l'en-tête
- Message personnalisé pour billets externes
- Instructions spécifiques aux organisateurs externes

## Gestion des erreurs

### Échecs d'envoi
- Les erreurs d'email n'affectent pas la génération du billet
- Logs détaillés pour le débogage
- QR code toujours disponible via l'API

### Codes d'erreur courants
- `400` : Données manquantes (email, nom, etc.)
- `403` : Permissions insuffisantes
- `404` : Événement externe non trouvé
- `500` : Erreur serveur (vérifier logs SendGrid)

## Logs et monitoring

### Logs automatiques
```
Billet externe envoyé par email à jean.dupont@email.com pour l'événement Festival Techno 2024
```

### Échecs d'envoi
```
Échec de l'envoi d'email pour le billet externe à jean.dupont@email.com
Erreur envoi email billet externe: [détails de l'erreur]
```

## Test et validation

### Script de test
Utilisez `test-external-ticket-email.js` pour valider :
- Génération d'événement externe
- Création de billet avec email automatique
- Validation du QR code

### Vérifications manuelles
1. Vérifier la réception de l'email
2. Tester l'affichage du QR code
3. Valider les informations de l'événement
4. Confirmer les instructions d'entrée

## Intégration dans votre système

### Workflow recommandé
1. Créer l'événement externe une fois
2. Pour chaque vente de billet :
   - Traiter le paiement côté organisateur
   - Appeler `/api/external/tickets/generate`
   - L'email est envoyé automatiquement
   - Sauvegarder le QR code pour validation

### Gestion des doublons
- Utilisez des `externalTicketId` uniques
- Vérifiez les réponses API pour éviter les doublons
- Conservez une trace des billets générés

## Support technique

### En cas de problème
1. Vérifier les logs de votre côté
2. Consulter les logs TechnoCorner (si accès)
3. Tester avec l'API de validation
4. Contacter le support TechnoCorner

### Informations à fournir
- ID de la clé API utilisée
- `externalEventId` et `externalTicketId`
- Timestamp de la requête
- Code d'erreur reçu

---

*Cette fonctionnalité garantit une expérience utilisateur fluide avec des billets professionnels livrés instantanément par email.*