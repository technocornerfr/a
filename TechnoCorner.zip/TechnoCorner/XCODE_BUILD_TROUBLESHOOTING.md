# Guide de résolution des erreurs de build Xcode

## Erreurs de build courantes et solutions

### 1. Erreur de signing/provisioning

**Symptômes :**
- "Failed to register bundle identifier"
- "No valid code signing certificate found"
- "Provisioning profile doesn't match"

**Solution :**
1. **Projet → General → Signing & Capabilities**
2. Cocher **"Automatically manage signing"**
3. Sélectionner votre **Team** (Apple Developer Account)
4. Modifier le **Bundle Identifier** : `com.votrenom.technocorner`

### 2. Erreur de target SDK/deployment

**Symptômes :**
- "Minimum deployment target version"
- "iOS version not supported"

**Solution :**
1. **Projet → Build Settings**
2. Chercher **"iOS Deployment Target"**
3. Définir à **iOS 12.0** ou plus récent
4. **Clean Build Folder** (Product → Clean Build Folder)

### 3. Erreur CocoaPods/Dependencies

**Symptômes :**
- "Pod install failed"
- "Framework not found"
- "Library not loaded"

**Solution :**
```bash
cd ios/App
pod deintegrate
pod install
```

### 4. Erreur de fichiers manquants

**Symptômes :**
- "File not found"
- "No such file or directory"
- "Resource not found"

**Solution :**
Vérifier que les fichiers sont synchronisés :
```bash
# Copier manuellement l'application
mkdir -p ios/App/App/public
cp -r client/src ios/App/App/public/
cp client/index.html ios/App/App/public/
cp -r public/* ios/App/App/public/ 2>/dev/null || true
```

### 5. Erreur de configuration Capacitor

**Symptômes :**
- "Capacitor configuration invalid"
- "WebView failed to load"

**Solution :**
Vérifier `capacitor.config.json` dans `ios/App/App/`:
```json
{
  "appId": "com.technocorner.app",
  "appName": "TechnoCorner",
  "webDir": "public"
}
```

### 6. Processus de debugging complet

**Étape 1 - Clean et rebuild :**
```
Product → Clean Build Folder (Cmd+Shift+K)
Product → Build (Cmd+B)
```

**Étape 2 - Vérifier les logs :**
- Navigator → Report Navigator (Cmd+9)
- Cliquer sur la dernière build
- Examiner les erreurs détaillées

**Étape 3 - Reset simulator :**
```
Device → Erase All Content and Settings
```

**Étape 4 - Restart Xcode :**
- Fermer Xcode complètement
- Rouvrir le projet
- Relancer la build

### 7. Configuration minimale fonctionnelle

**Info.plist corrections :**
```xml
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsArbitraryLoads</key>
    <true/>
</dict>
<key>UIRequiredDeviceCapabilities</key>
<array/>
```

**Build Settings essentiels :**
- **iOS Deployment Target :** 12.0
- **Code Signing Identity :** Apple Development
- **Development Team :** [Votre équipe]
- **Bundle Identifier :** com.votrenom.technocorner

### 8. Test de validation finale

Après correction, tester :
1. **Build réussie** (Cmd+B)
2. **Installation simulateur** (Cmd+R)
3. **App se lance** sans crash
4. **Navigation fonctionne** entre les pages
5. **Assets chargent** correctement

### 9. Script de diagnostic automatique

Créez ce script `diagnose-ios.sh` :
```bash
#!/bin/bash
echo "Diagnostic TechnoCorner iOS"
echo "=========================="

echo "1. Vérification structure projet..."
ls -la ios/App/App/public/ | head -10

echo "2. Vérification configuration Capacitor..."
cat ios/App/App/capacitor.config.json 2>/dev/null || echo "Config manquante"

echo "3. Vérification Info.plist..."
grep -A5 "CFBundleDisplayName" ios/App/App/Info.plist

echo "4. Vérification simulateurs disponibles..."
xcrun simctl list devices | grep iPhone | head -5

echo "5. Vérification certificats..."
security find-identity -v -p codesigning | head -3

echo "Diagnostic terminé"
```

### 10. Solutions d'urgence

**Si tout échoue :**
1. **Créer nouveau projet Capacitor :**
```bash
npx @capacitor/cli create
cd nouveau-projet
npx cap add ios
```

2. **Copier vos fichiers :**
```bash
cp -r ../ancien-projet/client/* www/
npx cap sync ios
```

3. **Ouvrir dans Xcode :**
```bash
npx cap open ios
```

L'objectif est d'avoir votre application TechnoCorner qui fonctionne parfaitement dans le simulateur iOS avec toutes les fonctionnalités : navigation, communauté, événements, messages, et scanner QR.