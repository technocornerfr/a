#!/bin/bash

echo "🚀 Déploiement PWA TechnoCorner - Compatible Monterey"
echo "=================================================="

# Créer une version statique optimisée
mkdir -p pwa-deploy
cd pwa-deploy

# Copier les fichiers essentiels
cp -r ../client/* .
cp ../public/* .

# Créer un index.html optimisé pour PWA
cat > index.html << 'EOF'
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechnoCorner - Événements Techno</title>
    
    <!-- PWA Meta -->
    <meta name="theme-color" content="#667eea">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="TechnoCorner">
    
    <!-- Icons -->
    <link rel="icon" href="/icon-192.svg">
    <link rel="apple-touch-icon" href="/icon-192.svg">
    <link rel="manifest" href="/manifest.json">
    
    <!-- CSS optimisé -->
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
        }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; padding: 40px 0; }
        .logo { font-size: 3rem; font-weight: bold; margin-bottom: 20px; }
        .tagline { font-size: 1.2rem; opacity: 0.9; margin-bottom: 40px; }
        .features { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin: 60px 0; }
        .feature { 
            background: rgba(255,255,255,0.1); 
            padding: 30px; 
            border-radius: 20px;
            backdrop-filter: blur(10px);
            text-align: center;
        }
        .feature h3 { font-size: 1.5rem; margin-bottom: 15px; }
        .cta { text-align: center; margin: 60px 0; }
        .btn { 
            display: inline-block;
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 15px 30px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            border: 2px solid rgba(255,255,255,0.3);
            transition: all 0.3s ease;
            margin: 10px;
        }
        .btn:hover { background: rgba(255,255,255,0.3); transform: translateY(-2px); }
        .install-prompt {
            position: fixed;
            bottom: 20px;
            left: 20px;
            right: 20px;
            background: #000;
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            display: none;
        }
        @media (max-width: 768px) {
            .logo { font-size: 2rem; }
            .features { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1 class="logo">🎧 TechnoCorner</h1>
            <p class="tagline">Découvrez la scène techno, connectez-vous avec la communauté</p>
        </header>

        <div class="features">
            <div class="feature">
                <h3>🎵 Événements</h3>
                <p>Découvrez les meilleurs événements techno près de chez vous. Soirées, festivals, afters.</p>
            </div>
            <div class="feature">
                <h3>👥 Communauté</h3>
                <p>Partagez vos moments, connectez-vous avec d'autres passionnés de musique électronique.</p>
            </div>
            <div class="feature">
                <h3>🎫 Scanner</h3>
                <p>Scannez et validez vos billets d'événements avec notre système anti-fraude.</p>
            </div>
            <div class="feature">
                <h3>📱 Mobile</h3>
                <p>Application PWA installable sur tous vos appareils, fonctionne hors ligne.</p>
            </div>
        </div>

        <div class="cta">
            <a href="#" class="btn" onclick="installPWA()">📱 Installer l'App</a>
            <a href="#" class="btn" onclick="openApp()">🚀 Lancer TechnoCorner</a>
        </div>
    </div>

    <div id="installPrompt" class="install-prompt">
        <p><strong>Installer TechnoCorner</strong></p>
        <p>Ajoutez cette app à votre écran d'accueil pour un accès rapide</p>
        <button onclick="hideInstallPrompt()" style="margin-top: 10px; padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 5px;">Installer</button>
    </div>

    <script>
        // PWA Installation
        let deferredPrompt;
        
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            document.getElementById('installPrompt').style.display = 'block';
        });

        function installPWA() {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                deferredPrompt.userChoice.then((choiceResult) => {
                    if (choiceResult.outcome === 'accepted') {
                        console.log('PWA installée');
                    }
                    deferredPrompt = null;
                });
            } else {
                // iOS Safari
                if (/iPhone|iPad|iPod/.test(navigator.userAgent)) {
                    alert('Pour installer sur iOS:\n1. Appuyez sur le bouton Partager\n2. Sélectionnez "Ajouter à l\'écran d\'accueil"');
                }
            }
        }

        function openApp() {
            // Redirection vers l'app complète
            window.location.href = '/community';
        }

        function hideInstallPrompt() {
            document.getElementById('installPrompt').style.display = 'none';
        }

        // Service Worker
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js')
                .then(() => console.log('SW enregistré'))
                .catch(() => console.log('SW erreur'));
        }
    </script>
</body>
</html>
EOF

# Optimiser le manifest.json
cat > manifest.json << 'EOF'
{
  "name": "TechnoCorner",
  "short_name": "TechnoCorner",
  "description": "Découvrez la scène techno, connectez-vous avec la communauté",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#667eea",
  "theme_color": "#667eea",
  "orientation": "portrait-primary",
  "categories": ["music", "entertainment", "social"],
  "icons": [
    {
      "src": "/icon-192.svg",
      "sizes": "192x192",
      "type": "image/svg+xml",
      "purpose": "any maskable"
    },
    {
      "src": "/icon-512.svg", 
      "sizes": "512x512",
      "type": "image/svg+xml",
      "purpose": "any maskable"
    }
  ],
  "screenshots": [
    {
      "src": "/icon-512.svg",
      "sizes": "540x720",
      "type": "image/svg+xml",
      "form_factor": "narrow"
    }
  ]
}
EOF

echo "✅ PWA préparée dans le dossier pwa-deploy/"
echo ""
echo "🌐 DÉPLOIEMENT OPTIONS :"
echo "1. Netlify Drop: drag & drop sur netlify.app/drop"
echo "2. Vercel: npx vercel --prod"
echo "3. GitHub Pages: push vers repository"
echo "4. Surge.sh: npx surge ."
echo ""
echo "📱 INSTALLATION iOS :"
echo "1. Ouvrir Safari sur iPhone/iPad"
echo "2. Aller sur votre URL déployée"
echo "3. Partager → Ajouter à l'écran d'accueil"
echo ""
echo "🎯 Votre app sera accessible comme une app native!"