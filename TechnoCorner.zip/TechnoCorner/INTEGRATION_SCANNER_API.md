# API d'Intégration Scanner Anti-Fraude TechnoCorner

## Vue d'ensemble
Cette API permet aux organisateurs d'intégrer le système anti-fraude TechnoCorner dans leurs propres machines de scan et terminaux de validation.

## Authentification
Les organisateurs doivent obtenir une clé API via le dashboard organisateur.

```bash
# Génération d'une clé API pour un organisateur
curl -X POST "https://your-domain.com/api/organizers/generate-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "organizerName": "Mon Organisation",
    "organizerEmail": "contact@monorg.com",
    "eventIds": [1, 2, 3]
  }'
```

## Endpoints de Validation

### 1. Vérification de billet (lecture seule)
```bash
POST /api/verify-ticket
Content-Type: application/json
Authorization: Bearer YOUR_API_KEY

{
  "qrData": "{\"ticketCode\":\"TECHNO-123...\",\"eventId\":1,\"buyerName\":\"John Doe\"}"
}
```

**Réponse :**
```json
{
  "valid": true,
  "message": "Billet valide",
  "ticket": {
    "id": 123,
    "ticketCode": "TECHNO-...",
    "buyerName": "John Doe",
    "status": "valid"
  },
  "event": {
    "id": 1,
    "title": "Techno Night 2025",
    "date": "2025-12-31",
    "venue": "Club XYZ"
  }
}
```

### 2. Validation d'entrée (marque comme utilisé)
```bash
POST /api/validate-ticket
Content-Type: application/json
Authorization: Bearer YOUR_API_KEY

{
  "qrData": "{\"ticketCode\":\"TECHNO-123...\",\"eventId\":1,\"buyerName\":\"John Doe\"}",
  "validatorId": "scanner-entree-01",
  "location": "Entrée principale"
}
```

**Réponse succès :**
```json
{
  "valid": true,
  "validated": true,
  "message": "Billet validé avec succès",
  "ticket": {
    "id": 123,
    "status": "used",
    "usedAt": "2025-06-08T18:30:00Z",
    "validatorId": "scanner-entree-01"
  }
}
```

**Réponse échec (déjà utilisé) :**
```json
{
  "valid": false,
  "alreadyUsed": true,
  "message": "Billet déjà utilisé le 08/06/2025 à 18:25",
  "usedAt": "2025-06-08T18:25:00Z",
  "originalValidator": "scanner-entree-02"
}
```

## Intégration dans machines de scan

### Option 1: Intégration directe API
Les machines de scan existantes peuvent appeler directement nos endpoints :

```python
# Exemple Python pour machine de scan
import requests
import json

def validate_ticket(qr_content, scanner_id):
    url = "https://your-domain.com/api/validate-ticket"
    headers = {
        "Authorization": "Bearer YOUR_API_KEY",
        "Content-Type": "application/json"
    }
    
    payload = {
        "qrData": qr_content,
        "validatorId": scanner_id,
        "location": "Entrée VIP"
    }
    
    response = requests.post(url, headers=headers, json=payload)
    result = response.json()
    
    if result.get("valid") and result.get("validated"):
        print("✅ ACCÈS AUTORISÉ")
        return True
    else:
        print(f"❌ ACCÈS REFUSÉ: {result.get('message')}")
        return False
```

### Option 2: SDK JavaScript/TypeScript
```javascript
// SDK pour terminaux web
class TechnoCornerScanner {
  constructor(apiKey, baseUrl) {
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;
  }
  
  async validateTicket(qrData, scannerId) {
    const response = await fetch(`${this.baseUrl}/api/validate-ticket`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        qrData,
        validatorId: scannerId
      })
    });
    
    return await response.json();
  }
}
```

### Option 3: Webhook en temps réel
Pour synchronisation immédiate :

```bash
POST /api/organizers/webhooks
{
  "url": "https://your-scanner-system.com/webhook",
  "events": ["ticket.validated", "ticket.duplicate_attempt"],
  "secret": "your_webhook_secret"
}
```

## Codes de statut et gestion d'erreurs

| Code | Signification | Action recommandée |
|------|---------------|-------------------|
| 200  | Validation réussie | Autoriser l'accès |
| 400  | Billet déjà utilisé | Refuser et alerter sécurité |
| 404  | Billet non trouvé | Refuser l'accès |
| 401  | Clé API invalide | Vérifier configuration |
| 500  | Erreur serveur | Retry ou mode dégradé |

## Configuration des machines de scan

### Variables d'environnement recommandées :
```bash
TECHNOCORNER_API_KEY=your_api_key_here
TECHNOCORNER_BASE_URL=https://your-domain.com
SCANNER_ID=scanner-entree-principale
LOCATION=Entrée principale
RETRY_ATTEMPTS=3
TIMEOUT_MS=5000
```

### Mode hors-ligne (optionnel)
Pour les événements sans connexion stable :
- Cache local des billets validés
- Synchronisation différée
- Mode dégradé avec validation basique

## Tests d'intégration

Codes de test fournis :
- `TECHNO-TEST-VALID-001` : Billet valide
- `TECHNO-TEST-USED-002` : Billet déjà utilisé
- `TECHNO-TEST-INVALID-003` : Billet invalide

## Support technique

- Documentation complète : `/docs/api`
- Sandbox de test : `https://sandbox.technocorner.com`
- Support organisateurs : support@technocorner.com
- Status API : `https://status.technocorner.com`