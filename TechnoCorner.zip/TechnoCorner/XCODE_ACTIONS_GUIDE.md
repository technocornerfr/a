# Guide Actions Xcode : Ce que vous devez faire exactement

## 1. Ouvrir votre projet TechnoCorner dans Xcode

### Action précise
```bash
cd ios/App
open App.xcworkspace
```

**Important :** Ouvrez `App.xcworkspace` (pas App.xcodeproj)

---

## 2. Localiser le projet dans l'interface Xcode

### Étapes visuelles

**a) Afficher le Navigator (si absent)**
- Appuyez sur **Cmd+1**
- Ou menu **View → Navigators → Show Project Navigator**

**b) Identifier la structure**
Vous verrez dans la barre latérale gauche :
```
📁 App                    ← CLIQUEZ ICI
📁 Pods
🔨 Products
```

**c) Cliquer sur "App"**
- Cliquez sur l'élément **"App"** avec l'icône de dossier
- PAS sur les sous-éléments, mais bien le premier "App"

---

## 3. Configurer les paramètres du projet

### Zone qui s'affiche au centre
Après avoir cliqué sur "App", vous verrez des onglets :
```
General | Signing & Capabilities | Build Settings | ...
```

### Onglet "General" (déjà sélectionné)

**Actions à faire :**

**a) Display Name**
- Localisez le champ "Display Name"
- Effacez "App"
- Tapez : **"TechnoCorner"**

**b) Bundle Identifier**
- Localisez "Bundle Identifier"
- Changez en quelque chose d'unique :
  - `com.votrenom.technocorner`
  - `com.technocorner.app`
  - `com.votrenom.techno2025`

**c) Version**
- Vérifiez que Version = "1.0.0"
- Vérifiez que Build = "1"

---

## 4. Configuration de la signature (CRUCIAL)

### Cliquer sur l'onglet "Signing & Capabilities"

**Actions requises :**

**a) Cocher les cases**
- Trouvez "Automatically manage signing" pour **Debug**
- Cochez la case ☑
- Trouvez "Automatically manage signing" pour **Release**  
- Cochez la case ☑

**b) Sélectionner Team**
- Cliquez sur la liste déroulante "Team"
- Sélectionnez votre nom/compte Apple Developer

**Si aucun Team disponible :**
1. Menu **Xcode → Preferences**
2. Onglet **"Accounts"**
3. Cliquez **"+"**
4. Sélectionnez **"Apple ID"**
5. Entrez vos identifiants Apple Developer
6. Cliquez **"Sign In"**
7. Fermez Preferences
8. Retournez à "Signing & Capabilities"
9. Sélectionnez votre équipe

---

## 5. Tester l'application dans le simulateur

### Actions de test

**a) Sélectionner destination**
- En haut de Xcode, à côté du bouton Play
- Cliquez sur la destination (ex: "iPhone 15 Pro")
- Sélectionnez **"iPhone 15 Pro"** dans la liste

**b) Lancer l'application**
- Cliquez le **bouton Play** (triangle) en haut à gauche
- Ou appuyez sur **Cmd+R**

**c) Attendre le simulateur**
- Le simulateur iPhone s'ouvre (1-2 minutes)
- Votre application TechnoCorner se lance
- Vérifiez que l'interface s'affiche correctement

---

## 6. Build pour l'App Store

### Préparation

**a) Changer la destination**
- Cliquez sur la destination en haut
- Sélectionnez **"Any iOS Device (arm64)"**
- Ne sélectionnez PAS un simulateur

**b) Nettoyer le projet**
- Menu **Product → Clean Build Folder**
- Ou **Cmd+Shift+K**
- Attendez "Clean Finished"

### Archiver l'application

**a) Lancer l'archive**
- Menu **Product → Archive**
- Attendez la compilation (10-20 minutes)

**b) L'Organizer s'ouvre**
- Fenêtre avec votre archive TechnoCorner
- Vérifiez Status : "Valid"
- Date récente
- Taille raisonnable (~15-30 MB)

---

## 7. Upload vers App Store Connect

### Dans l'Organizer

**a) Distribuer l'app**
- Cliquez **"Distribute App"**
- Sélectionnez **"App Store Connect"**
- Cliquez **"Next"**

**b) Options d'upload**
- Sélectionnez **"Upload"** (pas Export)
- Cliquez **"Next"**
- Laissez options par défaut
- Cliquez **"Next"**

**c) Signature automatique**
- Laissez **"Automatically manage signing"** coché
- Cliquez **"Next"**

**d) Upload final**
- Vérifiez les informations
- Cliquez **"Upload"**
- Attendez l'upload (5-20 minutes)

**e) Confirmation**
- Message "Upload Successful"
- Email de confirmation d'Apple

---

## 8. Vérifications importantes

### Pendant le processus

**✅ Vérifiez que :**
- Navigator est visible (Cmd+1)
- Projet "App" sélectionné
- Onglets General/Signing visibles
- Team sélectionné sans erreurs
- Archive créée avec status "Valid"
- Upload terminé avec succès

### En cas de problème

**Erreurs de signature :**
- Changez le Bundle Identifier
- Décochez/recochez "Automatically manage signing"

**Erreurs de build :**
- Product → Clean Build Folder
- Vérifiez que `npm run build` et `npx cap sync ios` ont été faits

**Interface manquante :**
- Fermez Xcode complètement
- Rouvrez avec `open App.xcworkspace`
- Appuyez Cmd+1 pour Navigator

---

## Récapitulatif des actions Xcode

1. **Ouvrir :** `App.xcworkspace`
2. **Navigator :** Cmd+1 puis cliquer "App"
3. **General :** Display Name = "TechnoCorner", Bundle ID unique
4. **Signing :** Cocher "Automatically manage", sélectionner Team
5. **Test :** iPhone 15 Pro + bouton Play
6. **Archive :** Any iOS Device + Product → Archive
7. **Upload :** Distribute App → App Store Connect → Upload

Après l'upload réussi, votre application TechnoCorner sera disponible sur App Store Connect pour configuration finale et soumission.