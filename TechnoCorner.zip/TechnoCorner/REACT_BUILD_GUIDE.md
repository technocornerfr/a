# Guide Détaillé : Préparer votre App React TechnoCorner pour iOS

## Situation actuelle
Votre projet TechnoCorner utilise :
- React/TypeScript frontend (dans `/client/`)
- Express backend (dans `/server/`)
- Vite comme bundler
- Capacitor pour iOS

## Étape 1 : Comprendre l'architecture React

### Structure de votre projet
```
TechnoCorner/
├── client/           ← Votre app React
│   ├── src/
│   │   ├── main.tsx  ← Point d'entrée React
│   │   ├── App.tsx   ← Composant principal
│   │   └── pages/    ← Pages de l'app
│   └── index.html    ← Template HTML
├── server/           ← Backend Express
├── dist/             ← Build final (créé par npm run build)
└── ios/              ← Projet iOS Capacitor
    └── App/
        └── public/   ← Ici sera copiée votre app React
```

## Étape 2 : Construire l'application React

### Commande de build
```bash
npm run build
```

### Ce qui se passe pendant le build

**Phase 1 : Compilation React (via Vite)**
```
1. [●○○○] Analyzing dependencies (10s)
   └ Vite analyse tous vos composants React

2. [●●○○] Transpiling TypeScript (30s)
   └ Conversion TypeScript → JavaScript

3. [●●●○] Bundling components (45s)
   └ Assemblage de tous vos fichiers React

4. [●●●●] Optimizing for production (20s)
   └ Minification CSS/JS, optimisation images
```

**Phase 2 : Build backend (via esbuild)**
```
5. [●●●●●] Building Express server (15s)
   └ Compilation du serveur pour production
```

### Résultat du build
Après `npm run build`, vous obtenez :
```
dist/
├── index.html           ← Page principale React
├── assets/
│   ├── index-abc123.js  ← JavaScript optimisé
│   ├── index-def456.css ← CSS optimisé
│   └── icons/           ← Images optimisées
└── index.js             ← Serveur Express compilé
```

## Étape 3 : Synchroniser avec iOS

### Commande de synchronisation
```bash
npx cap sync ios
```

### Ce qui se passe pendant la sync

**Phase 1 : Copie des fichiers web**
```
1. [●○○○] Copying web assets (5s)
   └ Copie dist/ → ios/App/public/

2. [●●○○] Updating Capacitor config (3s)
   └ Mise à jour capacitor.config.ts

3. [●●●○] Installing iOS dependencies (10s)
   └ Installation des plugins Capacitor

4. [●●●●] Updating Xcode project (5s)
   └ Mise à jour du projet iOS
```

**Résultat dans iOS :**
```
ios/App/public/
├── index.html           ← Votre app React copiée
├── assets/
│   ├── index-abc123.js  ← JavaScript de votre app
│   ├── index-def456.css ← Styles de votre app
│   └── icons/           ← Images de votre app
└── capacitor.config.json
```

## Étape 4 : Vérification avant Xcode

### Vérifier que le build a fonctionné
```bash
# Vérifier que dist/ existe
ls -la dist/

# Vérifier le contenu
ls -la dist/assets/
```

**Vous devez voir :**
- ✅ `index.html` (point d'entrée)
- ✅ `assets/index-[hash].js` (JavaScript bundlé)
- ✅ `assets/index-[hash].css` (CSS bundlé)

### Vérifier la synchronisation iOS
```bash
# Vérifier que les fichiers sont copiés
ls -la ios/App/public/

# Vérifier les assets
ls -la ios/App/public/assets/
```

**Vous devez voir :**
- ✅ Même structure que dist/
- ✅ Fichiers récents (timestamp d'aujourd'hui)

## Étape 5 : Test dans Xcode

### Ouvrir le projet iOS
```bash
cd ios/App
open App.xcworkspace
```

### Configuration dans Xcode
1. **Simulator :** iPhone 15 Pro
2. **Bouton Play :** Lance l'app
3. **Résultat attendu :** Votre vraie app TechnoCorner React

### Ce que vous devriez voir dans le simulateur
```
┌─────────────────────┐
│    ●  ●  ●         │ ← Notch iPhone
├─────────────────────┤
│ TechnoCorner        │ ← Votre vraie app React
│                     │
│ [Navigation]        │ ← Vos composants React
│ [Posts]             │
│ [Événements]        │ ← Toutes vos fonctionnalités
│ [Communauté]        │
│                     │
│ [Footer]            │
└─────────────────────┘
```

## Étape 6 : Résolution des problèmes courants

### Problème : "Index.html not found"
```bash
# Solution : Refaire le build complet
npm run build
npx cap sync ios
```

### Problème : App affiche une page blanche
```bash
# Vérifier les erreurs dans la console Xcode
# Menu View → Debug Area → Show Debug Area

# Regarder les erreurs JavaScript
# Souvent lié à des chemins d'assets incorrects
```

### Problème : Styles CSS manquants
```bash
# Vérifier que le CSS est bien copié
ls -la ios/App/public/assets/*.css

# Si absent, rebuild
npm run build
npx cap sync ios
```

### Problème : JavaScript ne fonctionne pas
```bash
# Vérifier la console pour erreurs
# Souvent lié à des API calls vers localhost

# Solution : Configurer les URLs pour mobile
# Dans votre code React, utiliser des URLs absolues
```

## Étape 7 : Optimisations pour iOS

### Configuration pour mobile
```typescript
// Dans votre code React, adapter pour mobile
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://votre-api.com' 
  : 'http://localhost:3000';
```

### Capacitor plugins pour fonctionnalités natives
```typescript
// Exemples d'intégrations iOS
import { StatusBar } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';

// Masquer le splash screen
await SplashScreen.hide();

// Configurer la barre de statut
await StatusBar.setStyle({ style: Style.Dark });
```

## Étape 8 : Workflow de développement

### Pour chaque modification de code
```bash
# 1. Modifier votre code React dans client/src/
# 2. Rebuilder
npm run build

# 3. Synchroniser avec iOS
npx cap sync ios

# 4. Tester dans Xcode
# Cmd+R dans Xcode pour relancer
```

### Automatisation avec script
```bash
# Créer un script de build iOS
cat > build-ios.sh << 'EOF'
#!/bin/bash
echo "Building React app..."
npm run build

echo "Syncing with iOS..."
npx cap sync ios

echo "Opening Xcode..."
cd ios/App && open App.xcworkspace
EOF

chmod +x build-ios.sh
```

## Récapitulatif du processus

**Votre app React → Build → iOS :**
1. Code React/TypeScript dans `client/src/`
2. `npm run build` → Compile en `dist/`
3. `npx cap sync ios` → Copie vers `ios/App/public/`
4. Xcode → Lit `ios/App/public/` → Affiche votre app

**Le résultat :** Votre application TechnoCorner complète (navigation, posts, événements, scanner QR, etc.) fonctionne nativement sur iPhone avec toutes les fonctionnalités iOS.