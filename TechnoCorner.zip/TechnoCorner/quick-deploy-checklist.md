# Checklist de Déploiement Rapide - TechnoCorner

## Commandes Essentielles

```bash
# 1. Préparer le projet
cd votre-projet-technocorner
npm install
npm run build
npx cap sync ios
npx cap open ios
```

## Dans Xcode (5 minutes)

**Configuration :**
- Team : Votre Apple Developer Account
- Bundle ID : com.technocorner.app
- Display Name : TechnoCorner

**Build :**
- Product → Archive
- Distribute App → App Store Connect → Upload

## App Store Connect (30 minutes)

**Création app :**
- My Apps → + → New App
- Nom : TechnoCorner
- Bundle ID : com.technocorner.app

**Métadonnées minimales :**
- Description : "Découvrez la scène techno avec TechnoCorner ! Trouvez des événements, connectez-vous avec la communauté électronique et scannez vos billets."
- Catégorie : Musique
- Mots-clés : techno,événements,musique,communauté,billets
- Screenshots : 5 captures iPhone (1290x2796px)

**Soumission :**
- Sélectionner le build uploadé
- Submit for Review

## Temps Total : 2-3 jours
- Configuration : 1 heure
- Révision Apple : 24-48 heures
- Publication : Immédiate

L'application est entièrement configurée et prête pour la publication.