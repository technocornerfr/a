#!/bin/bash

echo "🎧 TechnoCorner iOS Build Script"
echo "================================"

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check prerequisites
echo "Checking prerequisites..."

if ! command_exists npm; then
    echo "❌ npm not found. Please install Node.js"
    exit 1
fi

if ! command_exists npx; then
    echo "❌ npx not found. Please install Node.js"
    exit 1
fi

echo "✅ Prerequisites OK"

# Step 1: Create dist directory if it doesn't exist
echo ""
echo "Step 1: Preparing build directory..."
mkdir -p dist

# Step 2: Copy client files to dist
echo "Step 2: Copying React application..."
cp -r client/* dist/
echo "✅ React app copied to dist/"

# Step 3: Copy public assets
echo "Step 3: Copying public assets..."
if [ -d "public" ]; then
    cp -r public/* dist/
    echo "✅ Public assets copied"
else
    echo "⚠️  No public directory found, skipping"
fi

# Step 4: Update paths for production
echo "Step 4: Updating index.html for production..."
sed -i.bak 's|/src/main.tsx|./src/main.tsx|g' dist/index.html
sed -i.bak 's|type="module"|type="module"|g' dist/index.html

# Step 5: Capacitor sync
echo ""
echo "Step 5: Synchronizing with iOS..."
if ! command_exists cap; then
    echo "Using npx for Capacitor..."
    npx cap sync ios
else
    cap sync ios
fi

if [ $? -eq 0 ]; then
    echo "✅ Capacitor sync completed successfully"
else
    echo "❌ Capacitor sync failed"
    exit 1
fi

# Step 6: Verify iOS files
echo ""
echo "Step 6: Verifying iOS integration..."
if [ -d "ios/App/public" ]; then
    echo "✅ iOS public directory exists"
    echo "Files in iOS public:"
    ls -la ios/App/public/
else
    echo "❌ iOS public directory not found"
    exit 1
fi

# Step 7: Open Xcode
echo ""
echo "Step 7: Opening Xcode..."
if command_exists open; then
    cd ios/App
    open App.xcworkspace
    echo "✅ Xcode opened with TechnoCorner project"
else
    echo "⚠️  'open' command not available. Please manually open ios/App/App.xcworkspace"
fi

echo ""
echo "🎉 TechnoCorner iOS build completed!"
echo ""
echo "Next steps in Xcode:"
echo "1. Select iPhone 15 Pro as destination"
echo "2. Click Play button to test in simulator"
echo "3. For App Store: Select 'Any iOS Device' → Product → Archive"
echo ""
echo "Your complete TechnoCorner app with all features is ready for iOS!"